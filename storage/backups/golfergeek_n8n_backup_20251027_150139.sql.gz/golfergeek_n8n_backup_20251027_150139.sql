--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-10-27 20:01:39 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS postgres;
--
-- TOC entry 4390 (class 1262 OID 5)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4391 (class 0 OID 0)
-- Dependencies: 4390
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 4393 (class 0 OID 0)
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'super-secret-jwt-token-with-at-least-32-characters-long';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 16 (class 2615 OID 16779)
-- Name: n8n; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA n8n;


ALTER SCHEMA n8n OWNER TO postgres;

--
-- TOC entry 4394 (class 0 OID 0)
-- Dependencies: 16
-- Name: SCHEMA n8n; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA n8n IS 'Schema for n8n workflow automation tables and data';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 316 (class 1259 OID 18294)
-- Name: annotation_tag_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.annotation_tag_entity (
    id character varying(16) NOT NULL,
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.annotation_tag_entity OWNER TO postgres;

--
-- TOC entry 317 (class 1259 OID 18299)
-- Name: auth_identity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.auth_identity (
    "userId" uuid,
    "providerId" character varying(64) NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.auth_identity OWNER TO postgres;

--
-- TOC entry 318 (class 1259 OID 18304)
-- Name: auth_provider_sync_history; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.auth_provider_sync_history (
    id integer NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "runMode" text NOT NULL,
    status text NOT NULL,
    "startedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    scanned integer NOT NULL,
    created integer NOT NULL,
    updated integer NOT NULL,
    disabled integer NOT NULL,
    error text
);


ALTER TABLE n8n.auth_provider_sync_history OWNER TO postgres;

--
-- TOC entry 319 (class 1259 OID 18311)
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.auth_provider_sync_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE n8n.auth_provider_sync_history_id_seq OWNER TO postgres;

--
-- TOC entry 4395 (class 0 OID 0)
-- Dependencies: 319
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.auth_provider_sync_history_id_seq OWNED BY n8n.auth_provider_sync_history.id;


--
-- TOC entry 320 (class 1259 OID 18312)
-- Name: credentials_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.credentials_entity (
    name character varying(128) NOT NULL,
    data text NOT NULL,
    type character varying(128) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL,
    "isManaged" boolean DEFAULT false NOT NULL
);


ALTER TABLE n8n.credentials_entity OWNER TO postgres;

--
-- TOC entry 321 (class 1259 OID 18320)
-- Name: data_table; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.data_table (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.data_table OWNER TO postgres;

--
-- TOC entry 322 (class 1259 OID 18325)
-- Name: data_table_column; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.data_table_column (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    type character varying(32) NOT NULL,
    index integer NOT NULL,
    "dataTableId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.data_table_column OWNER TO postgres;

--
-- TOC entry 4396 (class 0 OID 0)
-- Dependencies: 322
-- Name: COLUMN data_table_column.type; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.data_table_column.type IS 'Expected: string, number, boolean, or date (not enforced as a constraint)';


--
-- TOC entry 4397 (class 0 OID 0)
-- Dependencies: 322
-- Name: COLUMN data_table_column.index; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.data_table_column.index IS 'Column order, starting from 0 (0 = first column)';


--
-- TOC entry 323 (class 1259 OID 18330)
-- Name: event_destinations; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.event_destinations (
    id uuid NOT NULL,
    destination jsonb NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.event_destinations OWNER TO postgres;

--
-- TOC entry 324 (class 1259 OID 18337)
-- Name: execution_annotation_tags; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_annotation_tags (
    "annotationId" integer NOT NULL,
    "tagId" character varying(24) NOT NULL
);


ALTER TABLE n8n.execution_annotation_tags OWNER TO postgres;

--
-- TOC entry 325 (class 1259 OID 18340)
-- Name: execution_annotations; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_annotations (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    vote character varying(6),
    note text,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.execution_annotations OWNER TO postgres;

--
-- TOC entry 326 (class 1259 OID 18347)
-- Name: execution_annotations_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.execution_annotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE n8n.execution_annotations_id_seq OWNER TO postgres;

--
-- TOC entry 4398 (class 0 OID 0)
-- Dependencies: 326
-- Name: execution_annotations_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.execution_annotations_id_seq OWNED BY n8n.execution_annotations.id;


--
-- TOC entry 327 (class 1259 OID 18348)
-- Name: execution_data; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_data (
    "executionId" integer NOT NULL,
    "workflowData" json NOT NULL,
    data text NOT NULL
);


ALTER TABLE n8n.execution_data OWNER TO postgres;

--
-- TOC entry 328 (class 1259 OID 18353)
-- Name: execution_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_entity (
    id integer NOT NULL,
    finished boolean NOT NULL,
    mode character varying NOT NULL,
    "retryOf" character varying,
    "retrySuccessId" character varying,
    "startedAt" timestamp(3) with time zone,
    "stoppedAt" timestamp(3) with time zone,
    "waitTill" timestamp(3) with time zone,
    status character varying NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "deletedAt" timestamp(3) with time zone,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.execution_entity OWNER TO postgres;

--
-- TOC entry 329 (class 1259 OID 18359)
-- Name: execution_entity_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.execution_entity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE n8n.execution_entity_id_seq OWNER TO postgres;

--
-- TOC entry 4399 (class 0 OID 0)
-- Dependencies: 329
-- Name: execution_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.execution_entity_id_seq OWNED BY n8n.execution_entity.id;


--
-- TOC entry 330 (class 1259 OID 18360)
-- Name: execution_metadata; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.execution_metadata (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL
);


ALTER TABLE n8n.execution_metadata OWNER TO postgres;

--
-- TOC entry 331 (class 1259 OID 18365)
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.execution_metadata_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE n8n.execution_metadata_temp_id_seq OWNER TO postgres;

--
-- TOC entry 4400 (class 0 OID 0)
-- Dependencies: 331
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.execution_metadata_temp_id_seq OWNED BY n8n.execution_metadata.id;


--
-- TOC entry 332 (class 1259 OID 18366)
-- Name: folder; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.folder (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "parentFolderId" character varying(36),
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.folder OWNER TO postgres;

--
-- TOC entry 333 (class 1259 OID 18371)
-- Name: folder_tag; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.folder_tag (
    "folderId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE n8n.folder_tag OWNER TO postgres;

--
-- TOC entry 334 (class 1259 OID 18374)
-- Name: insights_by_period; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.insights_by_period (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "periodUnit" integer NOT NULL,
    "periodStart" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE n8n.insights_by_period OWNER TO postgres;

--
-- TOC entry 4401 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN insights_by_period.type; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.insights_by_period.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- TOC entry 4402 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN insights_by_period."periodUnit"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.insights_by_period."periodUnit" IS '0: hour, 1: day, 2: week';


--
-- TOC entry 335 (class 1259 OID 18378)
-- Name: insights_by_period_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

ALTER TABLE n8n.insights_by_period ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n.insights_by_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 336 (class 1259 OID 18379)
-- Name: insights_metadata; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.insights_metadata (
    "metaId" integer NOT NULL,
    "workflowId" character varying(16),
    "projectId" character varying(36),
    "workflowName" character varying(128) NOT NULL,
    "projectName" character varying(255) NOT NULL
);


ALTER TABLE n8n.insights_metadata OWNER TO postgres;

--
-- TOC entry 337 (class 1259 OID 18382)
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

ALTER TABLE n8n.insights_metadata ALTER COLUMN "metaId" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n."insights_metadata_metaId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 338 (class 1259 OID 18383)
-- Name: insights_raw; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.insights_raw (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "timestamp" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE n8n.insights_raw OWNER TO postgres;

--
-- TOC entry 4403 (class 0 OID 0)
-- Dependencies: 338
-- Name: COLUMN insights_raw.type; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.insights_raw.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- TOC entry 339 (class 1259 OID 18387)
-- Name: insights_raw_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

ALTER TABLE n8n.insights_raw ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n.insights_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 340 (class 1259 OID 18388)
-- Name: installed_nodes; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.installed_nodes (
    name character varying(200) NOT NULL,
    type character varying(200) NOT NULL,
    "latestVersion" integer DEFAULT 1 NOT NULL,
    package character varying(241) NOT NULL
);


ALTER TABLE n8n.installed_nodes OWNER TO postgres;

--
-- TOC entry 341 (class 1259 OID 18394)
-- Name: installed_packages; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.installed_packages (
    "packageName" character varying(214) NOT NULL,
    "installedVersion" character varying(50) NOT NULL,
    "authorName" character varying(70),
    "authorEmail" character varying(70),
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.installed_packages OWNER TO postgres;

--
-- TOC entry 342 (class 1259 OID 18399)
-- Name: invalid_auth_token; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.invalid_auth_token (
    token character varying(512) NOT NULL,
    "expiresAt" timestamp(3) with time zone NOT NULL
);


ALTER TABLE n8n.invalid_auth_token OWNER TO postgres;

--
-- TOC entry 343 (class 1259 OID 18404)
-- Name: migration_metadata; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.migration_metadata (
    migration_file text NOT NULL,
    source text NOT NULL,
    workflow_id text,
    notes text,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE n8n.migration_metadata OWNER TO postgres;

--
-- TOC entry 4404 (class 0 OID 0)
-- Dependencies: 343
-- Name: TABLE migration_metadata; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON TABLE n8n.migration_metadata IS 'Tracks n8n workflow migration sources and metadata (moved to n8n schema for better organization)';


--
-- TOC entry 4405 (class 0 OID 0)
-- Dependencies: 343
-- Name: COLUMN migration_metadata.source; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.migration_metadata.source IS 'Origin of the migration: dev, prod, or staging';


--
-- TOC entry 4406 (class 0 OID 0)
-- Dependencies: 343
-- Name: COLUMN migration_metadata.workflow_id; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.migration_metadata.workflow_id IS 'References the n8n workflow this migration manages';


--
-- TOC entry 344 (class 1259 OID 18410)
-- Name: migrations; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE n8n.migrations OWNER TO postgres;

--
-- TOC entry 345 (class 1259 OID 18415)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: n8n; Owner: postgres
--

CREATE SEQUENCE n8n.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE n8n.migrations_id_seq OWNER TO postgres;

--
-- TOC entry 4407 (class 0 OID 0)
-- Dependencies: 345
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: postgres
--

ALTER SEQUENCE n8n.migrations_id_seq OWNED BY n8n.migrations.id;


--
-- TOC entry 346 (class 1259 OID 18416)
-- Name: n8n_workflows; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.n8n_workflows (
    id text NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT false NOT NULL,
    nodes jsonb NOT NULL,
    connections jsonb NOT NULL,
    settings jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE n8n.n8n_workflows OWNER TO postgres;

--
-- TOC entry 4408 (class 0 OID 0)
-- Dependencies: 346
-- Name: TABLE n8n_workflows; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON TABLE n8n.n8n_workflows IS 'Stores n8n workflow definitions for sync between environments (moved from public schema)';


--
-- TOC entry 347 (class 1259 OID 18424)
-- Name: processed_data; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.processed_data (
    "workflowId" character varying(36) NOT NULL,
    context character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    value text NOT NULL
);


ALTER TABLE n8n.processed_data OWNER TO postgres;

--
-- TOC entry 348 (class 1259 OID 18431)
-- Name: project; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.project (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    icon json,
    description character varying(512)
);


ALTER TABLE n8n.project OWNER TO postgres;

--
-- TOC entry 349 (class 1259 OID 18438)
-- Name: project_relation; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.project_relation (
    "projectId" character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    role character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.project_relation OWNER TO postgres;

--
-- TOC entry 350 (class 1259 OID 18445)
-- Name: role; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.role (
    slug character varying(128) NOT NULL,
    "displayName" text,
    description text,
    "roleType" text,
    "systemRole" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.role OWNER TO postgres;

--
-- TOC entry 4409 (class 0 OID 0)
-- Dependencies: 350
-- Name: COLUMN role.slug; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role.slug IS 'Unique identifier of the role for example: "global:owner"';


--
-- TOC entry 4410 (class 0 OID 0)
-- Dependencies: 350
-- Name: COLUMN role."displayName"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role."displayName" IS 'Name used to display in the UI';


--
-- TOC entry 4411 (class 0 OID 0)
-- Dependencies: 350
-- Name: COLUMN role.description; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role.description IS 'Text describing the scope in more detail of users';


--
-- TOC entry 4412 (class 0 OID 0)
-- Dependencies: 350
-- Name: COLUMN role."roleType"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role."roleType" IS 'Type of the role, e.g., global, project, or workflow';


--
-- TOC entry 4413 (class 0 OID 0)
-- Dependencies: 350
-- Name: COLUMN role."systemRole"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.role."systemRole" IS 'Indicates if the role is managed by the system and cannot be edited';


--
-- TOC entry 351 (class 1259 OID 18453)
-- Name: role_scope; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.role_scope (
    "roleSlug" character varying(128) NOT NULL,
    "scopeSlug" character varying(128) NOT NULL
);


ALTER TABLE n8n.role_scope OWNER TO postgres;

--
-- TOC entry 352 (class 1259 OID 18456)
-- Name: scope; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.scope (
    slug character varying(128) NOT NULL,
    "displayName" text,
    description text
);


ALTER TABLE n8n.scope OWNER TO postgres;

--
-- TOC entry 4414 (class 0 OID 0)
-- Dependencies: 352
-- Name: COLUMN scope.slug; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.scope.slug IS 'Unique identifier of the scope for example: "project:create"';


--
-- TOC entry 4415 (class 0 OID 0)
-- Dependencies: 352
-- Name: COLUMN scope."displayName"; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.scope."displayName" IS 'Name used to display in the UI';


--
-- TOC entry 4416 (class 0 OID 0)
-- Dependencies: 352
-- Name: COLUMN scope.description; Type: COMMENT; Schema: n8n; Owner: postgres
--

COMMENT ON COLUMN n8n.scope.description IS 'Text describing the scope in more detail of users';


--
-- TOC entry 353 (class 1259 OID 18461)
-- Name: settings; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.settings (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    "loadOnStartup" boolean DEFAULT false NOT NULL
);


ALTER TABLE n8n.settings OWNER TO postgres;

--
-- TOC entry 354 (class 1259 OID 18467)
-- Name: shared_credentials; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.shared_credentials (
    "credentialsId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.shared_credentials OWNER TO postgres;

--
-- TOC entry 355 (class 1259 OID 18474)
-- Name: shared_workflow; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.shared_workflow (
    "workflowId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.shared_workflow OWNER TO postgres;

--
-- TOC entry 356 (class 1259 OID 18481)
-- Name: tag_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.tag_entity (
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL
);


ALTER TABLE n8n.tag_entity OWNER TO postgres;

--
-- TOC entry 357 (class 1259 OID 18486)
-- Name: test_case_execution; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.test_case_execution (
    id character varying(36) NOT NULL,
    "testRunId" character varying(36) NOT NULL,
    "executionId" integer,
    status character varying NOT NULL,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    "errorCode" character varying,
    "errorDetails" json,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    inputs json,
    outputs json
);


ALTER TABLE n8n.test_case_execution OWNER TO postgres;

--
-- TOC entry 358 (class 1259 OID 18493)
-- Name: test_run; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.test_run (
    id character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    status character varying NOT NULL,
    "errorCode" character varying,
    "errorDetails" json,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE n8n.test_run OWNER TO postgres;

--
-- TOC entry 359 (class 1259 OID 18500)
-- Name: user; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n."user" (
    id uuid DEFAULT uuid_in((OVERLAY(OVERLAY(md5((((random())::text || ':'::text) || (clock_timestamp())::text)) PLACING '4'::text FROM 13) PLACING to_hex((floor(((random() * (((11 - 8) + 1))::double precision) + (8)::double precision)))::integer) FROM 17))::cstring) NOT NULL,
    email character varying(255),
    "firstName" character varying(32),
    "lastName" character varying(32),
    password character varying(255),
    "personalizationAnswers" json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    disabled boolean DEFAULT false NOT NULL,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaSecret" text,
    "mfaRecoveryCodes" text,
    "lastActiveAt" date,
    "roleSlug" character varying(128) DEFAULT 'global:member'::character varying NOT NULL
);


ALTER TABLE n8n."user" OWNER TO postgres;

--
-- TOC entry 360 (class 1259 OID 18511)
-- Name: user_api_keys; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.user_api_keys (
    id character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    label character varying(100) NOT NULL,
    "apiKey" character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    scopes json
);


ALTER TABLE n8n.user_api_keys OWNER TO postgres;

--
-- TOC entry 361 (class 1259 OID 18518)
-- Name: variables; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.variables (
    key character varying(50) NOT NULL,
    type character varying(50) DEFAULT 'string'::character varying NOT NULL,
    value character varying(255),
    id character varying(36) NOT NULL
);


ALTER TABLE n8n.variables OWNER TO postgres;

--
-- TOC entry 362 (class 1259 OID 18522)
-- Name: webhook_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.webhook_entity (
    "webhookPath" character varying NOT NULL,
    method character varying NOT NULL,
    node character varying NOT NULL,
    "webhookId" character varying,
    "pathLength" integer,
    "workflowId" character varying(36) NOT NULL
);


ALTER TABLE n8n.webhook_entity OWNER TO postgres;

--
-- TOC entry 363 (class 1259 OID 18527)
-- Name: workflow_entity; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflow_entity (
    name character varying(128) NOT NULL,
    active boolean NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    "staticData" json,
    "pinData" json,
    "versionId" character(36),
    "triggerCount" integer DEFAULT 0 NOT NULL,
    id character varying(36) NOT NULL,
    meta json,
    "parentFolderId" character varying(36) DEFAULT NULL::character varying,
    "isArchived" boolean DEFAULT false NOT NULL
);


ALTER TABLE n8n.workflow_entity OWNER TO postgres;

--
-- TOC entry 364 (class 1259 OID 18537)
-- Name: workflow_history; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflow_history (
    "versionId" character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    authors character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL
);


ALTER TABLE n8n.workflow_history OWNER TO postgres;

--
-- TOC entry 365 (class 1259 OID 18544)
-- Name: workflow_statistics; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflow_statistics (
    count integer DEFAULT 0,
    "latestEvent" timestamp(3) with time zone,
    name character varying(128) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "rootCount" integer DEFAULT 0
);


ALTER TABLE n8n.workflow_statistics OWNER TO postgres;

--
-- TOC entry 366 (class 1259 OID 18549)
-- Name: workflows_tags; Type: TABLE; Schema: n8n; Owner: postgres
--

CREATE TABLE n8n.workflows_tags (
    "workflowId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE n8n.workflows_tags OWNER TO postgres;

--
-- TOC entry 3941 (class 2604 OID 33277)
-- Name: auth_provider_sync_history id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_provider_sync_history ALTER COLUMN id SET DEFAULT nextval('n8n.auth_provider_sync_history_id_seq'::regclass);


--
-- TOC entry 3953 (class 2604 OID 33278)
-- Name: execution_annotations id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotations ALTER COLUMN id SET DEFAULT nextval('n8n.execution_annotations_id_seq'::regclass);


--
-- TOC entry 3956 (class 2604 OID 33279)
-- Name: execution_entity id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_entity ALTER COLUMN id SET DEFAULT nextval('n8n.execution_entity_id_seq'::regclass);


--
-- TOC entry 3958 (class 2604 OID 33280)
-- Name: execution_metadata id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_metadata ALTER COLUMN id SET DEFAULT nextval('n8n.execution_metadata_temp_id_seq'::regclass);


--
-- TOC entry 3967 (class 2604 OID 33281)
-- Name: migrations id; Type: DEFAULT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migrations ALTER COLUMN id SET DEFAULT nextval('n8n.migrations_id_seq'::regclass);


--
-- TOC entry 4334 (class 0 OID 18294)
-- Dependencies: 316
-- Data for Name: annotation_tag_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.annotation_tag_entity (id, name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4335 (class 0 OID 18299)
-- Dependencies: 317
-- Data for Name: auth_identity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.auth_identity ("userId", "providerId", "providerType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4336 (class 0 OID 18304)
-- Dependencies: 318
-- Data for Name: auth_provider_sync_history; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.auth_provider_sync_history (id, "providerType", "runMode", status, "startedAt", "endedAt", scanned, created, updated, disabled, error) FROM stdin;
\.


--
-- TOC entry 4338 (class 0 OID 18312)
-- Dependencies: 320
-- Data for Name: credentials_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.credentials_entity (name, data, type, "createdAt", "updatedAt", id, "isManaged") FROM stdin;
OpenAi account	U2FsdGVkX1+mnTyiaiCAEXHtV70KWtgtLuMkBMcq4TRlJ/lyXB7pN0d1lm5y0KpPaK9iEptg/ulmMH74gSvaJ5zt66NIwJoTyYDHDHo7jYVSIqibtEGSj2vWGA0CUrXBzHhhSyS4HiC9HyJujLbJ9akrj4rl8p22pdgqh1joWXyZwyo7BdjOn5shPzKrRpJwRTQnoorp13NF/gJfoIrAremU1h04U/PEltlTEBS3b/12ahzBtobmeuNES0qsp4e//wg2Elx6pXDgq92MQJC2xw==	openAiApi	2025-10-10 12:48:44.887+00	2025-10-10 12:51:03.155+00	7tuOlNCTiyjK0BzN	f
Ollama account	U2FsdGVkX1926CqP+KsEyuL53ryhMxqFYII9O29F+D+rs2ZcuQPALeKfU8lBJbZxP04leya9OtoJwqN+h9yu0A==	ollamaApi	2025-10-11 02:59:30.013+00	2025-10-11 03:04:13.033+00	hz52TIdzOn7p9IzY	f
\.


--
-- TOC entry 4339 (class 0 OID 18320)
-- Dependencies: 321
-- Data for Name: data_table; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.data_table (id, name, "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4340 (class 0 OID 18325)
-- Dependencies: 322
-- Data for Name: data_table_column; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.data_table_column (id, name, type, index, "dataTableId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4341 (class 0 OID 18330)
-- Dependencies: 323
-- Data for Name: event_destinations; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.event_destinations (id, destination, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4342 (class 0 OID 18337)
-- Dependencies: 324
-- Data for Name: execution_annotation_tags; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_annotation_tags ("annotationId", "tagId") FROM stdin;
\.


--
-- TOC entry 4343 (class 0 OID 18340)
-- Dependencies: 325
-- Data for Name: execution_annotations; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_annotations (id, "executionId", vote, note, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4345 (class 0 OID 18348)
-- Dependencies: 327
-- Data for Name: execution_data; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_data ("executionId", "workflowData", data) FROM stdin;
209	{"id":"1LaQnwqSoTxmnw3Z","name":"Marketing Swarm - Flexible LLM","active":true,"nodes":[{"parameters":{"multipleMethods":false,"httpMethod":"POST","path":"marketing-swarm-flexible","authentication":"none","responseMode":"responseNode","webhookNotice":"","options":{}},"id":"webhook","name":"Webhook","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[-16,304],"webhookId":"marketing-swarm-flex"},{"parameters":{"operation":"call_workflow","outdatedVersionWarning":"","source":"database","workflowId":{"__rl":true,"value":"9jxl03jCcqg17oOy","mode":"id"},"executeWorkflowNotice":"","mode":"once","options":{}},"id":"web-post-task","name":"Web Post Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,144]},{"parameters":{"operation":"call_workflow","outdatedVersionWarning":"","source":"database","workflowId":{"__rl":true,"value":"9jxl03jCcqg17oOy","mode":"id","cachedResultUrl":"/workflow/9jxl03jCcqg17oOy"},"executeWorkflowNotice":"","mode":"once","options":{}},"id":"seo-task","name":"SEO Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,304]},{"parameters":{"operation":"call_workflow","outdatedVersionWarning":"","source":"database","workflowId":{"__rl":true,"value":"9jxl03jCcqg17oOy","mode":"id","cachedResultUrl":"/workflow/9jxl03jCcqg17oOy"},"executeWorkflowNotice":"","mode":"once","options":{}},"id":"social-task","name":"Social Media Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,480]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $('Webhook').item.json.body.statusWebHook }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Webhook').item.json.body.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: 'swarm completed',\\n  message: 'Marketing Swarm workflow completed',\\n  sequence: 4,\\n  totalSteps: 4,\\n  conversationId: $('Webhook').item.json.body.conversationId,\\n  userId: $('WebHook').item.json.userId,\\n}) }}","options":{},"infoMessage":""},"id":"send-final-status","name":"Send Final Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1760,96],"continueOnFail":true},{"parameters":{"generalNotice":"","respondWith":"json","webhookNotice":"","responseBody":"={{ JSON.stringify({\\n  \\"web post\\": $json.webPost,\\n  \\"seo\\": $json.seoContent,\\n  \\"social media\\": $json.socialMedia\\n}) }}","options":{}},"id":"respond","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[1760,240]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}","id":"0e7e1195-46be-4104-ae35-19107420019d"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}","id":"997b9201-041c-4053-81f2-7e1f69ffe070"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}","id":"37100b7a-3727-4855-824f-2725e80d0440"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}","id":"c26c5743-8792-41fc-807a-65cc83a14ca1"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}","id":"f95fd7fb-df93-4dd3-8450-2830ce517fcd"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}","id":"56763026-b467-4e4b-b3fb-7842b63c1caf"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebHook }}","id":"5b5c4d3a-93bf-4f2d-aadf-e31b89a41079"},{"id":"a95859db-69f5-46c2-a895-883b3659deac","name":"systemMessage","value":"You are a social media content strategist. Create engaging social media posts (NOT blog posts) for multiple platforms: Twitter/X (280 chars with hashtags), LinkedIn (professional tone, 1300 chars max), and Facebook (conversational, 500 chars). Focus on hooks, engagement, and platform-specific best practices. Include relevant hashtags and emojis where appropriate.","type":"string"},{"id":"5c7b8969-c60a-42df-b9dc-84849e0f10a2","name":"userMessage","value":"={{ $json.body.announcement }}","type":"string"},{"id":"7b8664d1-0f50-4a1d-ad16-3867967041f8","name":"stepName","value":"Create Social Media","type":"string"},{"id":"291d34dd-2292-4cea-9432-3ae16b054053","name":"sequence","value":"3","type":"string"},{"id":"8cc15d2f-cab2-4691-b5ec-954ded016211","name":"totalSteps","value":"3","type":"string"}]},"includeOtherFields":false,"options":{}},"id":"99b3b396-8e31-444e-aa5e-f652105cf9a7","name":"Social Media","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,480]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}","id":"0e7e1195-46be-4104-ae35-19107420019d"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}","id":"997b9201-041c-4053-81f2-7e1f69ffe070"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}","id":"37100b7a-3727-4855-824f-2725e80d0440"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}","id":"c26c5743-8792-41fc-807a-65cc83a14ca1"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}","id":"f95fd7fb-df93-4dd3-8450-2830ce517fcd"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}","id":"56763026-b467-4e4b-b3fb-7842b63c1caf"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","id":"5b5c4d3a-93bf-4f2d-aadf-e31b89a41079"},{"id":"a95859db-69f5-46c2-a895-883b3659deac","name":"systemMessage","value":"You are an expert SEO specialist. Generate comprehensive SEO-optimized content including: meta title (60 chars max), meta description (155 chars max), 5-10 relevant keywords, H1 heading, and JSON-LD structured data for the given topic. Focus on search intent, readability, and technical SEO best practices.","type":"string"},{"id":"5c7b8969-c60a-42df-b9dc-84849e0f10a2","name":"userMessage","value":"={{ $json.body.announcement }}","type":"string"},{"id":"7b8664d1-0f50-4a1d-ad16-3867967041f8","name":"stepName","value":"Create SEO","type":"string"},{"id":"291d34dd-2292-4cea-9432-3ae16b054053","name":"sequence","value":2,"type":"number"},{"id":"8cc15d2f-cab2-4691-b5ec-954ded016211","name":"totalSteps","value":3,"type":"number"}]},"includeOtherFields":false,"options":{}},"id":"c035862f-b3ef-48e8-b7d3-8226b0a0642a","name":"SEO","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}","id":"0e7e1195-46be-4104-ae35-19107420019d"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}","id":"997b9201-041c-4053-81f2-7e1f69ffe070"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}","id":"37100b7a-3727-4855-824f-2725e80d0440"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}","id":"c26c5743-8792-41fc-807a-65cc83a14ca1"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}","id":"f95fd7fb-df93-4dd3-8450-2830ce517fcd"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}","id":"56763026-b467-4e4b-b3fb-7842b63c1caf"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","id":"5b5c4d3a-93bf-4f2d-aadf-e31b89a41079"},{"id":"a95859db-69f5-46c2-a895-883b3659deac","name":"systemMessage","value":"You are a brilliant blog post writer who specializes in being both entertaining and informative, and you're best known for being able to write posts for all audiences. ","type":"string"},{"id":"5c7b8969-c60a-42df-b9dc-84849e0f10a2","name":"userMessage","value":"={{ $json.body.announcement }}","type":"string"},{"id":"7b8664d1-0f50-4a1d-ad16-3867967041f8","name":"stepName","value":"Write Blog Post","type":"string"},{"id":"291d34dd-2292-4cea-9432-3ae16b054053","name":"sequence","value":1,"type":"number"},{"id":"8cc15d2f-cab2-4691-b5ec-954ded016211","name":"totalSteps","value":3,"type":"number"}]},"includeOtherFields":false,"options":{}},"id":"extract-config","name":"Web Post","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,144]},{"parameters":{"mode":"append","numberInputs":3},"type":"n8n-nodes-base.merge","typeVersion":3.2,"position":[1264,224],"id":"9a602287-8e53-45f0-a320-517acc8c7912","name":"Merge"},{"parameters":{"mode":"runOnceForAllItems","language":"javaScript","jsCode":"// Get all 3 items from the merge\\nconst items = $input.all();\\n\\n// Combine them into a single object\\nreturn [{\\n  json: {\\n    webPost: items[0].json.text,\\n    seoContent: items[1].json.text,\\n    socialMedia: items[2].json.text\\n  }\\n}];","notice":""},"type":"n8n-nodes-base.code","typeVersion":2,"position":[1520,240],"id":"df59f646-cdbe-4d71-b958-db6a17c2d003","name":"Code in JavaScript"}],"connections":{"Webhook":{"main":[[{"node":"Web Post","type":"main","index":0},{"node":"SEO","type":"main","index":0},{"node":"Social Media","type":"main","index":0}]]},"Web Post Task":{"main":[[{"node":"Merge","type":"main","index":0}]]},"SEO Task":{"main":[[{"node":"Merge","type":"main","index":1}]]},"Social Media Task":{"main":[[{"node":"Merge","type":"main","index":2}]]},"Send Final Status":{"main":[[]]},"Social Media":{"main":[[{"node":"Social Media Task","type":"main","index":0}]]},"SEO":{"main":[[{"node":"SEO Task","type":"main","index":0}]]},"Web Post":{"main":[[{"node":"Web Post Task","type":"main","index":0}]]},"Merge":{"main":[[{"node":"Code in JavaScript","type":"main","index":0}]]},"Code in JavaScript":{"main":[[{"node":"Respond to Webhook","type":"main","index":0},{"node":"Send Final Status","type":"main","index":0}]]}},"settings":{},"staticData":{},"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3"},{},{"runData":"4","pinData":"5","lastNodeExecuted":"6","error":"7"},{"contextData":"8","nodeExecutionStack":"9","waitingExecution":"10","waitingExecutionSource":"11"},{"Webhook":"12","Web Post":"13","SEO":"14","Social Media":"15","Web Post Task":"16","SEO Task":"17","Social Media Task":"18"},{},"Social Media Task",{"level":"19","tags":"20","description":"21","errorResponse":"22","timestamp":1760382117778,"context":"23","functionality":"24","name":"25","node":"26","messages":"27","executionId":"28","workflowId":"29","message":"30","stack":"31"},{},["32"],{"Merge":"33"},{"Merge":"34"},["35"],["36"],["37"],["38"],["39"],["40"],["41"],"warning",{},"<html>\\r\\n<head><title>502 Bad Gateway</title></head>\\r\\n<body>\\r\\n<center><h1>502 Bad Gateway</h1></center>\\r\\n<hr><center>cloudflare</center>\\r\\n</body>\\r\\n</html>\\r\\n",{"level":"19","tags":"42","description":"21","timestamp":1760382117764,"context":"43","functionality":"24","name":"44","node":"45","messages":"46","httpCode":"47","message":"30","stack":"31","executionId":"28","workflowId":"29"},{},"regular","NodeOperationError",{"parameters":"48","type":"49","typeVersion":1.8,"position":"50","id":"51","name":"52","credentials":"53"},[],"212","9jxl03jCcqg17oOy","Bad gateway - the service failed to handle your request","NodeApiError: Bad gateway - the service failed to handle your request\\n    at ExecuteContext.requestWithAuthentication (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/utils/request-helper-functions.ts:1472:10)\\n    at processTicksAndRejections (node:internal/process/task_queues:105:5)\\n    at ExecuteContext.requestWithAuthentication (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/utils/request-helper-functions.ts:1758:11)\\n    at ExecuteContext.apiRequest (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/@n8n+n8n-nodes-langchain@file+packages+@n8n+nodes-langchain_fc553bfe732254ec5207074cf9e2ceb7/node_modules/@n8n/n8n-nodes-langchain/nodes/vendors/OpenAi/transport/index.ts:56:9)\\n    at ExecuteContext.execute (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/@n8n+n8n-nodes-langchain@file+packages+@n8n+nodes-langchain_fc553bfe732254ec5207074cf9e2ceb7/node_modules/@n8n/n8n-nodes-langchain/nodes/vendors/OpenAi/actions/text/message.operation.ts:290:18)\\n    at ExecuteContext.router (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/@n8n+n8n-nodes-langchain@file+packages+@n8n+nodes-langchain_fc553bfe732254ec5207074cf9e2ceb7/node_modules/@n8n/n8n-nodes-langchain/nodes/vendors/OpenAi/actions/router.ts:54:25)\\n    at ExecuteContext.execute (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/@n8n+n8n-nodes-langchain@file+packages+@n8n+nodes-langchain_fc553bfe732254ec5207074cf9e2ceb7/node_modules/@n8n/n8n-nodes-langchain/nodes/vendors/OpenAi/OpenAi.node.ts:16:10)\\n    at WorkflowExecute.executeNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1265:8)\\n    at WorkflowExecute.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1446:11)\\n    at /usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1847:27",{"node":"54","data":"55","source":"56"},{"0":"57"},{"0":"58"},{"startTime":1760382093226,"executionIndex":0,"source":"59","hints":"60","executionTime":1,"executionStatus":"61","data":"62"},{"startTime":1760382093227,"executionIndex":1,"source":"63","hints":"64","executionTime":3,"executionStatus":"61","data":"65"},{"startTime":1760382093230,"executionIndex":2,"source":"66","hints":"67","executionTime":1,"executionStatus":"61","data":"68"},{"startTime":1760382093231,"executionIndex":3,"source":"69","hints":"70","executionTime":1,"executionStatus":"61","data":"71"},{"startTime":1760382093232,"executionIndex":4,"source":"72","hints":"73","executionTime":18445,"metadata":"74","executionStatus":"61","data":"75"},{"startTime":1760382111677,"executionIndex":5,"source":"76","hints":"77","executionTime":5519,"metadata":"78","executionStatus":"61","data":"79"},{"startTime":1760382117196,"executionIndex":6,"source":"80","hints":"81","executionTime":582,"executionStatus":"82","error":"83"},{},{"itemIndex":0},"NodeApiError",{"parameters":"84","type":"49","typeVersion":1.8,"position":"85","id":"51","name":"52","credentials":"86"},["87"],"502",{"resource":"88","operation":"89","modelId":"90","messages":"91","simplify":true,"jsonOutput":false,"hideTools":"92","options":"93"},"@n8n/n8n-nodes-langchain.openAi",[576,112],"0f6dbcf1-2458-4881-8c32-a4619529064e","OpenAI",{"openAiApi":"94"},{"parameters":"95","id":"96","name":"6","type":"97","typeVersion":1.1,"position":"98"},{"main":"99"},{"main":"80"},{"main":"100"},{"main":"101"},[],[],"success",{"main":"102"},["103"],[],{"main":"104"},["105"],[],{"main":"106"},["107"],[],{"main":"108"},["109"],[],{"subExecution":"110","subExecutionsCount":1},{"main":"111"},["112"],[],{"subExecution":"113","subExecutionsCount":1},{"main":"114"},["115"],[],"error",{"level":"19","tags":"20","description":"21","errorResponse":"22","timestamp":1760382117778,"context":"23","functionality":"24","name":"25","node":"26","messages":"27","executionId":"28","workflowId":"29","message":"30","stack":"31"},{"resource":"88","operation":"89","modelId":"116","messages":"117","simplify":true,"jsonOutput":false,"hideTools":"92","options":"118"},[576,112],{"openAiApi":"119"},"502 - \\"<html>\\\\r\\\\n<head><title>502 Bad Gateway</title></head>\\\\r\\\\n<body>\\\\r\\\\n<center><h1>502 Bad Gateway</h1></center>\\\\r\\\\n<hr><center>cloudflare</center>\\\\r\\\\n</body>\\\\r\\\\n</html>\\\\r\\\\n\\"","text","message",{"__rl":true,"value":"120","mode":"121"},{"values":"122"},"hide",{},{"id":"123","name":"124"},{"operation":"125","outdatedVersionWarning":"126","source":"127","workflowId":"128","executeWorkflowNotice":"126","mode":"129","options":"130"},"social-task","n8n-nodes-base.executeWorkflow",[912,480],["131"],["132","133",null],["134","135",null],["136"],{"previousNode":"137"},["138"],{"previousNode":"137"},["139"],{"previousNode":"137"},["140"],{"previousNode":"141"},{"executionId":"142","workflowId":"29"},["132"],{"previousNode":"143"},{"executionId":"144","workflowId":"29"},["133"],{"previousNode":"145"},{"__rl":true,"value":"120","mode":"121"},{"values":"146"},{},{"id":"123","name":"124"},"={{ $json.model }}","id",["147","148"],"7tuOlNCTiyjK0BzN","OpenAi account","call_workflow","","database",{"__rl":true,"value":"29","mode":"121","cachedResultUrl":"149"},"once",{},["150"],["151"],["152"],{"previousNode":"153"},{"previousNode":"154"},["155"],"Webhook",["156"],["157"],["158"],"Web Post","210","SEO","211","Social Media",["159","160"],{"content":"161","role":"162"},{"content":"163","role":"164"},"/workflow/9jxl03jCcqg17oOy",{"json":"165","pairedItem":"166"},{"json":"167","pairedItem":"168"},{"json":"169","pairedItem":"170"},"Web Post Task","SEO Task",{"json":"171","pairedItem":"172"},{"json":"173","pairedItem":"174"},{"json":"175","pairedItem":"176"},{"json":"165","pairedItem":"177"},{"content":"161","role":"162"},{"content":"163","role":"164"},"={{ $json['userMessage'] }}","user","={{ $json['systemMessage'] }}","system",{"provider":"178","model":"179","announcement":"180","taskId":"181","conversationId":"182","userId":"183","statusWebhook":"184","systemMessage":"185","userMessage":"180","stepName":"186","sequence":"187","totalSteps":"187"},{"item":0},{"text":"188","provider":"178","model":"179"},{"item":0},{"text":"189","provider":"178","model":"179"},{"item":0},{"headers":"190","params":"191","query":"192","body":"193","webhookUrl":"194","executionMode":"195"},{"item":0},{"provider":"178","model":"179","announcement":"180","taskId":"181","conversationId":"182","userId":"183","statusWebhook":"184","systemMessage":"196","userMessage":"180","stepName":"197","sequence":1,"totalSteps":3},{"item":0},{"provider":"178","model":"179","announcement":"180","taskId":"181","conversationId":"182","userId":"183","statusWebhook":"184","systemMessage":"198","userMessage":"180","stepName":"199","sequence":2,"totalSteps":3},{"item":0},{"item":0},"openai","gpt-4o","We'd like to announce our new product Orchestrator AI for Small Companies!","a1b2c3d4-5e6f-7890-abcd-ef1234567890","c6d7e8f9-0a1b-2c3d-4e5f-678901234567","u5e6f7a8-9b0c-1d2e-3f4a-567890123456","http://host.docker.internal:7100/webhooks/status","You are a social media content strategist. Create engaging social media posts (NOT blog posts) for multiple platforms: Twitter/X (280 chars with hashtags), LinkedIn (professional tone, 1300 chars max), and Facebook (conversational, 500 chars). Focus on hooks, engagement, and platform-specific best practices. Include relevant hashtags and emojis where appropriate.","Create Social Media","3","**Unlocking the Symphony of Success: Meet Orchestrator AI for Small Companies!**\\n\\nDrumroll, please! Ladies and gentlemen, entrepreneurs and dreamers, innovators and small business warriors, gather 'round! Today, we're rolling out the red carpet for a groundbreaking debut that’s set to transform the small business landscape. Fasten your seatbelts, because Orchestrator AI is here to be the maestro of your entrepreneurial symphony!\\n\\n### The Timbre of Innovation\\n\\nImagine conducting a business without missing a beat—an experience where strategy dances harmoniously with execution, and every decision rings with clarity and precision. Too poetic? Perhaps. But that’s precisely the transition Orchestrator AI brings to the table, transforming the cacophony of small business chaos into a harmonious melody of success.\\n\\n### Crescendo of Capabilities\\n\\nDesigned with small companies in mind, Orchestrator AI is your dynamic conductor, leading the ensemble of your business operations with:\\n\\n- **Seamless Integration**: Whatever tools and platforms your business uses, consider them a part of your orchestra pit. From CRM to accounting, Orchestrator AI integrates seamlessly to ensure all sections play in perfect harmony.\\n  \\n- **Predictive Analytics**: Harnessing the power of AI, Orchestrator AI anticipates market trends, customer needs, and potential hiccups before they even appear on your radar. Consider it your crystal ball—minus the mystic fog.\\n\\n- **Tailored Solutions**: Every business is its own composition—unique in rhythm and key. Orchestrator AI analyzes your specific needs, offering solutions that are as unique as your business tune.\\n\\n- **User-friendly Interface**: You don’t need to be a tech virtuoso to navigate Orchestrator AI. Our intuitive design ensures that you can easily compose and control every aspect of your business operations.\\n\\n### Symphony of Support\\n\\nWe know maestros aren’t born overnight, which is why Orchestrator AI is backed by an incredible support team ready to guide you through your business overtures. With round-the-clock assistance, your business crescendo will never fall flat.\\n\\n### Overture to Opportunity\\n\\nFor small companies eager to carve their niche, Orchestrator AI is the baton of empowerment. It’s more than a tool; it’s your ticket to a business performance that hits all the right notes.\\n\\nSo, dear readers, the stage is set. If your business is ready to usher in a new era of efficiency, growth, and innovation, let Orchestrator AI lead the way. The audience is waiting, the stage is yours—let’s make some beautiful business music together!\\n\\nStay tuned for more updates, harmonies, and stories as we journey with you, making the small company world a stage for innovation and success. Here's to orchestrating success, one small business at a time!\\n\\n---\\n\\n**Encore, please!** Drop us your thoughts or share your small-company symphony stories in the comments below. We’d love to hear how Orchestrator AI can support your next big debut! 🎵","**Meta Title:**  \\nOrchestrator AI for Small Businesses | Transform Your Company\\n\\n**Meta Description:**  \\nDiscover Orchestrator AI, designed to empower small businesses with innovative solutions for growth, efficiency, and success. Boost your company's potential today!\\n\\n**Keywords:**  \\nOrchestrator AI, small business AI, AI solutions for companies, business automation, AI technology, small company growth, business efficiency, artificial intelligence\\n\\n**H1 Heading:**  \\nIntroducing Orchestrator AI: The Ultimate AI Solution for Small Companies\\n\\n**JSON-LD Structured Data:**\\n\\n```json\\n{\\n  \\"@context\\": \\"https://schema.org\\",\\n  \\"@type\\": \\"Product\\",\\n  \\"name\\": \\"Orchestrator AI\\",\\n  \\"description\\": \\"Orchestrator AI is an innovative product designed to empower small businesses with advanced AI solutions, enhancing growth, efficiency, and operational success.\\",\\n  \\"brand\\": {\\n    \\"@type\\": \\"Brand\\",\\n    \\"name\\": \\"Orchestrator AI\\"\\n  },\\n  \\"offers\\": {\\n    \\"@type\\": \\"Offer\\",\\n    \\"url\\": \\"https://www.yourwebsite.com/orchestrator-ai\\",\\n    \\"priceCurrency\\": \\"USD\\",\\n    \\"availability\\": \\"https://schema.org/InStock\\"\\n  },\\n  \\"productID\\": \\"OAIS-001\\",\\n  \\"category\\": \\"https://schema.org/SoftwareApplication\\",\\n  \\"additionalType\\": \\"https://schema.org/AIApplication\\",\\n  \\"audience\\": {\\n    \\"@type\\": \\"Audience\\",\\n    \\"audienceType\\": \\"Small Business Owners\\"\\n  },\\n  \\"mainEntityOfPage\\": {\\n    \\"@type\\": \\"WebPage\\",\\n    \\"@id\\": \\"https://www.yourwebsite.com/orchestrator-ai\\"\\n  }\\n}\\n```\\n\\n**Content Recommendations:**\\n\\n1. **Introduction:** Start with a captivating introduction about the challenges faced by small businesses and how Orchestrator AI is designed to meet those challenges with precision and innovation.\\n\\n2. **Features and Benefits:** Detail the core features of Orchestrator AI and explain how each one can benefit small businesses. Use bullet points or numbered lists for clarity and readability.\\n\\n3. **Use Cases:** Provide specific examples or case studies of how Orchestrator AI has helped small companies automate processes, increase efficiency, and drive growth.\\n\\n4. **Call to Action:** End with a strong call to action, encouraging readers to visit the product page, sign up for a demo, or contact a sales representative for more information.\\n\\n5. **Visuals and Media:** Incorporate high-quality images and video demonstrations to visually communicate the capabilities and advantages of Orchestrator AI.  \\n\\nBy implementing these content guidelines alongside the technical SEO elements provided, you can effectively enhance the visibility and engagement of the Orchestrator AI product announcement.",{"content-type":"200","user-agent":"201","accept":"202","cache-control":"203","postman-token":"204","host":"205","accept-encoding":"206","connection":"207","content-length":"208"},{},{},{"taskId":"181","conversationId":"182","userId":"183","announcement":"180","statusWebHook":"184","provider":"178","model":"179"},"http://localhost:5678/webhook-test/marketing-swarm-flexible","test","You are a brilliant blog post writer who specializes in being both entertaining and informative, and you're best known for being able to write posts for all audiences. ","Write Blog Post","You are an expert SEO specialist. Generate comprehensive SEO-optimized content including: meta title (60 chars max), meta description (155 chars max), 5-10 relevant keywords, H1 heading, and JSON-LD structured data for the given topic. Focus on search intent, readability, and technical SEO best practices.","Create SEO","application/json","PostmanRuntime/7.48.0","*/*","no-cache","7056b786-b1a2-4820-b9ec-59a038fe9bdc","localhost:5678","gzip, deflate, br","keep-alive","392"]
210	{"id":"9jxl03jCcqg17oOy","name":"Helper: LLM Task","active":false,"isArchived":false,"createdAt":"2025-10-08T18:29:22.544Z","updatedAt":"2025-10-11T06:27:38.143Z","nodes":[{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || \\"http://host.docker.internal:7100/webhooks/status\\"}}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $json.taskId,\\n  status: 'running',\\n  timestamp: new Date().toISOString(),\\n  step: $json.stepName,\\n  message: `Starting ${$json.stepName || 'task'}`,\\n  sequence: $json.sequence,\\n  totalSteps: $json.totalSteps,\\n  conversationId: $json.conversationId,\\n  userId: $json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-start-status","name":"Send Start Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[288,176],"continueOnFail":true},{"parameters":{"mode":"rules","rules":{"values":[{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"leftValue":"={{ $json.provider }}","rightValue":"openai","operator":{"type":"string","operation":"equals"},"id":"a1593526-252b-40e7-b755-414c0363680d"}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"46d844e4-2f30-44cb-87c6-618ed4c789d3","leftValue":"={{ $json.provider }}","rightValue":"ollama","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"9331fc1c-d594-4900-81b6-89021334541c","leftValue":"=  {{ $json.provider }}","rightValue":"anthropic","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false}]},"options":{"fallbackOutput":0}},"id":"select-provider","name":"Select Provider","type":"n8n-nodes-base.switch","typeVersion":3,"position":[256,432]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"https://api.anthropic.com/v1/messages","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Trigger').item.json.model || 'claude-3-sonnet-20240229',\\\\n  messages: [{ role: 'user', content: $('Trigger').item.json.prompt }],\\\\n  temperature: $('Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{},"infoMessage":""},"id":"anthropic-request","name":"Anthropic Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[576,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.message.content }}","id":"30f4cc34-cbec-4fca-8b91-e20aa43ddd65"},{"name":"provider","type":"string","value":"openai","id":"541ecad6-3b94-4836-96b0-b9781b984082"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"60f6d0c1-0884-4c00-bacc-53c73c86c2c2"}]},"includeOtherFields":false,"options":{}},"id":"normalize-openai","name":"Normalize OpenAI","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,112]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.output }}","id":"926dda93-2e9e-4dfc-8bc0-117cdd7411ec"},{"name":"provider","type":"string","value":"ollama","id":"e3f38e7d-5f10-4f83-93e4-a07d98b0d9ec"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"97cf8ec6-5dfd-422c-b9ff-834a7af9af05"},{"name":"usage","type":"object","value":"={{ { prompt_tokens: $json.prompt_eval_count, completion_tokens: $json.eval_count } }}","id":"13a20d07-fc9f-4bac-aec5-98f4007f2b27"}]},"includeOtherFields":false,"options":{}},"id":"normalize-ollama","name":"Normalize Ollama","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.content[0].text }}"},{"name":"provider","type":"string","value":"anthropic"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"includeOtherFields":false,"options":{}},"id":"normalize-anthropic","name":"Normalize Anthropic","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,528]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Edit Fields').item.json.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: $('Edit Fields').item.json.stepName,\\n  message: `Completed ${$('Edit Fields').item.json.stepName || 'task'}`,\\n  sequence: $('Edit Fields').item.json.sequence,\\n  totalSteps: $('Edit Fields').item.json.totalSteps,\\n  conversationId: $('Edit Fields').item.json.conversationId,\\n  userId: $('Edit Fields').item.json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-end-status","name":"Send End Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1584,224],"continueOnFail":true},{"parameters":{"events":"worklfow_call","notice":"","outdatedVersionWarning":""},"id":"execute-workflow-trigger","name":"Trigger","type":"n8n-nodes-base.executeWorkflowTrigger","typeVersion":1,"position":[-144,400]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"id":"12f8c18a-7b6e-4614-85bf-229053383b5c","name":"taskId","value":"={{ $json.taskId }}","type":"string"},{"id":"9028a85d-49ec-4801-a5a4-2d69221316ab","name":"conversationId","value":"={{ $json.conversationId}}","type":"string"},{"id":"3ff69eae-d1d9-4914-bc6b-373025caf3cd","name":"userId","value":"={{ $json.userId }}","type":"string"},{"id":"56ff3fd3-baf6-47c6-9d39-ac0b0ee08fe1","name":"provider","value":"={{ $json.provider }}","type":"string"},{"id":"ccff1938-95b6-4aa9-a5c2-920db7438e80","name":"model","value":"={{ $json.model }}","type":"string"},{"id":"78a2244a-5425-45ee-8aa2-b1fe99b5148d","name":"systemMessage","value":"={{ $json.systemMessage }}","type":"string"},{"id":"8e5dd07f-7174-48d1-b8e9-88e1d14ee329","name":"userMessage","value":"={{ $json.userMessage }}","type":"string"},{"id":"caaafbf9-3b3f-4af7-a781-5a4777759fe5","name":"stepName","value":"={{ $json.stepName }} ","type":"string"},{"id":"61b1529b-9cb1-4b73-b469-b835fc78767a","name":"sequence","value":"={{ $json.sequence }}","type":"number"},{"id":"c5163f91-4647-4a7c-b7b7-346abb4acb25","name":"statusWebhook","value":"={{ $json.statusWebhook }}","type":"string"},{"id":"3f34c0ff-db77-42a1-9d41-90abe27a1150","name":"=totalSteps","value":"={{ $json.totalSteps }}","type":"number"}]},"includeOtherFields":false,"options":{}},"type":"n8n-nodes-base.set","typeVersion":3.4,"position":[96,288],"id":"81c83945-6bd0-41bb-9a6d-7c8eb2db9338","name":"Edit Fields"},{"parameters":{},"type":"n8n-nodes-base.noOp","typeVersion":1,"position":[1584,384],"id":"9d553c6b-ecae-4157-acf2-c5d6dff83eaa","name":"No Operation, do nothing"},{"parameters":{"notice":"","model":"llama3.2","options":{}},"type":"@n8n/n8n-nodes-langchain.lmChatOllama","typeVersion":1,"position":[928,400],"id":"84dbc11a-2747-4d17-ab88-d368279feb87","name":"Ollama Chat Model","credentials":{"ollamaApi":{"id":"hz52TIdzOn7p9IzY","name":"Ollama account"}}},{"parameters":{"resource":"text","operation":"message","modelId":{"__rl":true,"value":"={{ $json.model }}","mode":"id"},"messages":{"values":[{"content":"={{ $json['userMessage'] }}","role":"user"},{"content":"={{ $json['systemMessage'] }}","role":"system"}]},"simplify":true,"jsonOutput":false,"hideTools":"hide","options":{}},"type":"@n8n/n8n-nodes-langchain.openAi","typeVersion":1.8,"position":[576,112],"id":"0f6dbcf1-2458-4881-8c32-a4619529064e","name":"OpenAI","credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"aiAgentStarterCallout":"","preBuiltAgentsCallout":"","promptType":"define","text":"={{ $json['userMessage'] }}","hasOutputParser":false,"needsFallback":false,"options":{"systemMessage":"={{ $json['systemMessage'] }}"}},"type":"@n8n/n8n-nodes-langchain.agent","typeVersion":2.2,"position":[576,288],"id":"9ad2d867-3295-49ee-bfe9-d5641c47dcf1","name":"Ollama"},{"parameters":{"mode":"runOnceForAllItems","language":"javaScript","jsCode":"console.log('Received data:', JSON.stringify($input.all(), null, 2));\\nreturn $input.all();","notice":""},"type":"n8n-nodes-base.code","typeVersion":2,"position":[16,560],"id":"09f5c425-7ea8-45e3-82f2-55e072314d39","name":"Code in JavaScript"}],"connections":{"Send Start Status":{"main":[[]]},"Select Provider":{"main":[[{"node":"OpenAI","type":"main","index":0}],[{"node":"Ollama","type":"main","index":0}],[{"node":"Anthropic Request","type":"main","index":0}],[],[]]},"Anthropic Request":{"main":[[{"node":"Normalize Anthropic","type":"main","index":0}]]},"Normalize OpenAI":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Ollama":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Anthropic":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Trigger":{"main":[[{"node":"Edit Fields","type":"main","index":0},{"node":"Code in JavaScript","type":"main","index":0}]]},"Edit Fields":{"main":[[{"node":"Send Start Status","type":"main","index":0},{"node":"Select Provider","type":"main","index":0}]]},"Ollama Chat Model":{"ai_languageModel":[[{"node":"Ollama","type":"ai_languageModel","index":0}]]},"OpenAI":{"main":[[{"node":"Normalize OpenAI","type":"main","index":0}]]},"Ollama":{"main":[[{"node":"Normalize Ollama","type":"main","index":0}]]}},"settings":{},"staticData":null,"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3","parentExecution":"4"},{},{"runData":"5","lastNodeExecuted":"6"},{"contextData":"7","metadata":"8","nodeExecutionStack":"9","waitingExecution":"10","waitingExecutionSource":"11"},{"executionId":"12","workflowId":"13"},{"Trigger":"14","Edit Fields":"15","Code in JavaScript":"16","Send Start Status":"17","Select Provider":"18","OpenAI":"19","Normalize OpenAI":"20","Send End Status":"21","No Operation, do nothing":"22"},"No Operation, do nothing",{},{},[],{},{},"209","1LaQnwqSoTxmnw3Z",["23"],["24"],["25"],["26"],["27"],["28"],["29"],["30"],["31"],{"startTime":1760382093254,"executionIndex":0,"source":"32","hints":"33","executionTime":1,"metadata":"34","executionStatus":"35","data":"36"},{"startTime":1760382093255,"executionIndex":1,"source":"37","hints":"38","executionTime":2,"executionStatus":"35","data":"39"},{"startTime":1760382093257,"executionIndex":2,"source":"40","hints":"41","executionTime":11,"executionStatus":"35","data":"42"},{"startTime":1760382093268,"executionIndex":3,"source":"43","hints":"44","executionTime":16,"executionStatus":"35","data":"45"},{"startTime":1760382093284,"executionIndex":4,"source":"46","hints":"47","executionTime":1,"executionStatus":"35","data":"48"},{"startTime":1760382093285,"executionIndex":5,"source":"49","hints":"50","executionTime":18354,"executionStatus":"35","data":"51"},{"startTime":1760382111639,"executionIndex":6,"source":"52","hints":"53","executionTime":2,"executionStatus":"35","data":"54"},{"startTime":1760382111641,"executionIndex":7,"source":"55","hints":"56","executionTime":22,"executionStatus":"35","data":"57"},{"startTime":1760382111663,"executionIndex":8,"source":"58","hints":"59","executionTime":1,"executionStatus":"35","data":"60"},[],[],{"parentExecution":"4"},"success",{"main":"61"},["62"],[],{"main":"63"},["64"],[],{"main":"65"},["66"],[],{"main":"67"},["68"],[],{"main":"69"},["70"],[],{"main":"71"},["72"],[],{"main":"73"},["74"],[],{"main":"75"},["76"],[],{"main":"77"},["78"],{"previousNode":"79"},["80"],{"previousNode":"79"},["81"],{"previousNode":"82"},["83"],{"previousNode":"82"},["84","85","86"],{"previousNode":"87"},["88"],{"previousNode":"89"},["90"],{"previousNode":"91"},["92"],{"previousNode":"91"},["93"],["94"],"Trigger",["95"],["96"],"Edit Fields",["97"],["98"],[],[],"Select Provider",["99"],"OpenAI",["100"],"Normalize OpenAI",["101"],["102"],{"json":"103","index":0,"pairedItem":"104"},{"json":"105","pairedItem":"106"},{"json":"107","index":0,"pairedItem":"108"},{"json":"109","pairedItem":"110"},{"json":"105","pairedItem":"111"},{"json":"112","pairedItem":"113"},{"json":"114","pairedItem":"115"},{"json":"116","pairedItem":"117"},{"json":"114","pairedItem":"118"},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":1,"totalSteps":3},{"item":0},{"taskId":"122","conversationId":"123","userId":"124","provider":"119","model":"120","systemMessage":"126","userMessage":"121","stepName":"128","sequence":1,"statusWebhook":"125","totalSteps":3},{"item":0},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":1,"totalSteps":3},{"item":0},{},{"item":0},{"item":0},{"index":0,"message":"129","logprobs":null,"finish_reason":"130"},{"item":0},{"text":"131","provider":"119","model":"120"},{"item":0},{},{"item":0},{"item":0},"openai","gpt-4o","We'd like to announce our new product Orchestrator AI for Small Companies!","a1b2c3d4-5e6f-7890-abcd-ef1234567890","c6d7e8f9-0a1b-2c3d-4e5f-678901234567","u5e6f7a8-9b0c-1d2e-3f4a-567890123456","http://host.docker.internal:7100/webhooks/status","You are a brilliant blog post writer who specializes in being both entertaining and informative, and you're best known for being able to write posts for all audiences. ","Write Blog Post","Write Blog Post ",{"role":"132","content":"131","refusal":null,"annotations":"133"},"stop","**Unlocking the Symphony of Success: Meet Orchestrator AI for Small Companies!**\\n\\nDrumroll, please! Ladies and gentlemen, entrepreneurs and dreamers, innovators and small business warriors, gather 'round! Today, we're rolling out the red carpet for a groundbreaking debut that’s set to transform the small business landscape. Fasten your seatbelts, because Orchestrator AI is here to be the maestro of your entrepreneurial symphony!\\n\\n### The Timbre of Innovation\\n\\nImagine conducting a business without missing a beat—an experience where strategy dances harmoniously with execution, and every decision rings with clarity and precision. Too poetic? Perhaps. But that’s precisely the transition Orchestrator AI brings to the table, transforming the cacophony of small business chaos into a harmonious melody of success.\\n\\n### Crescendo of Capabilities\\n\\nDesigned with small companies in mind, Orchestrator AI is your dynamic conductor, leading the ensemble of your business operations with:\\n\\n- **Seamless Integration**: Whatever tools and platforms your business uses, consider them a part of your orchestra pit. From CRM to accounting, Orchestrator AI integrates seamlessly to ensure all sections play in perfect harmony.\\n  \\n- **Predictive Analytics**: Harnessing the power of AI, Orchestrator AI anticipates market trends, customer needs, and potential hiccups before they even appear on your radar. Consider it your crystal ball—minus the mystic fog.\\n\\n- **Tailored Solutions**: Every business is its own composition—unique in rhythm and key. Orchestrator AI analyzes your specific needs, offering solutions that are as unique as your business tune.\\n\\n- **User-friendly Interface**: You don’t need to be a tech virtuoso to navigate Orchestrator AI. Our intuitive design ensures that you can easily compose and control every aspect of your business operations.\\n\\n### Symphony of Support\\n\\nWe know maestros aren’t born overnight, which is why Orchestrator AI is backed by an incredible support team ready to guide you through your business overtures. With round-the-clock assistance, your business crescendo will never fall flat.\\n\\n### Overture to Opportunity\\n\\nFor small companies eager to carve their niche, Orchestrator AI is the baton of empowerment. It’s more than a tool; it’s your ticket to a business performance that hits all the right notes.\\n\\nSo, dear readers, the stage is set. If your business is ready to usher in a new era of efficiency, growth, and innovation, let Orchestrator AI lead the way. The audience is waiting, the stage is yours—let’s make some beautiful business music together!\\n\\nStay tuned for more updates, harmonies, and stories as we journey with you, making the small company world a stage for innovation and success. Here's to orchestrating success, one small business at a time!\\n\\n---\\n\\n**Encore, please!** Drop us your thoughts or share your small-company symphony stories in the comments below. We’d love to hear how Orchestrator AI can support your next big debut! 🎵","assistant",[]]
212	{"id":"9jxl03jCcqg17oOy","name":"Helper: LLM Task","active":false,"isArchived":false,"createdAt":"2025-10-08T18:29:22.544Z","updatedAt":"2025-10-11T06:27:38.143Z","nodes":[{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || \\"http://host.docker.internal:7100/webhooks/status\\"}}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $json.taskId,\\n  status: 'running',\\n  timestamp: new Date().toISOString(),\\n  step: $json.stepName,\\n  message: `Starting ${$json.stepName || 'task'}`,\\n  sequence: $json.sequence,\\n  totalSteps: $json.totalSteps,\\n  conversationId: $json.conversationId,\\n  userId: $json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-start-status","name":"Send Start Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[288,176],"continueOnFail":true},{"parameters":{"mode":"rules","rules":{"values":[{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"leftValue":"={{ $json.provider }}","rightValue":"openai","operator":{"type":"string","operation":"equals"},"id":"a1593526-252b-40e7-b755-414c0363680d"}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"46d844e4-2f30-44cb-87c6-618ed4c789d3","leftValue":"={{ $json.provider }}","rightValue":"ollama","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"9331fc1c-d594-4900-81b6-89021334541c","leftValue":"=  {{ $json.provider }}","rightValue":"anthropic","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false}]},"options":{"fallbackOutput":0}},"id":"select-provider","name":"Select Provider","type":"n8n-nodes-base.switch","typeVersion":3,"position":[256,432]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"https://api.anthropic.com/v1/messages","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Trigger').item.json.model || 'claude-3-sonnet-20240229',\\\\n  messages: [{ role: 'user', content: $('Trigger').item.json.prompt }],\\\\n  temperature: $('Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{},"infoMessage":""},"id":"anthropic-request","name":"Anthropic Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[576,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.message.content }}","id":"30f4cc34-cbec-4fca-8b91-e20aa43ddd65"},{"name":"provider","type":"string","value":"openai","id":"541ecad6-3b94-4836-96b0-b9781b984082"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"60f6d0c1-0884-4c00-bacc-53c73c86c2c2"}]},"includeOtherFields":false,"options":{}},"id":"normalize-openai","name":"Normalize OpenAI","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,112]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.output }}","id":"926dda93-2e9e-4dfc-8bc0-117cdd7411ec"},{"name":"provider","type":"string","value":"ollama","id":"e3f38e7d-5f10-4f83-93e4-a07d98b0d9ec"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"97cf8ec6-5dfd-422c-b9ff-834a7af9af05"},{"name":"usage","type":"object","value":"={{ { prompt_tokens: $json.prompt_eval_count, completion_tokens: $json.eval_count } }}","id":"13a20d07-fc9f-4bac-aec5-98f4007f2b27"}]},"includeOtherFields":false,"options":{}},"id":"normalize-ollama","name":"Normalize Ollama","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.content[0].text }}"},{"name":"provider","type":"string","value":"anthropic"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"includeOtherFields":false,"options":{}},"id":"normalize-anthropic","name":"Normalize Anthropic","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,528]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Edit Fields').item.json.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: $('Edit Fields').item.json.stepName,\\n  message: `Completed ${$('Edit Fields').item.json.stepName || 'task'}`,\\n  sequence: $('Edit Fields').item.json.sequence,\\n  totalSteps: $('Edit Fields').item.json.totalSteps,\\n  conversationId: $('Edit Fields').item.json.conversationId,\\n  userId: $('Edit Fields').item.json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-end-status","name":"Send End Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1584,224],"continueOnFail":true},{"parameters":{"events":"worklfow_call","notice":"","outdatedVersionWarning":""},"id":"execute-workflow-trigger","name":"Trigger","type":"n8n-nodes-base.executeWorkflowTrigger","typeVersion":1,"position":[-144,400]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"id":"12f8c18a-7b6e-4614-85bf-229053383b5c","name":"taskId","value":"={{ $json.taskId }}","type":"string"},{"id":"9028a85d-49ec-4801-a5a4-2d69221316ab","name":"conversationId","value":"={{ $json.conversationId}}","type":"string"},{"id":"3ff69eae-d1d9-4914-bc6b-373025caf3cd","name":"userId","value":"={{ $json.userId }}","type":"string"},{"id":"56ff3fd3-baf6-47c6-9d39-ac0b0ee08fe1","name":"provider","value":"={{ $json.provider }}","type":"string"},{"id":"ccff1938-95b6-4aa9-a5c2-920db7438e80","name":"model","value":"={{ $json.model }}","type":"string"},{"id":"78a2244a-5425-45ee-8aa2-b1fe99b5148d","name":"systemMessage","value":"={{ $json.systemMessage }}","type":"string"},{"id":"8e5dd07f-7174-48d1-b8e9-88e1d14ee329","name":"userMessage","value":"={{ $json.userMessage }}","type":"string"},{"id":"caaafbf9-3b3f-4af7-a781-5a4777759fe5","name":"stepName","value":"={{ $json.stepName }} ","type":"string"},{"id":"61b1529b-9cb1-4b73-b469-b835fc78767a","name":"sequence","value":"={{ $json.sequence }}","type":"number"},{"id":"c5163f91-4647-4a7c-b7b7-346abb4acb25","name":"statusWebhook","value":"={{ $json.statusWebhook }}","type":"string"},{"id":"3f34c0ff-db77-42a1-9d41-90abe27a1150","name":"=totalSteps","value":"={{ $json.totalSteps }}","type":"number"}]},"includeOtherFields":false,"options":{}},"type":"n8n-nodes-base.set","typeVersion":3.4,"position":[96,288],"id":"81c83945-6bd0-41bb-9a6d-7c8eb2db9338","name":"Edit Fields"},{"parameters":{},"type":"n8n-nodes-base.noOp","typeVersion":1,"position":[1584,384],"id":"9d553c6b-ecae-4157-acf2-c5d6dff83eaa","name":"No Operation, do nothing"},{"parameters":{"notice":"","model":"llama3.2","options":{}},"type":"@n8n/n8n-nodes-langchain.lmChatOllama","typeVersion":1,"position":[928,400],"id":"84dbc11a-2747-4d17-ab88-d368279feb87","name":"Ollama Chat Model","credentials":{"ollamaApi":{"id":"hz52TIdzOn7p9IzY","name":"Ollama account"}}},{"parameters":{"resource":"text","operation":"message","modelId":{"__rl":true,"value":"={{ $json.model }}","mode":"id"},"messages":{"values":[{"content":"={{ $json['userMessage'] }}","role":"user"},{"content":"={{ $json['systemMessage'] }}","role":"system"}]},"simplify":true,"jsonOutput":false,"hideTools":"hide","options":{}},"type":"@n8n/n8n-nodes-langchain.openAi","typeVersion":1.8,"position":[576,112],"id":"0f6dbcf1-2458-4881-8c32-a4619529064e","name":"OpenAI","credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"aiAgentStarterCallout":"","preBuiltAgentsCallout":"","promptType":"define","text":"={{ $json['userMessage'] }}","hasOutputParser":false,"needsFallback":false,"options":{"systemMessage":"={{ $json['systemMessage'] }}"}},"type":"@n8n/n8n-nodes-langchain.agent","typeVersion":2.2,"position":[576,288],"id":"9ad2d867-3295-49ee-bfe9-d5641c47dcf1","name":"Ollama"},{"parameters":{"mode":"runOnceForAllItems","language":"javaScript","jsCode":"console.log('Received data:', JSON.stringify($input.all(), null, 2));\\nreturn $input.all();","notice":""},"type":"n8n-nodes-base.code","typeVersion":2,"position":[16,560],"id":"09f5c425-7ea8-45e3-82f2-55e072314d39","name":"Code in JavaScript"}],"connections":{"Send Start Status":{"main":[[]]},"Select Provider":{"main":[[{"node":"OpenAI","type":"main","index":0}],[{"node":"Ollama","type":"main","index":0}],[{"node":"Anthropic Request","type":"main","index":0}],[],[]]},"Anthropic Request":{"main":[[{"node":"Normalize Anthropic","type":"main","index":0}]]},"Normalize OpenAI":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Ollama":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Anthropic":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Trigger":{"main":[[{"node":"Edit Fields","type":"main","index":0},{"node":"Code in JavaScript","type":"main","index":0}]]},"Edit Fields":{"main":[[{"node":"Send Start Status","type":"main","index":0},{"node":"Select Provider","type":"main","index":0}]]},"Ollama Chat Model":{"ai_languageModel":[[{"node":"Ollama","type":"ai_languageModel","index":0}]]},"OpenAI":{"main":[[{"node":"Normalize OpenAI","type":"main","index":0}]]},"Ollama":{"main":[[{"node":"Normalize Ollama","type":"main","index":0}]]}},"settings":{},"staticData":null,"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3","parentExecution":"4"},{},{"runData":"5","lastNodeExecuted":"6","error":"7"},{"contextData":"8","metadata":"9","nodeExecutionStack":"10","waitingExecution":"11","waitingExecutionSource":"12"},{"executionId":"13","workflowId":"14"},{"Trigger":"15","Edit Fields":"16","Code in JavaScript":"17","Send Start Status":"18","Select Provider":"19","OpenAI":"20"},"OpenAI",{"level":"21","tags":"22","description":"23","timestamp":1760382117764,"context":"24","functionality":"25","name":"26","node":"27","messages":"28","httpCode":"29","message":"30","stack":"31"},{},{},["32"],{},{},"209","1LaQnwqSoTxmnw3Z",["33"],["34"],["35"],["36"],["37"],["38"],"warning",{},"<html>\\r\\n<head><title>502 Bad Gateway</title></head>\\r\\n<body>\\r\\n<center><h1>502 Bad Gateway</h1></center>\\r\\n<hr><center>cloudflare</center>\\r\\n</body>\\r\\n</html>\\r\\n",{"itemIndex":0},"regular","NodeApiError",{"parameters":"39","type":"40","typeVersion":1.8,"position":"41","id":"42","name":"6","credentials":"43"},["44"],"502","Bad gateway - the service failed to handle your request","NodeApiError: Bad gateway - the service failed to handle your request\\n    at ExecuteContext.requestWithAuthentication (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/utils/request-helper-functions.ts:1472:10)\\n    at processTicksAndRejections (node:internal/process/task_queues:105:5)\\n    at ExecuteContext.requestWithAuthentication (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/node-execution-context/utils/request-helper-functions.ts:1758:11)\\n    at ExecuteContext.apiRequest (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/@n8n+n8n-nodes-langchain@file+packages+@n8n+nodes-langchain_fc553bfe732254ec5207074cf9e2ceb7/node_modules/@n8n/n8n-nodes-langchain/nodes/vendors/OpenAi/transport/index.ts:56:9)\\n    at ExecuteContext.execute (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/@n8n+n8n-nodes-langchain@file+packages+@n8n+nodes-langchain_fc553bfe732254ec5207074cf9e2ceb7/node_modules/@n8n/n8n-nodes-langchain/nodes/vendors/OpenAi/actions/text/message.operation.ts:290:18)\\n    at ExecuteContext.router (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/@n8n+n8n-nodes-langchain@file+packages+@n8n+nodes-langchain_fc553bfe732254ec5207074cf9e2ceb7/node_modules/@n8n/n8n-nodes-langchain/nodes/vendors/OpenAi/actions/router.ts:54:25)\\n    at ExecuteContext.execute (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/@n8n+n8n-nodes-langchain@file+packages+@n8n+nodes-langchain_fc553bfe732254ec5207074cf9e2ceb7/node_modules/@n8n/n8n-nodes-langchain/nodes/vendors/OpenAi/OpenAi.node.ts:16:10)\\n    at WorkflowExecute.executeNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1265:8)\\n    at WorkflowExecute.runNode (/usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1446:11)\\n    at /usr/local/lib/node_modules/n8n/node_modules/.pnpm/n8n-core@file+packages+core_@opentelemetry+api@1.9.0_@opentelemetry+sdk-trace-base@1.30_08b575bec2313d5d8a4cc75358971443/node_modules/n8n-core/src/execution-engine/workflow-execute.ts:1847:27",{"node":"45","data":"46","source":"47"},{"startTime":1760382117222,"executionIndex":0,"source":"48","hints":"49","executionTime":1,"metadata":"50","executionStatus":"51","data":"52"},{"startTime":1760382117223,"executionIndex":1,"source":"53","hints":"54","executionTime":1,"executionStatus":"51","data":"55"},{"startTime":1760382117224,"executionIndex":2,"source":"56","hints":"57","executionTime":28,"executionStatus":"51","data":"58"},{"startTime":1760382117252,"executionIndex":3,"source":"59","hints":"60","executionTime":7,"executionStatus":"51","data":"61"},{"startTime":1760382117259,"executionIndex":4,"source":"62","hints":"63","executionTime":1,"executionStatus":"51","data":"64"},{"startTime":1760382117260,"executionIndex":5,"source":"65","hints":"66","executionTime":507,"executionStatus":"67","error":"68"},{"resource":"69","operation":"70","modelId":"71","messages":"72","simplify":true,"jsonOutput":false,"hideTools":"73","options":"74"},"@n8n/n8n-nodes-langchain.openAi",[576,112],"0f6dbcf1-2458-4881-8c32-a4619529064e",{"openAiApi":"75"},"502 - \\"<html>\\\\r\\\\n<head><title>502 Bad Gateway</title></head>\\\\r\\\\n<body>\\\\r\\\\n<center><h1>502 Bad Gateway</h1></center>\\\\r\\\\n<hr><center>cloudflare</center>\\\\r\\\\n</body>\\\\r\\\\n</html>\\\\r\\\\n\\"",{"parameters":"76","type":"40","typeVersion":1.8,"position":"77","id":"42","name":"6","credentials":"78"},{"main":"79"},{"main":"65"},[],[],{"parentExecution":"4"},"success",{"main":"80"},["81"],[],{"main":"82"},["83"],[],{"main":"84"},["85"],[],{"main":"86"},["87"],[],{"main":"88"},["89"],[],"error",{"level":"21","tags":"22","description":"23","timestamp":1760382117764,"context":"24","functionality":"25","name":"26","node":"27","messages":"28","httpCode":"29","message":"30","stack":"31"},"text","message",{"__rl":true,"value":"90","mode":"91"},{"values":"92"},"hide",{},{"id":"93","name":"94"},{"resource":"69","operation":"70","modelId":"95","messages":"96","simplify":true,"jsonOutput":false,"hideTools":"73","options":"97"},[576,112],{"openAiApi":"98"},["99"],["100"],{"previousNode":"101"},["102"],{"previousNode":"101"},["103"],{"previousNode":"104"},["105"],{"previousNode":"104"},["106","107","108"],{"previousNode":"109"},"={{ $json.model }}","id",["110","111"],"7tuOlNCTiyjK0BzN","OpenAi account",{"__rl":true,"value":"90","mode":"91"},{"values":"112"},{},{"id":"93","name":"94"},["113"],["114"],"Trigger",["115"],["116"],"Edit Fields",["117"],["118"],[],[],"Select Provider",{"content":"119","role":"120"},{"content":"121","role":"122"},["123","124"],{"json":"125","pairedItem":"126"},{"json":"127","index":0,"pairedItem":"128"},{"json":"125","pairedItem":"129"},{"json":"130","index":0,"pairedItem":"131"},{"json":"132","pairedItem":"133"},{"json":"125","pairedItem":"134"},"={{ $json['userMessage'] }}","user","={{ $json['systemMessage'] }}","system",{"content":"119","role":"120"},{"content":"121","role":"122"},{"taskId":"135","conversationId":"136","userId":"137","provider":"138","model":"139","systemMessage":"140","userMessage":"141","stepName":"142","sequence":3,"statusWebhook":"143","totalSteps":3},{"item":0},{"provider":"138","model":"139","announcement":"141","taskId":"135","conversationId":"136","userId":"137","statusWebhook":"143","systemMessage":"140","userMessage":"141","stepName":"144","sequence":"145","totalSteps":"145"},{"item":0},{"item":0},{"provider":"138","model":"139","announcement":"141","taskId":"135","conversationId":"136","userId":"137","statusWebhook":"143","systemMessage":"140","userMessage":"141","stepName":"144","sequence":"145","totalSteps":"145"},{"item":0},{},{"item":0},{"item":0},"a1b2c3d4-5e6f-7890-abcd-ef1234567890","c6d7e8f9-0a1b-2c3d-4e5f-678901234567","u5e6f7a8-9b0c-1d2e-3f4a-567890123456","openai","gpt-4o","You are a social media content strategist. Create engaging social media posts (NOT blog posts) for multiple platforms: Twitter/X (280 chars with hashtags), LinkedIn (professional tone, 1300 chars max), and Facebook (conversational, 500 chars). Focus on hooks, engagement, and platform-specific best practices. Include relevant hashtags and emojis where appropriate.","We'd like to announce our new product Orchestrator AI for Small Companies!","Create Social Media ","http://host.docker.internal:7100/webhooks/status","Create Social Media","3"]
214	{"id":"9jxl03jCcqg17oOy","name":"Helper: LLM Task","active":false,"isArchived":false,"createdAt":"2025-10-08T18:29:22.544Z","updatedAt":"2025-10-11T06:27:38.143Z","nodes":[{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || \\"http://host.docker.internal:7100/webhooks/status\\"}}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $json.taskId,\\n  status: 'running',\\n  timestamp: new Date().toISOString(),\\n  step: $json.stepName,\\n  message: `Starting ${$json.stepName || 'task'}`,\\n  sequence: $json.sequence,\\n  totalSteps: $json.totalSteps,\\n  conversationId: $json.conversationId,\\n  userId: $json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-start-status","name":"Send Start Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[288,176],"continueOnFail":true},{"parameters":{"mode":"rules","rules":{"values":[{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"leftValue":"={{ $json.provider }}","rightValue":"openai","operator":{"type":"string","operation":"equals"},"id":"a1593526-252b-40e7-b755-414c0363680d"}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"46d844e4-2f30-44cb-87c6-618ed4c789d3","leftValue":"={{ $json.provider }}","rightValue":"ollama","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"9331fc1c-d594-4900-81b6-89021334541c","leftValue":"=  {{ $json.provider }}","rightValue":"anthropic","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false}]},"options":{"fallbackOutput":0}},"id":"select-provider","name":"Select Provider","type":"n8n-nodes-base.switch","typeVersion":3,"position":[256,432]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"https://api.anthropic.com/v1/messages","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Trigger').item.json.model || 'claude-3-sonnet-20240229',\\\\n  messages: [{ role: 'user', content: $('Trigger').item.json.prompt }],\\\\n  temperature: $('Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{},"infoMessage":""},"id":"anthropic-request","name":"Anthropic Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[576,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.message.content }}","id":"30f4cc34-cbec-4fca-8b91-e20aa43ddd65"},{"name":"provider","type":"string","value":"openai","id":"541ecad6-3b94-4836-96b0-b9781b984082"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"60f6d0c1-0884-4c00-bacc-53c73c86c2c2"}]},"includeOtherFields":false,"options":{}},"id":"normalize-openai","name":"Normalize OpenAI","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,112]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.output }}","id":"926dda93-2e9e-4dfc-8bc0-117cdd7411ec"},{"name":"provider","type":"string","value":"ollama","id":"e3f38e7d-5f10-4f83-93e4-a07d98b0d9ec"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"97cf8ec6-5dfd-422c-b9ff-834a7af9af05"},{"name":"usage","type":"object","value":"={{ { prompt_tokens: $json.prompt_eval_count, completion_tokens: $json.eval_count } }}","id":"13a20d07-fc9f-4bac-aec5-98f4007f2b27"}]},"includeOtherFields":false,"options":{}},"id":"normalize-ollama","name":"Normalize Ollama","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.content[0].text }}"},{"name":"provider","type":"string","value":"anthropic"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"includeOtherFields":false,"options":{}},"id":"normalize-anthropic","name":"Normalize Anthropic","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,528]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Edit Fields').item.json.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: $('Edit Fields').item.json.stepName,\\n  message: `Completed ${$('Edit Fields').item.json.stepName || 'task'}`,\\n  sequence: $('Edit Fields').item.json.sequence,\\n  totalSteps: $('Edit Fields').item.json.totalSteps,\\n  conversationId: $('Edit Fields').item.json.conversationId,\\n  userId: $('Edit Fields').item.json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-end-status","name":"Send End Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1584,224],"continueOnFail":true},{"parameters":{"events":"worklfow_call","notice":"","outdatedVersionWarning":""},"id":"execute-workflow-trigger","name":"Trigger","type":"n8n-nodes-base.executeWorkflowTrigger","typeVersion":1,"position":[-144,400]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"id":"12f8c18a-7b6e-4614-85bf-229053383b5c","name":"taskId","value":"={{ $json.taskId }}","type":"string"},{"id":"9028a85d-49ec-4801-a5a4-2d69221316ab","name":"conversationId","value":"={{ $json.conversationId}}","type":"string"},{"id":"3ff69eae-d1d9-4914-bc6b-373025caf3cd","name":"userId","value":"={{ $json.userId }}","type":"string"},{"id":"56ff3fd3-baf6-47c6-9d39-ac0b0ee08fe1","name":"provider","value":"={{ $json.provider }}","type":"string"},{"id":"ccff1938-95b6-4aa9-a5c2-920db7438e80","name":"model","value":"={{ $json.model }}","type":"string"},{"id":"78a2244a-5425-45ee-8aa2-b1fe99b5148d","name":"systemMessage","value":"={{ $json.systemMessage }}","type":"string"},{"id":"8e5dd07f-7174-48d1-b8e9-88e1d14ee329","name":"userMessage","value":"={{ $json.userMessage }}","type":"string"},{"id":"caaafbf9-3b3f-4af7-a781-5a4777759fe5","name":"stepName","value":"={{ $json.stepName }} ","type":"string"},{"id":"61b1529b-9cb1-4b73-b469-b835fc78767a","name":"sequence","value":"={{ $json.sequence }}","type":"number"},{"id":"c5163f91-4647-4a7c-b7b7-346abb4acb25","name":"statusWebhook","value":"={{ $json.statusWebhook }}","type":"string"},{"id":"3f34c0ff-db77-42a1-9d41-90abe27a1150","name":"=totalSteps","value":"={{ $json.totalSteps }}","type":"number"}]},"includeOtherFields":false,"options":{}},"type":"n8n-nodes-base.set","typeVersion":3.4,"position":[96,288],"id":"81c83945-6bd0-41bb-9a6d-7c8eb2db9338","name":"Edit Fields"},{"parameters":{},"type":"n8n-nodes-base.noOp","typeVersion":1,"position":[1584,384],"id":"9d553c6b-ecae-4157-acf2-c5d6dff83eaa","name":"No Operation, do nothing"},{"parameters":{"notice":"","model":"llama3.2","options":{}},"type":"@n8n/n8n-nodes-langchain.lmChatOllama","typeVersion":1,"position":[928,400],"id":"84dbc11a-2747-4d17-ab88-d368279feb87","name":"Ollama Chat Model","credentials":{"ollamaApi":{"id":"hz52TIdzOn7p9IzY","name":"Ollama account"}}},{"parameters":{"resource":"text","operation":"message","modelId":{"__rl":true,"value":"={{ $json.model }}","mode":"id"},"messages":{"values":[{"content":"={{ $json['userMessage'] }}","role":"user"},{"content":"={{ $json['systemMessage'] }}","role":"system"}]},"simplify":true,"jsonOutput":false,"hideTools":"hide","options":{}},"type":"@n8n/n8n-nodes-langchain.openAi","typeVersion":1.8,"position":[576,112],"id":"0f6dbcf1-2458-4881-8c32-a4619529064e","name":"OpenAI","credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"aiAgentStarterCallout":"","preBuiltAgentsCallout":"","promptType":"define","text":"={{ $json['userMessage'] }}","hasOutputParser":false,"needsFallback":false,"options":{"systemMessage":"={{ $json['systemMessage'] }}"}},"type":"@n8n/n8n-nodes-langchain.agent","typeVersion":2.2,"position":[576,288],"id":"9ad2d867-3295-49ee-bfe9-d5641c47dcf1","name":"Ollama"},{"parameters":{"mode":"runOnceForAllItems","language":"javaScript","jsCode":"console.log('Received data:', JSON.stringify($input.all(), null, 2));\\nreturn $input.all();","notice":""},"type":"n8n-nodes-base.code","typeVersion":2,"position":[16,560],"id":"09f5c425-7ea8-45e3-82f2-55e072314d39","name":"Code in JavaScript"}],"connections":{"Send Start Status":{"main":[[]]},"Select Provider":{"main":[[{"node":"OpenAI","type":"main","index":0}],[{"node":"Ollama","type":"main","index":0}],[{"node":"Anthropic Request","type":"main","index":0}],[],[]]},"Anthropic Request":{"main":[[{"node":"Normalize Anthropic","type":"main","index":0}]]},"Normalize OpenAI":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Ollama":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Anthropic":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Trigger":{"main":[[{"node":"Edit Fields","type":"main","index":0},{"node":"Code in JavaScript","type":"main","index":0}]]},"Edit Fields":{"main":[[{"node":"Send Start Status","type":"main","index":0},{"node":"Select Provider","type":"main","index":0}]]},"Ollama Chat Model":{"ai_languageModel":[[{"node":"Ollama","type":"ai_languageModel","index":0}]]},"OpenAI":{"main":[[{"node":"Normalize OpenAI","type":"main","index":0}]]},"Ollama":{"main":[[{"node":"Normalize Ollama","type":"main","index":0}]]}},"settings":{},"staticData":null,"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3","parentExecution":"4"},{},{"runData":"5","lastNodeExecuted":"6"},{"contextData":"7","metadata":"8","nodeExecutionStack":"9","waitingExecution":"10","waitingExecutionSource":"11"},{"executionId":"12","workflowId":"13"},{"Trigger":"14","Edit Fields":"15","Code in JavaScript":"16","Send Start Status":"17","Select Provider":"18","OpenAI":"19","Normalize OpenAI":"20","Send End Status":"21","No Operation, do nothing":"22"},"No Operation, do nothing",{},{},[],{},{},"213","1LaQnwqSoTxmnw3Z",["23"],["24"],["25"],["26"],["27"],["28"],["29"],["30"],["31"],{"startTime":1760382164478,"executionIndex":0,"source":"32","hints":"33","executionTime":0,"metadata":"34","executionStatus":"35","data":"36"},{"startTime":1760382164478,"executionIndex":1,"source":"37","hints":"38","executionTime":2,"executionStatus":"35","data":"39"},{"startTime":1760382164480,"executionIndex":2,"source":"40","hints":"41","executionTime":11,"executionStatus":"35","data":"42"},{"startTime":1760382164492,"executionIndex":3,"source":"43","hints":"44","executionTime":24,"executionStatus":"35","data":"45"},{"startTime":1760382164516,"executionIndex":4,"source":"46","hints":"47","executionTime":3,"executionStatus":"35","data":"48"},{"startTime":1760382164519,"executionIndex":5,"source":"49","hints":"50","executionTime":21407,"executionStatus":"35","data":"51"},{"startTime":1760382185926,"executionIndex":6,"source":"52","hints":"53","executionTime":4,"executionStatus":"35","data":"54"},{"startTime":1760382185935,"executionIndex":7,"source":"55","hints":"56","executionTime":73,"executionStatus":"35","data":"57"},{"startTime":1760382186008,"executionIndex":8,"source":"58","hints":"59","executionTime":1,"executionStatus":"35","data":"60"},[],[],{"parentExecution":"4"},"success",{"main":"61"},["62"],[],{"main":"63"},["64"],[],{"main":"65"},["66"],[],{"main":"67"},["68"],[],{"main":"69"},["70"],[],{"main":"71"},["72"],[],{"main":"73"},["74"],[],{"main":"75"},["76"],[],{"main":"77"},["78"],{"previousNode":"79"},["80"],{"previousNode":"79"},["81"],{"previousNode":"82"},["83"],{"previousNode":"82"},["84","85","86"],{"previousNode":"87"},["88"],{"previousNode":"89"},["90"],{"previousNode":"91"},["92"],{"previousNode":"91"},["93"],["94"],"Trigger",["95"],["96"],"Edit Fields",["97"],["98"],[],[],"Select Provider",["99"],"OpenAI",["100"],"Normalize OpenAI",["101"],["102"],{"json":"103","index":0,"pairedItem":"104"},{"json":"105","pairedItem":"106"},{"json":"107","index":0,"pairedItem":"108"},{"json":"109","pairedItem":"110"},{"json":"105","pairedItem":"111"},{"json":"112","pairedItem":"113"},{"json":"114","pairedItem":"115"},{"json":"116","pairedItem":"117"},{"json":"114","pairedItem":"118"},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":1,"totalSteps":3},{"item":0},{"taskId":"122","conversationId":"123","userId":"124","provider":"119","model":"120","systemMessage":"126","userMessage":"121","stepName":"128","sequence":1,"statusWebhook":"125","totalSteps":3},{"item":0},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":1,"totalSteps":3},{"item":0},{},{"item":0},{"item":0},{"index":0,"message":"129","logprobs":null,"finish_reason":"130"},{"item":0},{"text":"131","provider":"119","model":"120"},{"item":0},{},{"item":0},{"item":0},"openai","gpt-4o","We'd like to announce our new product Orchestrator AI for Small Companies!","a1b2c3d4-5e6f-7890-abcd-ef1234567890","c6d7e8f9-0a1b-2c3d-4e5f-678901234567","u5e6f7a8-9b0c-1d2e-3f4a-567890123456","http://host.docker.internal:7100/webhooks/status","You are a brilliant blog post writer who specializes in being both entertaining and informative, and you're best known for being able to write posts for all audiences. ","Write Blog Post","Write Blog Post ",{"role":"132","content":"131","refusal":null,"annotations":"133"},"stop","**Introducing Orchestrator AI: The Maestro of Success for Small Companies!**\\n\\n🎉 Drumroll, please! 🎉 The business world is ablaze with excitement as we unveil our latest masterpiece – Orchestrator AI for Small Companies! This isn't just another tech tool; it's your new co-pilot in the thrilling journey of your business adventure.\\n\\n**Small Giants, Meet Your Symphony Conductor**\\n\\nImagine your business as a magnificent orchestra. Your team members are the talented musicians, each with their unique skills and instruments. Until now, coordinating all these gifted individuals required the virtuoso expertise of a seasoned conductor. Enter Orchestrator AI, a masterful blend of innovation and automation, poised to conduct your business symphony with precision and flair.\\n\\n**Why Orchestrator AI?**\\n\\n1. **Tailored for Small Companies**: We've crafted Orchestrator AI with the small business owner in mind. Whether you run a cozy café, a bustling boutique, or a nimble tech startup, our AI understands your scale and speaks your language.\\n\\n2. **Efficiency Extraordinaire**: Ditch the chaos and embrace clarity! Orchestrator AI organizes your tasks, optimizes your processes, and manages time so efficiently, you'll wonder how you ever lived without it.\\n\\n3. **Insightful Analytics**: Gone are the days of making decisions in the dark. Our AI provides crystal-clear insights, drawing from the depths of your data to guide your strategies with unwavering accuracy.\\n\\n4. **Growth Partner**: This isn’t just about surviving – it's about thriving. Orchestrator AI is designed to scale with your dreams, ensuring that whether you're serving 10 clients or 10,000, you're primed for success.\\n\\n5. **Cost-Conscious Genius**: Worried about breaking the bank? Breathe easy. Orchestrator AI offers powerful capabilities on a budget that respects your financial boundaries.\\n\\n**How it Works:**\\n\\nUnleashing the potential of Orchestrator AI is as simple as a walk in the park:\\n\\n- **Integration Made Easy**: Our seamless integration process means you can start orchestrating your business brilliance in no time. No need for a Ph.D. in tech jargon.\\n\\n- **Learn, Adapt, Succeed**: Equipped with machine learning, our AI evolves alongside your business, picking up on patterns and fine-tuning its capabilities to offer even more refined guidance.\\n\\n- **Stay Ahead of the Curve**: The business landscape is dynamic, and so is Orchestrator AI. With regular updates and enhancements, you're guaranteed to always be a step ahead.\\n\\n**What Sets Us Apart?**\\n\\nThere are plenty of tools out there that promise to revolutionize your business. But Orchestrator AI doesn't just promise; it delivers a transformative experience wrapped in a user-friendly package, ensuring you spend less time managing and more time celebrating successes.\\n\\n**The Final Crescendo**\\n\\nSo, dear visionary entrepreneur, are you ready to hand over the baton to Orchestrator AI? Prepare to witness your operations transform into an elegant ballet of efficiency, creativity, and success. Get ready to dazzle your audience – the world is your stage!\\n\\nStay tuned for our launch event, where we’ll showcase Orchestrator AI in action and provide exclusive offers for early adopters. Your ticket to creating a harmonious business future awaits!\\n\\n**Hit that \\"Contact Us\\" button and let's start orchestrating your business symphony today!**\\n\\nStay harmonious,\\nThe Orchestrator AI Team 🌟","assistant",[]]
215	{"id":"9jxl03jCcqg17oOy","name":"Helper: LLM Task","active":false,"isArchived":false,"createdAt":"2025-10-08T18:29:22.544Z","updatedAt":"2025-10-11T06:27:38.143Z","nodes":[{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || \\"http://host.docker.internal:7100/webhooks/status\\"}}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $json.taskId,\\n  status: 'running',\\n  timestamp: new Date().toISOString(),\\n  step: $json.stepName,\\n  message: `Starting ${$json.stepName || 'task'}`,\\n  sequence: $json.sequence,\\n  totalSteps: $json.totalSteps,\\n  conversationId: $json.conversationId,\\n  userId: $json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-start-status","name":"Send Start Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[288,176],"continueOnFail":true},{"parameters":{"mode":"rules","rules":{"values":[{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"leftValue":"={{ $json.provider }}","rightValue":"openai","operator":{"type":"string","operation":"equals"},"id":"a1593526-252b-40e7-b755-414c0363680d"}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"46d844e4-2f30-44cb-87c6-618ed4c789d3","leftValue":"={{ $json.provider }}","rightValue":"ollama","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"9331fc1c-d594-4900-81b6-89021334541c","leftValue":"=  {{ $json.provider }}","rightValue":"anthropic","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false}]},"options":{"fallbackOutput":0}},"id":"select-provider","name":"Select Provider","type":"n8n-nodes-base.switch","typeVersion":3,"position":[256,432]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"https://api.anthropic.com/v1/messages","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Trigger').item.json.model || 'claude-3-sonnet-20240229',\\\\n  messages: [{ role: 'user', content: $('Trigger').item.json.prompt }],\\\\n  temperature: $('Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{},"infoMessage":""},"id":"anthropic-request","name":"Anthropic Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[576,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.message.content }}","id":"30f4cc34-cbec-4fca-8b91-e20aa43ddd65"},{"name":"provider","type":"string","value":"openai","id":"541ecad6-3b94-4836-96b0-b9781b984082"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"60f6d0c1-0884-4c00-bacc-53c73c86c2c2"}]},"includeOtherFields":false,"options":{}},"id":"normalize-openai","name":"Normalize OpenAI","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,112]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.output }}","id":"926dda93-2e9e-4dfc-8bc0-117cdd7411ec"},{"name":"provider","type":"string","value":"ollama","id":"e3f38e7d-5f10-4f83-93e4-a07d98b0d9ec"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"97cf8ec6-5dfd-422c-b9ff-834a7af9af05"},{"name":"usage","type":"object","value":"={{ { prompt_tokens: $json.prompt_eval_count, completion_tokens: $json.eval_count } }}","id":"13a20d07-fc9f-4bac-aec5-98f4007f2b27"}]},"includeOtherFields":false,"options":{}},"id":"normalize-ollama","name":"Normalize Ollama","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.content[0].text }}"},{"name":"provider","type":"string","value":"anthropic"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"includeOtherFields":false,"options":{}},"id":"normalize-anthropic","name":"Normalize Anthropic","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,528]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Edit Fields').item.json.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: $('Edit Fields').item.json.stepName,\\n  message: `Completed ${$('Edit Fields').item.json.stepName || 'task'}`,\\n  sequence: $('Edit Fields').item.json.sequence,\\n  totalSteps: $('Edit Fields').item.json.totalSteps,\\n  conversationId: $('Edit Fields').item.json.conversationId,\\n  userId: $('Edit Fields').item.json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-end-status","name":"Send End Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1584,224],"continueOnFail":true},{"parameters":{"events":"worklfow_call","notice":"","outdatedVersionWarning":""},"id":"execute-workflow-trigger","name":"Trigger","type":"n8n-nodes-base.executeWorkflowTrigger","typeVersion":1,"position":[-144,400]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"id":"12f8c18a-7b6e-4614-85bf-229053383b5c","name":"taskId","value":"={{ $json.taskId }}","type":"string"},{"id":"9028a85d-49ec-4801-a5a4-2d69221316ab","name":"conversationId","value":"={{ $json.conversationId}}","type":"string"},{"id":"3ff69eae-d1d9-4914-bc6b-373025caf3cd","name":"userId","value":"={{ $json.userId }}","type":"string"},{"id":"56ff3fd3-baf6-47c6-9d39-ac0b0ee08fe1","name":"provider","value":"={{ $json.provider }}","type":"string"},{"id":"ccff1938-95b6-4aa9-a5c2-920db7438e80","name":"model","value":"={{ $json.model }}","type":"string"},{"id":"78a2244a-5425-45ee-8aa2-b1fe99b5148d","name":"systemMessage","value":"={{ $json.systemMessage }}","type":"string"},{"id":"8e5dd07f-7174-48d1-b8e9-88e1d14ee329","name":"userMessage","value":"={{ $json.userMessage }}","type":"string"},{"id":"caaafbf9-3b3f-4af7-a781-5a4777759fe5","name":"stepName","value":"={{ $json.stepName }} ","type":"string"},{"id":"61b1529b-9cb1-4b73-b469-b835fc78767a","name":"sequence","value":"={{ $json.sequence }}","type":"number"},{"id":"c5163f91-4647-4a7c-b7b7-346abb4acb25","name":"statusWebhook","value":"={{ $json.statusWebhook }}","type":"string"},{"id":"3f34c0ff-db77-42a1-9d41-90abe27a1150","name":"=totalSteps","value":"={{ $json.totalSteps }}","type":"number"}]},"includeOtherFields":false,"options":{}},"type":"n8n-nodes-base.set","typeVersion":3.4,"position":[96,288],"id":"81c83945-6bd0-41bb-9a6d-7c8eb2db9338","name":"Edit Fields"},{"parameters":{},"type":"n8n-nodes-base.noOp","typeVersion":1,"position":[1584,384],"id":"9d553c6b-ecae-4157-acf2-c5d6dff83eaa","name":"No Operation, do nothing"},{"parameters":{"notice":"","model":"llama3.2","options":{}},"type":"@n8n/n8n-nodes-langchain.lmChatOllama","typeVersion":1,"position":[928,400],"id":"84dbc11a-2747-4d17-ab88-d368279feb87","name":"Ollama Chat Model","credentials":{"ollamaApi":{"id":"hz52TIdzOn7p9IzY","name":"Ollama account"}}},{"parameters":{"resource":"text","operation":"message","modelId":{"__rl":true,"value":"={{ $json.model }}","mode":"id"},"messages":{"values":[{"content":"={{ $json['userMessage'] }}","role":"user"},{"content":"={{ $json['systemMessage'] }}","role":"system"}]},"simplify":true,"jsonOutput":false,"hideTools":"hide","options":{}},"type":"@n8n/n8n-nodes-langchain.openAi","typeVersion":1.8,"position":[576,112],"id":"0f6dbcf1-2458-4881-8c32-a4619529064e","name":"OpenAI","credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"aiAgentStarterCallout":"","preBuiltAgentsCallout":"","promptType":"define","text":"={{ $json['userMessage'] }}","hasOutputParser":false,"needsFallback":false,"options":{"systemMessage":"={{ $json['systemMessage'] }}"}},"type":"@n8n/n8n-nodes-langchain.agent","typeVersion":2.2,"position":[576,288],"id":"9ad2d867-3295-49ee-bfe9-d5641c47dcf1","name":"Ollama"},{"parameters":{"mode":"runOnceForAllItems","language":"javaScript","jsCode":"console.log('Received data:', JSON.stringify($input.all(), null, 2));\\nreturn $input.all();","notice":""},"type":"n8n-nodes-base.code","typeVersion":2,"position":[16,560],"id":"09f5c425-7ea8-45e3-82f2-55e072314d39","name":"Code in JavaScript"}],"connections":{"Send Start Status":{"main":[[]]},"Select Provider":{"main":[[{"node":"OpenAI","type":"main","index":0}],[{"node":"Ollama","type":"main","index":0}],[{"node":"Anthropic Request","type":"main","index":0}],[],[]]},"Anthropic Request":{"main":[[{"node":"Normalize Anthropic","type":"main","index":0}]]},"Normalize OpenAI":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Ollama":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Anthropic":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Trigger":{"main":[[{"node":"Edit Fields","type":"main","index":0},{"node":"Code in JavaScript","type":"main","index":0}]]},"Edit Fields":{"main":[[{"node":"Send Start Status","type":"main","index":0},{"node":"Select Provider","type":"main","index":0}]]},"Ollama Chat Model":{"ai_languageModel":[[{"node":"Ollama","type":"ai_languageModel","index":0}]]},"OpenAI":{"main":[[{"node":"Normalize OpenAI","type":"main","index":0}]]},"Ollama":{"main":[[{"node":"Normalize Ollama","type":"main","index":0}]]}},"settings":{},"staticData":null,"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3","parentExecution":"4"},{},{"runData":"5","lastNodeExecuted":"6"},{"contextData":"7","metadata":"8","nodeExecutionStack":"9","waitingExecution":"10","waitingExecutionSource":"11"},{"executionId":"12","workflowId":"13"},{"Trigger":"14","Edit Fields":"15","Code in JavaScript":"16","Send Start Status":"17","Select Provider":"18","OpenAI":"19","Normalize OpenAI":"20","Send End Status":"21","No Operation, do nothing":"22"},"No Operation, do nothing",{},{},[],{},{},"213","1LaQnwqSoTxmnw3Z",["23"],["24"],["25"],["26"],["27"],["28"],["29"],["30"],["31"],{"startTime":1760382186181,"executionIndex":0,"source":"32","hints":"33","executionTime":2,"metadata":"34","executionStatus":"35","data":"36"},{"startTime":1760382186183,"executionIndex":1,"source":"37","hints":"38","executionTime":3,"executionStatus":"35","data":"39"},{"startTime":1760382186186,"executionIndex":2,"source":"40","hints":"41","executionTime":14,"executionStatus":"35","data":"42"},{"startTime":1760382186200,"executionIndex":3,"source":"43","hints":"44","executionTime":22,"executionStatus":"35","data":"45"},{"startTime":1760382186222,"executionIndex":4,"source":"46","hints":"47","executionTime":1,"executionStatus":"35","data":"48"},{"startTime":1760382186223,"executionIndex":5,"source":"49","hints":"50","executionTime":7706,"executionStatus":"35","data":"51"},{"startTime":1760382193931,"executionIndex":6,"source":"52","hints":"53","executionTime":4,"executionStatus":"35","data":"54"},{"startTime":1760382193936,"executionIndex":7,"source":"55","hints":"56","executionTime":47,"executionStatus":"35","data":"57"},{"startTime":1760382193983,"executionIndex":8,"source":"58","hints":"59","executionTime":1,"executionStatus":"35","data":"60"},[],[],{"parentExecution":"4"},"success",{"main":"61"},["62"],[],{"main":"63"},["64"],[],{"main":"65"},["66"],[],{"main":"67"},["68"],[],{"main":"69"},["70"],[],{"main":"71"},["72"],[],{"main":"73"},["74"],[],{"main":"75"},["76"],[],{"main":"77"},["78"],{"previousNode":"79"},["80"],{"previousNode":"79"},["81"],{"previousNode":"82"},["83"],{"previousNode":"82"},["84","85","86"],{"previousNode":"87"},["88"],{"previousNode":"89"},["90"],{"previousNode":"91"},["92"],{"previousNode":"91"},["93"],["94"],"Trigger",["95"],["96"],"Edit Fields",["97"],["98"],[],[],"Select Provider",["99"],"OpenAI",["100"],"Normalize OpenAI",["101"],["102"],{"json":"103","index":0,"pairedItem":"104"},{"json":"105","pairedItem":"106"},{"json":"107","index":0,"pairedItem":"108"},{"json":"109","pairedItem":"110"},{"json":"105","pairedItem":"111"},{"json":"112","pairedItem":"113"},{"json":"114","pairedItem":"115"},{"json":"116","pairedItem":"117"},{"json":"114","pairedItem":"118"},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":2,"totalSteps":3},{"item":0},{"taskId":"122","conversationId":"123","userId":"124","provider":"119","model":"120","systemMessage":"126","userMessage":"121","stepName":"128","sequence":2,"statusWebhook":"125","totalSteps":3},{"item":0},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":2,"totalSteps":3},{"item":0},{},{"item":0},{"item":0},{"index":0,"message":"129","logprobs":null,"finish_reason":"130"},{"item":0},{"text":"131","provider":"119","model":"120"},{"item":0},{},{"item":0},{"item":0},"openai","gpt-4o","We'd like to announce our new product Orchestrator AI for Small Companies!","a1b2c3d4-5e6f-7890-abcd-ef1234567890","c6d7e8f9-0a1b-2c3d-4e5f-678901234567","u5e6f7a8-9b0c-1d2e-3f4a-567890123456","http://host.docker.internal:7100/webhooks/status","You are an expert SEO specialist. Generate comprehensive SEO-optimized content including: meta title (60 chars max), meta description (155 chars max), 5-10 relevant keywords, H1 heading, and JSON-LD structured data for the given topic. Focus on search intent, readability, and technical SEO best practices.","Create SEO","Create SEO ",{"role":"132","content":"131","refusal":null,"annotations":"133"},"stop","Meta Title:  \\nOrchestrator AI for Small Companies - Transform Your Business\\n\\nMeta Description:  \\nDiscover how Orchestrator AI helps small businesses streamline operations, boost efficiency, and drive growth with innovative digital solutions.\\n\\nKeywords:  \\nOrchestrator AI, AI for small companies, small business AI, operational efficiency, business automation, AI solutions, digital transformation, innovative tech, business growth\\n\\nH1 Heading:  \\nRevolutionize Your Business Operations with Orchestrator AI for Small Companies\\n\\nJSON-LD Structured Data:  \\n```json\\n{\\n  \\"@context\\": \\"https://schema.org\\",\\n  \\"@type\\": \\"Product\\",\\n  \\"name\\": \\"Orchestrator AI for Small Companies\\",\\n  \\"description\\": \\"Orchestrator AI helps small businesses streamline operations, boost efficiency, and drive growth with innovative digital solutions.\\",\\n  \\"brand\\": {\\n    \\"@type\\": \\"Organization\\",\\n    \\"name\\": \\"Orchestrator AI\\"\\n  },\\n  \\"offers\\": {\\n    \\"@type\\": \\"Offer\\",\\n    \\"url\\": \\"https://www.orchestratorai.com/products/small-companies\\",\\n    \\"priceCurrency\\": \\"USD\\",\\n    \\"availability\\": \\"https://schema.org/InStock\\"\\n  },\\n  \\"audience\\": {\\n    \\"@type\\": \\"Audience\\",\\n    \\"audienceType\\": \\"SmallBusiness\\"\\n  },\\n  \\"potentialAction\\": {\\n    \\"@type\\": \\"ConsumeAction\\",\\n    \\"target\\": {\\n      \\"@type\\": \\"EntryPoint\\",\\n      \\"urlTemplate\\": \\"https://www.orchestratorai.com\\"\\n    }\\n  }\\n}\\n```\\n\\nThis SEO-optimized content is crafted to ensure that users searching for AI solutions for small businesses can easily discover how Orchestrator AI can maximize their operational efficiency and drive business growth. The structured data further aids search engines in understanding the context of the product, potentially enhancing visibility in search results.","assistant",[]]
216	{"id":"9jxl03jCcqg17oOy","name":"Helper: LLM Task","active":false,"isArchived":false,"createdAt":"2025-10-08T18:29:22.544Z","updatedAt":"2025-10-11T06:27:38.143Z","nodes":[{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || \\"http://host.docker.internal:7100/webhooks/status\\"}}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $json.taskId,\\n  status: 'running',\\n  timestamp: new Date().toISOString(),\\n  step: $json.stepName,\\n  message: `Starting ${$json.stepName || 'task'}`,\\n  sequence: $json.sequence,\\n  totalSteps: $json.totalSteps,\\n  conversationId: $json.conversationId,\\n  userId: $json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-start-status","name":"Send Start Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[288,176],"continueOnFail":true},{"parameters":{"mode":"rules","rules":{"values":[{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"leftValue":"={{ $json.provider }}","rightValue":"openai","operator":{"type":"string","operation":"equals"},"id":"a1593526-252b-40e7-b755-414c0363680d"}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"46d844e4-2f30-44cb-87c6-618ed4c789d3","leftValue":"={{ $json.provider }}","rightValue":"ollama","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"9331fc1c-d594-4900-81b6-89021334541c","leftValue":"=  {{ $json.provider }}","rightValue":"anthropic","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false}]},"options":{"fallbackOutput":0}},"id":"select-provider","name":"Select Provider","type":"n8n-nodes-base.switch","typeVersion":3,"position":[256,432]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"https://api.anthropic.com/v1/messages","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Trigger').item.json.model || 'claude-3-sonnet-20240229',\\\\n  messages: [{ role: 'user', content: $('Trigger').item.json.prompt }],\\\\n  temperature: $('Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{},"infoMessage":""},"id":"anthropic-request","name":"Anthropic Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[576,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.message.content }}","id":"30f4cc34-cbec-4fca-8b91-e20aa43ddd65"},{"name":"provider","type":"string","value":"openai","id":"541ecad6-3b94-4836-96b0-b9781b984082"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"60f6d0c1-0884-4c00-bacc-53c73c86c2c2"}]},"includeOtherFields":false,"options":{}},"id":"normalize-openai","name":"Normalize OpenAI","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,112]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.output }}","id":"926dda93-2e9e-4dfc-8bc0-117cdd7411ec"},{"name":"provider","type":"string","value":"ollama","id":"e3f38e7d-5f10-4f83-93e4-a07d98b0d9ec"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"97cf8ec6-5dfd-422c-b9ff-834a7af9af05"},{"name":"usage","type":"object","value":"={{ { prompt_tokens: $json.prompt_eval_count, completion_tokens: $json.eval_count } }}","id":"13a20d07-fc9f-4bac-aec5-98f4007f2b27"}]},"includeOtherFields":false,"options":{}},"id":"normalize-ollama","name":"Normalize Ollama","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.content[0].text }}"},{"name":"provider","type":"string","value":"anthropic"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"includeOtherFields":false,"options":{}},"id":"normalize-anthropic","name":"Normalize Anthropic","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,528]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Edit Fields').item.json.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: $('Edit Fields').item.json.stepName,\\n  message: `Completed ${$('Edit Fields').item.json.stepName || 'task'}`,\\n  sequence: $('Edit Fields').item.json.sequence,\\n  totalSteps: $('Edit Fields').item.json.totalSteps,\\n  conversationId: $('Edit Fields').item.json.conversationId,\\n  userId: $('Edit Fields').item.json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-end-status","name":"Send End Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1584,224],"continueOnFail":true},{"parameters":{"events":"worklfow_call","notice":"","outdatedVersionWarning":""},"id":"execute-workflow-trigger","name":"Trigger","type":"n8n-nodes-base.executeWorkflowTrigger","typeVersion":1,"position":[-144,400]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"id":"12f8c18a-7b6e-4614-85bf-229053383b5c","name":"taskId","value":"={{ $json.taskId }}","type":"string"},{"id":"9028a85d-49ec-4801-a5a4-2d69221316ab","name":"conversationId","value":"={{ $json.conversationId}}","type":"string"},{"id":"3ff69eae-d1d9-4914-bc6b-373025caf3cd","name":"userId","value":"={{ $json.userId }}","type":"string"},{"id":"56ff3fd3-baf6-47c6-9d39-ac0b0ee08fe1","name":"provider","value":"={{ $json.provider }}","type":"string"},{"id":"ccff1938-95b6-4aa9-a5c2-920db7438e80","name":"model","value":"={{ $json.model }}","type":"string"},{"id":"78a2244a-5425-45ee-8aa2-b1fe99b5148d","name":"systemMessage","value":"={{ $json.systemMessage }}","type":"string"},{"id":"8e5dd07f-7174-48d1-b8e9-88e1d14ee329","name":"userMessage","value":"={{ $json.userMessage }}","type":"string"},{"id":"caaafbf9-3b3f-4af7-a781-5a4777759fe5","name":"stepName","value":"={{ $json.stepName }} ","type":"string"},{"id":"61b1529b-9cb1-4b73-b469-b835fc78767a","name":"sequence","value":"={{ $json.sequence }}","type":"number"},{"id":"c5163f91-4647-4a7c-b7b7-346abb4acb25","name":"statusWebhook","value":"={{ $json.statusWebhook }}","type":"string"},{"id":"3f34c0ff-db77-42a1-9d41-90abe27a1150","name":"=totalSteps","value":"={{ $json.totalSteps }}","type":"number"}]},"includeOtherFields":false,"options":{}},"type":"n8n-nodes-base.set","typeVersion":3.4,"position":[96,288],"id":"81c83945-6bd0-41bb-9a6d-7c8eb2db9338","name":"Edit Fields"},{"parameters":{},"type":"n8n-nodes-base.noOp","typeVersion":1,"position":[1584,384],"id":"9d553c6b-ecae-4157-acf2-c5d6dff83eaa","name":"No Operation, do nothing"},{"parameters":{"notice":"","model":"llama3.2","options":{}},"type":"@n8n/n8n-nodes-langchain.lmChatOllama","typeVersion":1,"position":[928,400],"id":"84dbc11a-2747-4d17-ab88-d368279feb87","name":"Ollama Chat Model","credentials":{"ollamaApi":{"id":"hz52TIdzOn7p9IzY","name":"Ollama account"}}},{"parameters":{"resource":"text","operation":"message","modelId":{"__rl":true,"value":"={{ $json.model }}","mode":"id"},"messages":{"values":[{"content":"={{ $json['userMessage'] }}","role":"user"},{"content":"={{ $json['systemMessage'] }}","role":"system"}]},"simplify":true,"jsonOutput":false,"hideTools":"hide","options":{}},"type":"@n8n/n8n-nodes-langchain.openAi","typeVersion":1.8,"position":[576,112],"id":"0f6dbcf1-2458-4881-8c32-a4619529064e","name":"OpenAI","credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"aiAgentStarterCallout":"","preBuiltAgentsCallout":"","promptType":"define","text":"={{ $json['userMessage'] }}","hasOutputParser":false,"needsFallback":false,"options":{"systemMessage":"={{ $json['systemMessage'] }}"}},"type":"@n8n/n8n-nodes-langchain.agent","typeVersion":2.2,"position":[576,288],"id":"9ad2d867-3295-49ee-bfe9-d5641c47dcf1","name":"Ollama"},{"parameters":{"mode":"runOnceForAllItems","language":"javaScript","jsCode":"console.log('Received data:', JSON.stringify($input.all(), null, 2));\\nreturn $input.all();","notice":""},"type":"n8n-nodes-base.code","typeVersion":2,"position":[16,560],"id":"09f5c425-7ea8-45e3-82f2-55e072314d39","name":"Code in JavaScript"}],"connections":{"Send Start Status":{"main":[[]]},"Select Provider":{"main":[[{"node":"OpenAI","type":"main","index":0}],[{"node":"Ollama","type":"main","index":0}],[{"node":"Anthropic Request","type":"main","index":0}],[],[]]},"Anthropic Request":{"main":[[{"node":"Normalize Anthropic","type":"main","index":0}]]},"Normalize OpenAI":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Ollama":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Anthropic":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Trigger":{"main":[[{"node":"Edit Fields","type":"main","index":0},{"node":"Code in JavaScript","type":"main","index":0}]]},"Edit Fields":{"main":[[{"node":"Send Start Status","type":"main","index":0},{"node":"Select Provider","type":"main","index":0}]]},"Ollama Chat Model":{"ai_languageModel":[[{"node":"Ollama","type":"ai_languageModel","index":0}]]},"OpenAI":{"main":[[{"node":"Normalize OpenAI","type":"main","index":0}]]},"Ollama":{"main":[[{"node":"Normalize Ollama","type":"main","index":0}]]}},"settings":{},"staticData":null,"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3","parentExecution":"4"},{},{"runData":"5","lastNodeExecuted":"6"},{"contextData":"7","metadata":"8","nodeExecutionStack":"9","waitingExecution":"10","waitingExecutionSource":"11"},{"executionId":"12","workflowId":"13"},{"Trigger":"14","Edit Fields":"15","Code in JavaScript":"16","Send Start Status":"17","Select Provider":"18","OpenAI":"19","Normalize OpenAI":"20","Send End Status":"21","No Operation, do nothing":"22"},"No Operation, do nothing",{},{},[],{},{},"213","1LaQnwqSoTxmnw3Z",["23"],["24"],["25"],["26"],["27"],["28"],["29"],["30"],["31"],{"startTime":1760382194041,"executionIndex":0,"source":"32","hints":"33","executionTime":1,"metadata":"34","executionStatus":"35","data":"36"},{"startTime":1760382194042,"executionIndex":1,"source":"37","hints":"38","executionTime":2,"executionStatus":"35","data":"39"},{"startTime":1760382194044,"executionIndex":2,"source":"40","hints":"41","executionTime":11,"executionStatus":"35","data":"42"},{"startTime":1760382194055,"executionIndex":3,"source":"43","hints":"44","executionTime":7,"executionStatus":"35","data":"45"},{"startTime":1760382194062,"executionIndex":4,"source":"46","hints":"47","executionTime":2,"executionStatus":"35","data":"48"},{"startTime":1760382194064,"executionIndex":5,"source":"49","hints":"50","executionTime":9564,"executionStatus":"35","data":"51"},{"startTime":1760382203629,"executionIndex":6,"source":"52","hints":"53","executionTime":0,"executionStatus":"35","data":"54"},{"startTime":1760382203630,"executionIndex":7,"source":"55","hints":"56","executionTime":27,"executionStatus":"35","data":"57"},{"startTime":1760382203657,"executionIndex":8,"source":"58","hints":"59","executionTime":0,"executionStatus":"35","data":"60"},[],[],{"parentExecution":"4"},"success",{"main":"61"},["62"],[],{"main":"63"},["64"],[],{"main":"65"},["66"],[],{"main":"67"},["68"],[],{"main":"69"},["70"],[],{"main":"71"},["72"],[],{"main":"73"},["74"],[],{"main":"75"},["76"],[],{"main":"77"},["78"],{"previousNode":"79"},["80"],{"previousNode":"79"},["81"],{"previousNode":"82"},["83"],{"previousNode":"82"},["84","85","86"],{"previousNode":"87"},["88"],{"previousNode":"89"},["90"],{"previousNode":"91"},["92"],{"previousNode":"91"},["93"],["94"],"Trigger",["95"],["96"],"Edit Fields",["97"],["98"],[],[],"Select Provider",["99"],"OpenAI",["100"],"Normalize OpenAI",["101"],["102"],{"json":"103","index":0,"pairedItem":"104"},{"json":"105","pairedItem":"106"},{"json":"107","index":0,"pairedItem":"108"},{"json":"109","pairedItem":"110"},{"json":"105","pairedItem":"111"},{"json":"112","pairedItem":"113"},{"json":"114","pairedItem":"115"},{"json":"116","pairedItem":"117"},{"json":"114","pairedItem":"118"},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":"128","totalSteps":"128"},{"item":0},{"taskId":"122","conversationId":"123","userId":"124","provider":"119","model":"120","systemMessage":"126","userMessage":"121","stepName":"129","sequence":3,"statusWebhook":"125","totalSteps":3},{"item":0},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":"128","totalSteps":"128"},{"item":0},{},{"item":0},{"item":0},{"index":0,"message":"130","logprobs":null,"finish_reason":"131"},{"item":0},{"text":"132","provider":"119","model":"120"},{"item":0},{},{"item":0},{"item":0},"openai","gpt-4o","We'd like to announce our new product Orchestrator AI for Small Companies!","a1b2c3d4-5e6f-7890-abcd-ef1234567890","c6d7e8f9-0a1b-2c3d-4e5f-678901234567","u5e6f7a8-9b0c-1d2e-3f4a-567890123456","http://host.docker.internal:7100/webhooks/status","You are a social media content strategist. Create engaging social media posts (NOT blog posts) for multiple platforms: Twitter/X (280 chars with hashtags), LinkedIn (professional tone, 1300 chars max), and Facebook (conversational, 500 chars). Focus on hooks, engagement, and platform-specific best practices. Include relevant hashtags and emojis where appropriate.","Create Social Media","3","Create Social Media ",{"role":"133","content":"132","refusal":null,"annotations":"134"},"stop","**Twitter/X:**\\n\\n🎉 Exciting News for Small Businesses! 🎉 Introducing Orchestrator AI - your new partner in boosting efficiency and innovation. Ready to revolutionize your operations and streamline success? 🌟 Learn more! 🚀 #OrchestratorAI #SmallBizSuccess #AIInnovation\\n\\n---\\n\\n**LinkedIn:**\\n\\n🚀 Introducing Orchestrator AI: The Game-Changer for Small Companies! 🚀\\n\\nIn today’s fast-paced world, small businesses need tools that enhance efficiency and innovation without overwhelming resources. Meet Orchestrator AI, your new strategic partner designed specifically with small companies in mind. \\n\\nWhy Choose Orchestrator AI?\\n🔹 Simplified Operations: Streamline your daily tasks and get more done, with less effort.\\n🔹 Smart Insights: Use data-driven strategies to make informed decisions and stay ahead.\\n🔹 Seamless Integration: Enhance current workflows without disrupting them.\\n🔹 Cost-Effective: Tailored solutions that provide maximum value for your investment.\\n\\nJoin the revolution in small business operations! Elevate your company’s performance and stay competitive with Orchestrator AI.\\n\\n👉 Ready to take your company to the next level? Discover more about how Orchestrator AI can empower your business!\\n\\n#OrchestratorAI #SmallBusinessGrowth #AITransformation #Innovation\\n\\n---\\n\\n**Facebook:**\\n\\n🎉 Big News for Small Businesses! 🎉 We’re thrilled to introduce Orchestrator AI – designed just for you! 🚀 Imagine boosting your company's efficiency and innovation effortlessly. With Orchestrator AI, streamline operations, gather smart insights, and achieve more every day.\\n\\nNo more feeling overwhelmed by daily tasks. Our AI solution makes your life easier and helps your business grow. Curious how this can work for you? Let's chat about how Orchestrator AI can be your secret weapon to success! Ready to level up your business game? 💡🌟\\n\\n#SmallBiz #Innovation #OrchestratorAI #AIForYou","assistant",[]]
213	{"id":"1LaQnwqSoTxmnw3Z","name":"Marketing Swarm - Flexible LLM","active":true,"nodes":[{"parameters":{"multipleMethods":false,"httpMethod":"POST","path":"marketing-swarm-flexible","authentication":"none","responseMode":"responseNode","webhookNotice":"","options":{}},"id":"webhook","name":"Webhook","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[-16,304],"webhookId":"marketing-swarm-flex"},{"parameters":{"operation":"call_workflow","outdatedVersionWarning":"","source":"database","workflowId":{"__rl":true,"value":"9jxl03jCcqg17oOy","mode":"id"},"executeWorkflowNotice":"","mode":"once","options":{}},"id":"web-post-task","name":"Web Post Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,144]},{"parameters":{"operation":"call_workflow","outdatedVersionWarning":"","source":"database","workflowId":{"__rl":true,"value":"9jxl03jCcqg17oOy","mode":"id","cachedResultUrl":"/workflow/9jxl03jCcqg17oOy"},"executeWorkflowNotice":"","mode":"once","options":{}},"id":"seo-task","name":"SEO Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,304]},{"parameters":{"operation":"call_workflow","outdatedVersionWarning":"","source":"database","workflowId":{"__rl":true,"value":"9jxl03jCcqg17oOy","mode":"id","cachedResultUrl":"/workflow/9jxl03jCcqg17oOy"},"executeWorkflowNotice":"","mode":"once","options":{}},"id":"social-task","name":"Social Media Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,480]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $('Webhook').item.json.body.statusWebHook }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Webhook').item.json.body.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: 'swarm completed',\\n  message: 'Marketing Swarm workflow completed',\\n  sequence: 4,\\n  totalSteps: 4,\\n  conversationId: $('Webhook').item.json.body.conversationId,\\n  userId: $('WebHook').item.json.userId,\\n}) }}","options":{},"infoMessage":""},"id":"send-final-status","name":"Send Final Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1760,96],"continueOnFail":true},{"parameters":{"generalNotice":"","respondWith":"json","webhookNotice":"","responseBody":"={{ JSON.stringify({\\n  \\"web post\\": $json.webPost,\\n  \\"seo\\": $json.seoContent,\\n  \\"social media\\": $json.socialMedia\\n}) }}","options":{}},"id":"respond","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[1760,240]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}","id":"0e7e1195-46be-4104-ae35-19107420019d"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}","id":"997b9201-041c-4053-81f2-7e1f69ffe070"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}","id":"37100b7a-3727-4855-824f-2725e80d0440"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}","id":"c26c5743-8792-41fc-807a-65cc83a14ca1"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}","id":"f95fd7fb-df93-4dd3-8450-2830ce517fcd"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}","id":"56763026-b467-4e4b-b3fb-7842b63c1caf"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebHook }}","id":"5b5c4d3a-93bf-4f2d-aadf-e31b89a41079"},{"id":"a95859db-69f5-46c2-a895-883b3659deac","name":"systemMessage","value":"You are a social media content strategist. Create engaging social media posts (NOT blog posts) for multiple platforms: Twitter/X (280 chars with hashtags), LinkedIn (professional tone, 1300 chars max), and Facebook (conversational, 500 chars). Focus on hooks, engagement, and platform-specific best practices. Include relevant hashtags and emojis where appropriate.","type":"string"},{"id":"5c7b8969-c60a-42df-b9dc-84849e0f10a2","name":"userMessage","value":"={{ $json.body.announcement }}","type":"string"},{"id":"7b8664d1-0f50-4a1d-ad16-3867967041f8","name":"stepName","value":"Create Social Media","type":"string"},{"id":"291d34dd-2292-4cea-9432-3ae16b054053","name":"sequence","value":"3","type":"string"},{"id":"8cc15d2f-cab2-4691-b5ec-954ded016211","name":"totalSteps","value":"3","type":"string"}]},"includeOtherFields":false,"options":{}},"id":"99b3b396-8e31-444e-aa5e-f652105cf9a7","name":"Social Media","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,480]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}","id":"0e7e1195-46be-4104-ae35-19107420019d"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}","id":"997b9201-041c-4053-81f2-7e1f69ffe070"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}","id":"37100b7a-3727-4855-824f-2725e80d0440"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}","id":"c26c5743-8792-41fc-807a-65cc83a14ca1"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}","id":"f95fd7fb-df93-4dd3-8450-2830ce517fcd"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}","id":"56763026-b467-4e4b-b3fb-7842b63c1caf"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","id":"5b5c4d3a-93bf-4f2d-aadf-e31b89a41079"},{"id":"a95859db-69f5-46c2-a895-883b3659deac","name":"systemMessage","value":"You are an expert SEO specialist. Generate comprehensive SEO-optimized content including: meta title (60 chars max), meta description (155 chars max), 5-10 relevant keywords, H1 heading, and JSON-LD structured data for the given topic. Focus on search intent, readability, and technical SEO best practices.","type":"string"},{"id":"5c7b8969-c60a-42df-b9dc-84849e0f10a2","name":"userMessage","value":"={{ $json.body.announcement }}","type":"string"},{"id":"7b8664d1-0f50-4a1d-ad16-3867967041f8","name":"stepName","value":"Create SEO","type":"string"},{"id":"291d34dd-2292-4cea-9432-3ae16b054053","name":"sequence","value":2,"type":"number"},{"id":"8cc15d2f-cab2-4691-b5ec-954ded016211","name":"totalSteps","value":3,"type":"number"}]},"includeOtherFields":false,"options":{}},"id":"c035862f-b3ef-48e8-b7d3-8226b0a0642a","name":"SEO","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}","id":"0e7e1195-46be-4104-ae35-19107420019d"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}","id":"997b9201-041c-4053-81f2-7e1f69ffe070"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}","id":"37100b7a-3727-4855-824f-2725e80d0440"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}","id":"c26c5743-8792-41fc-807a-65cc83a14ca1"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}","id":"f95fd7fb-df93-4dd3-8450-2830ce517fcd"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}","id":"56763026-b467-4e4b-b3fb-7842b63c1caf"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","id":"5b5c4d3a-93bf-4f2d-aadf-e31b89a41079"},{"id":"a95859db-69f5-46c2-a895-883b3659deac","name":"systemMessage","value":"You are a brilliant blog post writer who specializes in being both entertaining and informative, and you're best known for being able to write posts for all audiences. ","type":"string"},{"id":"5c7b8969-c60a-42df-b9dc-84849e0f10a2","name":"userMessage","value":"={{ $json.body.announcement }}","type":"string"},{"id":"7b8664d1-0f50-4a1d-ad16-3867967041f8","name":"stepName","value":"Write Blog Post","type":"string"},{"id":"291d34dd-2292-4cea-9432-3ae16b054053","name":"sequence","value":1,"type":"number"},{"id":"8cc15d2f-cab2-4691-b5ec-954ded016211","name":"totalSteps","value":3,"type":"number"}]},"includeOtherFields":false,"options":{}},"id":"extract-config","name":"Web Post","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,144]},{"parameters":{"mode":"append","numberInputs":3},"type":"n8n-nodes-base.merge","typeVersion":3.2,"position":[1264,224],"id":"9a602287-8e53-45f0-a320-517acc8c7912","name":"Merge"},{"parameters":{"mode":"runOnceForAllItems","language":"javaScript","jsCode":"// Get all 3 items from the merge\\nconst items = $input.all();\\n\\n// Combine them into a single object\\nreturn [{\\n  json: {\\n    webPost: items[0].json.text,\\n    seoContent: items[1].json.text,\\n    socialMedia: items[2].json.text\\n  }\\n}];","notice":""},"type":"n8n-nodes-base.code","typeVersion":2,"position":[1520,240],"id":"df59f646-cdbe-4d71-b958-db6a17c2d003","name":"Code in JavaScript"}],"connections":{"Webhook":{"main":[[{"node":"Web Post","type":"main","index":0},{"node":"SEO","type":"main","index":0},{"node":"Social Media","type":"main","index":0}]]},"Web Post Task":{"main":[[{"node":"Merge","type":"main","index":0}]]},"SEO Task":{"main":[[{"node":"Merge","type":"main","index":1}]]},"Social Media Task":{"main":[[{"node":"Merge","type":"main","index":2}]]},"Send Final Status":{"main":[[]]},"Social Media":{"main":[[{"node":"Social Media Task","type":"main","index":0}]]},"SEO":{"main":[[{"node":"SEO Task","type":"main","index":0}]]},"Web Post":{"main":[[{"node":"Web Post Task","type":"main","index":0}]]},"Merge":{"main":[[{"node":"Code in JavaScript","type":"main","index":0}]]},"Code in JavaScript":{"main":[[{"node":"Respond to Webhook","type":"main","index":0},{"node":"Send Final Status","type":"main","index":0}]]}},"settings":{},"staticData":{},"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3"},{},{"runData":"4","pinData":"5","lastNodeExecuted":"6"},{"contextData":"7","nodeExecutionStack":"8","waitingExecution":"9","waitingExecutionSource":"10"},{"Webhook":"11","Web Post":"12","SEO":"13","Social Media":"14","Web Post Task":"15","SEO Task":"16","Social Media Task":"17","Merge":"18","Code in JavaScript":"19","Respond to Webhook":"20","Send Final Status":"21"},{},"Send Final Status",{},[],{},{},["22"],["23"],["24"],["25"],["26"],["27"],["28"],["29"],["30"],["31"],["32"],{"startTime":1760382164452,"executionIndex":0,"source":"33","hints":"34","executionTime":0,"executionStatus":"35","data":"36"},{"startTime":1760382164452,"executionIndex":1,"source":"37","hints":"38","executionTime":3,"executionStatus":"35","data":"39"},{"startTime":1760382164456,"executionIndex":2,"source":"40","hints":"41","executionTime":1,"executionStatus":"35","data":"42"},{"startTime":1760382164457,"executionIndex":3,"source":"43","hints":"44","executionTime":1,"executionStatus":"35","data":"45"},{"startTime":1760382164458,"executionIndex":4,"source":"46","hints":"47","executionTime":21618,"metadata":"48","executionStatus":"35","data":"49"},{"startTime":1760382186077,"executionIndex":5,"source":"50","hints":"51","executionTime":7929,"metadata":"52","executionStatus":"35","data":"53"},{"startTime":1760382194007,"executionIndex":6,"source":"54","hints":"55","executionTime":9660,"metadata":"56","executionStatus":"35","data":"57"},{"startTime":1760382203668,"executionIndex":7,"source":"58","hints":"59","executionTime":0,"executionStatus":"35","data":"60"},{"startTime":1760382203668,"executionIndex":8,"source":"61","hints":"62","executionTime":5,"executionStatus":"35","data":"63"},{"startTime":1760382203674,"executionIndex":9,"source":"64","hints":"65","executionTime":4,"executionStatus":"35","data":"66"},{"startTime":1760382203678,"executionIndex":10,"source":"67","hints":"68","executionTime":2,"executionStatus":"35","data":"69"},[],[],"success",{"main":"70"},["71"],[],{"main":"72"},["73"],[],{"main":"74"},["75"],[],{"main":"76"},["77"],[],{"subExecution":"78","subExecutionsCount":1},{"main":"79"},["80"],[],{"subExecution":"81","subExecutionsCount":1},{"main":"82"},["83"],[],{"subExecution":"84","subExecutionsCount":1},{"main":"85"},["86","87","88"],[],{"main":"89"},["90"],[],{"main":"91"},["92"],[],{"main":"93"},["94"],[],{"main":"95"},["96"],{"previousNode":"97"},["98"],{"previousNode":"97"},["99"],{"previousNode":"97"},["100"],{"previousNode":"101"},{"executionId":"102","workflowId":"103"},["104"],{"previousNode":"105"},{"executionId":"106","workflowId":"103"},["107"],{"previousNode":"108"},{"executionId":"109","workflowId":"103"},["110"],{"previousNode":"111"},{"previousNode":"112"},{"previousNode":"113"},["114"],{"previousNode":"115"},["116"],{"previousNode":"117"},["118"],{"previousNode":"117"},["119"],["120"],"Webhook",["121"],["122"],["123"],"Web Post","214","9jxl03jCcqg17oOy",["124"],"SEO","215",["125"],"Social Media","216",["126"],"Web Post Task","SEO Task","Social Media Task",["127","128","129"],"Merge",["130"],"Code in JavaScript",["131"],["132"],{"json":"133","pairedItem":"134"},{"json":"135","pairedItem":"136"},{"json":"137","pairedItem":"138"},{"json":"139","pairedItem":"140"},{"json":"141","pairedItem":"142"},{"json":"143","pairedItem":"144"},{"json":"145","pairedItem":"146"},{"json":"141","pairedItem":"147"},{"json":"143","pairedItem":"148"},{"json":"145","pairedItem":"149"},{"json":"150"},{"json":"150","pairedItem":"151"},{"json":"152","pairedItem":"153"},{"headers":"154","params":"155","query":"156","body":"157","webhookUrl":"158","executionMode":"159"},{"item":0},{"provider":"160","model":"161","announcement":"162","taskId":"163","conversationId":"164","userId":"165","statusWebhook":"166","systemMessage":"167","userMessage":"162","stepName":"168","sequence":1,"totalSteps":3},{"item":0},{"provider":"160","model":"161","announcement":"162","taskId":"163","conversationId":"164","userId":"165","statusWebhook":"166","systemMessage":"169","userMessage":"162","stepName":"170","sequence":2,"totalSteps":3},{"item":0},{"provider":"160","model":"161","announcement":"162","taskId":"163","conversationId":"164","userId":"165","statusWebhook":"166","systemMessage":"171","userMessage":"162","stepName":"172","sequence":"173","totalSteps":"173"},{"item":0},{"text":"174","provider":"160","model":"161"},{"item":0},{"text":"175","provider":"160","model":"161"},{"item":0},{"text":"176","provider":"160","model":"161"},{"item":0},{"item":0},{"item":0,"input":1},{"item":0,"input":2},{"webPost":"174","seoContent":"175","socialMedia":"176"},{"item":0},{"error":"177"},{"item":0},{"content-type":"178","user-agent":"179","accept":"180","cache-control":"181","postman-token":"182","host":"183","accept-encoding":"184","connection":"185","content-length":"186"},{},{},{"taskId":"163","conversationId":"164","userId":"165","announcement":"162","statusWebHook":"166","provider":"160","model":"161"},"http://localhost:5678/webhook-test/marketing-swarm-flexible","test","openai","gpt-4o","We'd like to announce our new product Orchestrator AI for Small Companies!","a1b2c3d4-5e6f-7890-abcd-ef1234567890","c6d7e8f9-0a1b-2c3d-4e5f-678901234567","u5e6f7a8-9b0c-1d2e-3f4a-567890123456","http://host.docker.internal:7100/webhooks/status","You are a brilliant blog post writer who specializes in being both entertaining and informative, and you're best known for being able to write posts for all audiences. ","Write Blog Post","You are an expert SEO specialist. Generate comprehensive SEO-optimized content including: meta title (60 chars max), meta description (155 chars max), 5-10 relevant keywords, H1 heading, and JSON-LD structured data for the given topic. Focus on search intent, readability, and technical SEO best practices.","Create SEO","You are a social media content strategist. Create engaging social media posts (NOT blog posts) for multiple platforms: Twitter/X (280 chars with hashtags), LinkedIn (professional tone, 1300 chars max), and Facebook (conversational, 500 chars). Focus on hooks, engagement, and platform-specific best practices. Include relevant hashtags and emojis where appropriate.","Create Social Media","3","**Introducing Orchestrator AI: The Maestro of Success for Small Companies!**\\n\\n🎉 Drumroll, please! 🎉 The business world is ablaze with excitement as we unveil our latest masterpiece – Orchestrator AI for Small Companies! This isn't just another tech tool; it's your new co-pilot in the thrilling journey of your business adventure.\\n\\n**Small Giants, Meet Your Symphony Conductor**\\n\\nImagine your business as a magnificent orchestra. Your team members are the talented musicians, each with their unique skills and instruments. Until now, coordinating all these gifted individuals required the virtuoso expertise of a seasoned conductor. Enter Orchestrator AI, a masterful blend of innovation and automation, poised to conduct your business symphony with precision and flair.\\n\\n**Why Orchestrator AI?**\\n\\n1. **Tailored for Small Companies**: We've crafted Orchestrator AI with the small business owner in mind. Whether you run a cozy café, a bustling boutique, or a nimble tech startup, our AI understands your scale and speaks your language.\\n\\n2. **Efficiency Extraordinaire**: Ditch the chaos and embrace clarity! Orchestrator AI organizes your tasks, optimizes your processes, and manages time so efficiently, you'll wonder how you ever lived without it.\\n\\n3. **Insightful Analytics**: Gone are the days of making decisions in the dark. Our AI provides crystal-clear insights, drawing from the depths of your data to guide your strategies with unwavering accuracy.\\n\\n4. **Growth Partner**: This isn’t just about surviving – it's about thriving. Orchestrator AI is designed to scale with your dreams, ensuring that whether you're serving 10 clients or 10,000, you're primed for success.\\n\\n5. **Cost-Conscious Genius**: Worried about breaking the bank? Breathe easy. Orchestrator AI offers powerful capabilities on a budget that respects your financial boundaries.\\n\\n**How it Works:**\\n\\nUnleashing the potential of Orchestrator AI is as simple as a walk in the park:\\n\\n- **Integration Made Easy**: Our seamless integration process means you can start orchestrating your business brilliance in no time. No need for a Ph.D. in tech jargon.\\n\\n- **Learn, Adapt, Succeed**: Equipped with machine learning, our AI evolves alongside your business, picking up on patterns and fine-tuning its capabilities to offer even more refined guidance.\\n\\n- **Stay Ahead of the Curve**: The business landscape is dynamic, and so is Orchestrator AI. With regular updates and enhancements, you're guaranteed to always be a step ahead.\\n\\n**What Sets Us Apart?**\\n\\nThere are plenty of tools out there that promise to revolutionize your business. But Orchestrator AI doesn't just promise; it delivers a transformative experience wrapped in a user-friendly package, ensuring you spend less time managing and more time celebrating successes.\\n\\n**The Final Crescendo**\\n\\nSo, dear visionary entrepreneur, are you ready to hand over the baton to Orchestrator AI? Prepare to witness your operations transform into an elegant ballet of efficiency, creativity, and success. Get ready to dazzle your audience – the world is your stage!\\n\\nStay tuned for our launch event, where we’ll showcase Orchestrator AI in action and provide exclusive offers for early adopters. Your ticket to creating a harmonious business future awaits!\\n\\n**Hit that \\"Contact Us\\" button and let's start orchestrating your business symphony today!**\\n\\nStay harmonious,\\nThe Orchestrator AI Team 🌟","Meta Title:  \\nOrchestrator AI for Small Companies - Transform Your Business\\n\\nMeta Description:  \\nDiscover how Orchestrator AI helps small businesses streamline operations, boost efficiency, and drive growth with innovative digital solutions.\\n\\nKeywords:  \\nOrchestrator AI, AI for small companies, small business AI, operational efficiency, business automation, AI solutions, digital transformation, innovative tech, business growth\\n\\nH1 Heading:  \\nRevolutionize Your Business Operations with Orchestrator AI for Small Companies\\n\\nJSON-LD Structured Data:  \\n```json\\n{\\n  \\"@context\\": \\"https://schema.org\\",\\n  \\"@type\\": \\"Product\\",\\n  \\"name\\": \\"Orchestrator AI for Small Companies\\",\\n  \\"description\\": \\"Orchestrator AI helps small businesses streamline operations, boost efficiency, and drive growth with innovative digital solutions.\\",\\n  \\"brand\\": {\\n    \\"@type\\": \\"Organization\\",\\n    \\"name\\": \\"Orchestrator AI\\"\\n  },\\n  \\"offers\\": {\\n    \\"@type\\": \\"Offer\\",\\n    \\"url\\": \\"https://www.orchestratorai.com/products/small-companies\\",\\n    \\"priceCurrency\\": \\"USD\\",\\n    \\"availability\\": \\"https://schema.org/InStock\\"\\n  },\\n  \\"audience\\": {\\n    \\"@type\\": \\"Audience\\",\\n    \\"audienceType\\": \\"SmallBusiness\\"\\n  },\\n  \\"potentialAction\\": {\\n    \\"@type\\": \\"ConsumeAction\\",\\n    \\"target\\": {\\n      \\"@type\\": \\"EntryPoint\\",\\n      \\"urlTemplate\\": \\"https://www.orchestratorai.com\\"\\n    }\\n  }\\n}\\n```\\n\\nThis SEO-optimized content is crafted to ensure that users searching for AI solutions for small businesses can easily discover how Orchestrator AI can maximize their operational efficiency and drive business growth. The structured data further aids search engines in understanding the context of the product, potentially enhancing visibility in search results.","**Twitter/X:**\\n\\n🎉 Exciting News for Small Businesses! 🎉 Introducing Orchestrator AI - your new partner in boosting efficiency and innovation. Ready to revolutionize your operations and streamline success? 🌟 Learn more! 🚀 #OrchestratorAI #SmallBizSuccess #AIInnovation\\n\\n---\\n\\n**LinkedIn:**\\n\\n🚀 Introducing Orchestrator AI: The Game-Changer for Small Companies! 🚀\\n\\nIn today’s fast-paced world, small businesses need tools that enhance efficiency and innovation without overwhelming resources. Meet Orchestrator AI, your new strategic partner designed specifically with small companies in mind. \\n\\nWhy Choose Orchestrator AI?\\n🔹 Simplified Operations: Streamline your daily tasks and get more done, with less effort.\\n🔹 Smart Insights: Use data-driven strategies to make informed decisions and stay ahead.\\n🔹 Seamless Integration: Enhance current workflows without disrupting them.\\n🔹 Cost-Effective: Tailored solutions that provide maximum value for your investment.\\n\\nJoin the revolution in small business operations! Elevate your company’s performance and stay competitive with Orchestrator AI.\\n\\n👉 Ready to take your company to the next level? Discover more about how Orchestrator AI can empower your business!\\n\\n#OrchestratorAI #SmallBusinessGrowth #AITransformation #Innovation\\n\\n---\\n\\n**Facebook:**\\n\\n🎉 Big News for Small Businesses! 🎉 We’re thrilled to introduce Orchestrator AI – designed just for you! 🚀 Imagine boosting your company's efficiency and innovation effortlessly. With Orchestrator AI, streamline operations, gather smart insights, and achieve more every day.\\n\\nNo more feeling overwhelmed by daily tasks. Our AI solution makes your life easier and helps your business grow. Curious how this can work for you? Let's chat about how Orchestrator AI can be your secret weapon to success! Ready to level up your business game? 💡🌟\\n\\n#SmallBiz #Innovation #OrchestratorAI #AIForYou","Paired item data for item from node 'Code in JavaScript' is unavailable. Ensure 'Code in JavaScript' is providing the required output.","application/json","PostmanRuntime/7.48.0","*/*","no-cache","34eea584-ff25-4bc0-8ff4-cc69c9a190a8","localhost:5678","gzip, deflate, br","keep-alive","392"]
211	{"id":"9jxl03jCcqg17oOy","name":"Helper: LLM Task","active":false,"isArchived":false,"createdAt":"2025-10-08T18:29:22.544Z","updatedAt":"2025-10-11T06:27:38.143Z","nodes":[{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || \\"http://host.docker.internal:7100/webhooks/status\\"}}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $json.taskId,\\n  status: 'running',\\n  timestamp: new Date().toISOString(),\\n  step: $json.stepName,\\n  message: `Starting ${$json.stepName || 'task'}`,\\n  sequence: $json.sequence,\\n  totalSteps: $json.totalSteps,\\n  conversationId: $json.conversationId,\\n  userId: $json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-start-status","name":"Send Start Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[288,176],"continueOnFail":true},{"parameters":{"mode":"rules","rules":{"values":[{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"leftValue":"={{ $json.provider }}","rightValue":"openai","operator":{"type":"string","operation":"equals"},"id":"a1593526-252b-40e7-b755-414c0363680d"}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"46d844e4-2f30-44cb-87c6-618ed4c789d3","leftValue":"={{ $json.provider }}","rightValue":"ollama","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"9331fc1c-d594-4900-81b6-89021334541c","leftValue":"=  {{ $json.provider }}","rightValue":"anthropic","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"},"renameOutput":false}]},"options":{"fallbackOutput":0}},"id":"select-provider","name":"Select Provider","type":"n8n-nodes-base.switch","typeVersion":3,"position":[256,432]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"https://api.anthropic.com/v1/messages","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Trigger').item.json.model || 'claude-3-sonnet-20240229',\\\\n  messages: [{ role: 'user', content: $('Trigger').item.json.prompt }],\\\\n  temperature: $('Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{},"infoMessage":""},"id":"anthropic-request","name":"Anthropic Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[576,512]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.message.content }}","id":"30f4cc34-cbec-4fca-8b91-e20aa43ddd65"},{"name":"provider","type":"string","value":"openai","id":"541ecad6-3b94-4836-96b0-b9781b984082"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"60f6d0c1-0884-4c00-bacc-53c73c86c2c2"}]},"includeOtherFields":false,"options":{}},"id":"normalize-openai","name":"Normalize OpenAI","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,112]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.output }}","id":"926dda93-2e9e-4dfc-8bc0-117cdd7411ec"},{"name":"provider","type":"string","value":"ollama","id":"e3f38e7d-5f10-4f83-93e4-a07d98b0d9ec"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"97cf8ec6-5dfd-422c-b9ff-834a7af9af05"},{"name":"usage","type":"object","value":"={{ { prompt_tokens: $json.prompt_eval_count, completion_tokens: $json.eval_count } }}","id":"13a20d07-fc9f-4bac-aec5-98f4007f2b27"}]},"includeOtherFields":false,"options":{}},"id":"normalize-ollama","name":"Normalize Ollama","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,304]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.content[0].text }}"},{"name":"provider","type":"string","value":"anthropic"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"includeOtherFields":false,"options":{}},"id":"normalize-anthropic","name":"Normalize Anthropic","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,528]},{"parameters":{"preBuiltAgentsCalloutHttpRequest":"","curlImport":"","method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","authentication":"none","provideSslCertificates":false,"sendQuery":false,"sendHeaders":false,"sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Edit Fields').item.json.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: $('Edit Fields').item.json.stepName,\\n  message: `Completed ${$('Edit Fields').item.json.stepName || 'task'}`,\\n  sequence: $('Edit Fields').item.json.sequence,\\n  totalSteps: $('Edit Fields').item.json.totalSteps,\\n  conversationId: $('Edit Fields').item.json.conversationId,\\n  userId: $('Edit Fields').item.json.userId\\n}) }}","options":{},"infoMessage":""},"id":"send-end-status","name":"Send End Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1584,224],"continueOnFail":true},{"parameters":{"events":"worklfow_call","notice":"","outdatedVersionWarning":""},"id":"execute-workflow-trigger","name":"Trigger","type":"n8n-nodes-base.executeWorkflowTrigger","typeVersion":1,"position":[-144,400]},{"parameters":{"mode":"manual","duplicateItem":false,"assignments":{"assignments":[{"id":"12f8c18a-7b6e-4614-85bf-229053383b5c","name":"taskId","value":"={{ $json.taskId }}","type":"string"},{"id":"9028a85d-49ec-4801-a5a4-2d69221316ab","name":"conversationId","value":"={{ $json.conversationId}}","type":"string"},{"id":"3ff69eae-d1d9-4914-bc6b-373025caf3cd","name":"userId","value":"={{ $json.userId }}","type":"string"},{"id":"56ff3fd3-baf6-47c6-9d39-ac0b0ee08fe1","name":"provider","value":"={{ $json.provider }}","type":"string"},{"id":"ccff1938-95b6-4aa9-a5c2-920db7438e80","name":"model","value":"={{ $json.model }}","type":"string"},{"id":"78a2244a-5425-45ee-8aa2-b1fe99b5148d","name":"systemMessage","value":"={{ $json.systemMessage }}","type":"string"},{"id":"8e5dd07f-7174-48d1-b8e9-88e1d14ee329","name":"userMessage","value":"={{ $json.userMessage }}","type":"string"},{"id":"caaafbf9-3b3f-4af7-a781-5a4777759fe5","name":"stepName","value":"={{ $json.stepName }} ","type":"string"},{"id":"61b1529b-9cb1-4b73-b469-b835fc78767a","name":"sequence","value":"={{ $json.sequence }}","type":"number"},{"id":"c5163f91-4647-4a7c-b7b7-346abb4acb25","name":"statusWebhook","value":"={{ $json.statusWebhook }}","type":"string"},{"id":"3f34c0ff-db77-42a1-9d41-90abe27a1150","name":"=totalSteps","value":"={{ $json.totalSteps }}","type":"number"}]},"includeOtherFields":false,"options":{}},"type":"n8n-nodes-base.set","typeVersion":3.4,"position":[96,288],"id":"81c83945-6bd0-41bb-9a6d-7c8eb2db9338","name":"Edit Fields"},{"parameters":{},"type":"n8n-nodes-base.noOp","typeVersion":1,"position":[1584,384],"id":"9d553c6b-ecae-4157-acf2-c5d6dff83eaa","name":"No Operation, do nothing"},{"parameters":{"notice":"","model":"llama3.2","options":{}},"type":"@n8n/n8n-nodes-langchain.lmChatOllama","typeVersion":1,"position":[928,400],"id":"84dbc11a-2747-4d17-ab88-d368279feb87","name":"Ollama Chat Model","credentials":{"ollamaApi":{"id":"hz52TIdzOn7p9IzY","name":"Ollama account"}}},{"parameters":{"resource":"text","operation":"message","modelId":{"__rl":true,"value":"={{ $json.model }}","mode":"id"},"messages":{"values":[{"content":"={{ $json['userMessage'] }}","role":"user"},{"content":"={{ $json['systemMessage'] }}","role":"system"}]},"simplify":true,"jsonOutput":false,"hideTools":"hide","options":{}},"type":"@n8n/n8n-nodes-langchain.openAi","typeVersion":1.8,"position":[576,112],"id":"0f6dbcf1-2458-4881-8c32-a4619529064e","name":"OpenAI","credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"aiAgentStarterCallout":"","preBuiltAgentsCallout":"","promptType":"define","text":"={{ $json['userMessage'] }}","hasOutputParser":false,"needsFallback":false,"options":{"systemMessage":"={{ $json['systemMessage'] }}"}},"type":"@n8n/n8n-nodes-langchain.agent","typeVersion":2.2,"position":[576,288],"id":"9ad2d867-3295-49ee-bfe9-d5641c47dcf1","name":"Ollama"},{"parameters":{"mode":"runOnceForAllItems","language":"javaScript","jsCode":"console.log('Received data:', JSON.stringify($input.all(), null, 2));\\nreturn $input.all();","notice":""},"type":"n8n-nodes-base.code","typeVersion":2,"position":[16,560],"id":"09f5c425-7ea8-45e3-82f2-55e072314d39","name":"Code in JavaScript"}],"connections":{"Send Start Status":{"main":[[]]},"Select Provider":{"main":[[{"node":"OpenAI","type":"main","index":0}],[{"node":"Ollama","type":"main","index":0}],[{"node":"Anthropic Request","type":"main","index":0}],[],[]]},"Anthropic Request":{"main":[[{"node":"Normalize Anthropic","type":"main","index":0}]]},"Normalize OpenAI":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Ollama":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Anthropic":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Trigger":{"main":[[{"node":"Edit Fields","type":"main","index":0},{"node":"Code in JavaScript","type":"main","index":0}]]},"Edit Fields":{"main":[[{"node":"Send Start Status","type":"main","index":0},{"node":"Select Provider","type":"main","index":0}]]},"Ollama Chat Model":{"ai_languageModel":[[{"node":"Ollama","type":"ai_languageModel","index":0}]]},"OpenAI":{"main":[[{"node":"Normalize OpenAI","type":"main","index":0}]]},"Ollama":{"main":[[{"node":"Normalize Ollama","type":"main","index":0}]]}},"settings":{},"staticData":null,"pinData":{}}	[{"startData":"1","resultData":"2","executionData":"3","parentExecution":"4"},{},{"runData":"5","lastNodeExecuted":"6"},{"contextData":"7","metadata":"8","nodeExecutionStack":"9","waitingExecution":"10","waitingExecutionSource":"11"},{"executionId":"12","workflowId":"13"},{"Trigger":"14","Edit Fields":"15","Code in JavaScript":"16","Send Start Status":"17","Select Provider":"18","OpenAI":"19","Normalize OpenAI":"20","Send End Status":"21","No Operation, do nothing":"22"},"No Operation, do nothing",{},{},[],{},{},"209","1LaQnwqSoTxmnw3Z",["23"],["24"],["25"],["26"],["27"],["28"],["29"],["30"],["31"],{"startTime":1760382111692,"executionIndex":0,"source":"32","hints":"33","executionTime":0,"metadata":"34","executionStatus":"35","data":"36"},{"startTime":1760382111692,"executionIndex":1,"source":"37","hints":"38","executionTime":2,"executionStatus":"35","data":"39"},{"startTime":1760382111694,"executionIndex":2,"source":"40","hints":"41","executionTime":4,"executionStatus":"35","data":"42"},{"startTime":1760382111698,"executionIndex":3,"source":"43","hints":"44","executionTime":5,"executionStatus":"35","data":"45"},{"startTime":1760382111703,"executionIndex":4,"source":"46","hints":"47","executionTime":0,"executionStatus":"35","data":"48"},{"startTime":1760382111704,"executionIndex":5,"source":"49","hints":"50","executionTime":5449,"executionStatus":"35","data":"51"},{"startTime":1760382117153,"executionIndex":6,"source":"52","hints":"53","executionTime":1,"executionStatus":"35","data":"54"},{"startTime":1760382117154,"executionIndex":7,"source":"55","hints":"56","executionTime":25,"executionStatus":"35","data":"57"},{"startTime":1760382117179,"executionIndex":8,"source":"58","hints":"59","executionTime":0,"executionStatus":"35","data":"60"},[],[],{"parentExecution":"4"},"success",{"main":"61"},["62"],[],{"main":"63"},["64"],[],{"main":"65"},["66"],[],{"main":"67"},["68"],[],{"main":"69"},["70"],[],{"main":"71"},["72"],[],{"main":"73"},["74"],[],{"main":"75"},["76"],[],{"main":"77"},["78"],{"previousNode":"79"},["80"],{"previousNode":"79"},["81"],{"previousNode":"82"},["83"],{"previousNode":"82"},["84","85","86"],{"previousNode":"87"},["88"],{"previousNode":"89"},["90"],{"previousNode":"91"},["92"],{"previousNode":"91"},["93"],["94"],"Trigger",["95"],["96"],"Edit Fields",["97"],["98"],[],[],"Select Provider",["99"],"OpenAI",["100"],"Normalize OpenAI",["101"],["102"],{"json":"103","index":0,"pairedItem":"104"},{"json":"105","pairedItem":"106"},{"json":"107","index":0,"pairedItem":"108"},{"json":"109","pairedItem":"110"},{"json":"105","pairedItem":"111"},{"json":"112","pairedItem":"113"},{"json":"114","pairedItem":"115"},{"json":"116","pairedItem":"117"},{"json":"114","pairedItem":"118"},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":2,"totalSteps":3},{"item":0},{"taskId":"122","conversationId":"123","userId":"124","provider":"119","model":"120","systemMessage":"126","userMessage":"121","stepName":"128","sequence":2,"statusWebhook":"125","totalSteps":3},{"item":0},{"provider":"119","model":"120","announcement":"121","taskId":"122","conversationId":"123","userId":"124","statusWebhook":"125","systemMessage":"126","userMessage":"121","stepName":"127","sequence":2,"totalSteps":3},{"item":0},{},{"item":0},{"item":0},{"index":0,"message":"129","logprobs":null,"finish_reason":"130"},{"item":0},{"text":"131","provider":"119","model":"120"},{"item":0},{},{"item":0},{"item":0},"openai","gpt-4o","We'd like to announce our new product Orchestrator AI for Small Companies!","a1b2c3d4-5e6f-7890-abcd-ef1234567890","c6d7e8f9-0a1b-2c3d-4e5f-678901234567","u5e6f7a8-9b0c-1d2e-3f4a-567890123456","http://host.docker.internal:7100/webhooks/status","You are an expert SEO specialist. Generate comprehensive SEO-optimized content including: meta title (60 chars max), meta description (155 chars max), 5-10 relevant keywords, H1 heading, and JSON-LD structured data for the given topic. Focus on search intent, readability, and technical SEO best practices.","Create SEO","Create SEO ",{"role":"132","content":"131","refusal":null,"annotations":"133"},"stop","**Meta Title:**  \\nOrchestrator AI for Small Businesses | Transform Your Company\\n\\n**Meta Description:**  \\nDiscover Orchestrator AI, designed to empower small businesses with innovative solutions for growth, efficiency, and success. Boost your company's potential today!\\n\\n**Keywords:**  \\nOrchestrator AI, small business AI, AI solutions for companies, business automation, AI technology, small company growth, business efficiency, artificial intelligence\\n\\n**H1 Heading:**  \\nIntroducing Orchestrator AI: The Ultimate AI Solution for Small Companies\\n\\n**JSON-LD Structured Data:**\\n\\n```json\\n{\\n  \\"@context\\": \\"https://schema.org\\",\\n  \\"@type\\": \\"Product\\",\\n  \\"name\\": \\"Orchestrator AI\\",\\n  \\"description\\": \\"Orchestrator AI is an innovative product designed to empower small businesses with advanced AI solutions, enhancing growth, efficiency, and operational success.\\",\\n  \\"brand\\": {\\n    \\"@type\\": \\"Brand\\",\\n    \\"name\\": \\"Orchestrator AI\\"\\n  },\\n  \\"offers\\": {\\n    \\"@type\\": \\"Offer\\",\\n    \\"url\\": \\"https://www.yourwebsite.com/orchestrator-ai\\",\\n    \\"priceCurrency\\": \\"USD\\",\\n    \\"availability\\": \\"https://schema.org/InStock\\"\\n  },\\n  \\"productID\\": \\"OAIS-001\\",\\n  \\"category\\": \\"https://schema.org/SoftwareApplication\\",\\n  \\"additionalType\\": \\"https://schema.org/AIApplication\\",\\n  \\"audience\\": {\\n    \\"@type\\": \\"Audience\\",\\n    \\"audienceType\\": \\"Small Business Owners\\"\\n  },\\n  \\"mainEntityOfPage\\": {\\n    \\"@type\\": \\"WebPage\\",\\n    \\"@id\\": \\"https://www.yourwebsite.com/orchestrator-ai\\"\\n  }\\n}\\n```\\n\\n**Content Recommendations:**\\n\\n1. **Introduction:** Start with a captivating introduction about the challenges faced by small businesses and how Orchestrator AI is designed to meet those challenges with precision and innovation.\\n\\n2. **Features and Benefits:** Detail the core features of Orchestrator AI and explain how each one can benefit small businesses. Use bullet points or numbered lists for clarity and readability.\\n\\n3. **Use Cases:** Provide specific examples or case studies of how Orchestrator AI has helped small companies automate processes, increase efficiency, and drive growth.\\n\\n4. **Call to Action:** End with a strong call to action, encouraging readers to visit the product page, sign up for a demo, or contact a sales representative for more information.\\n\\n5. **Visuals and Media:** Incorporate high-quality images and video demonstrations to visually communicate the capabilities and advantages of Orchestrator AI.  \\n\\nBy implementing these content guidelines alongside the technical SEO elements provided, you can effectively enhance the visibility and engagement of the Orchestrator AI product announcement.","assistant",[]]
\.


--
-- TOC entry 4346 (class 0 OID 18353)
-- Dependencies: 328
-- Data for Name: execution_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_entity (id, finished, mode, "retryOf", "retrySuccessId", "startedAt", "stoppedAt", "waitTill", status, "workflowId", "deletedAt", "createdAt") FROM stdin;
211	t	integrated	\N	\N	2025-10-13 19:01:51.689+00	2025-10-13 19:01:57.179+00	\N	success	9jxl03jCcqg17oOy	2025-10-27 19:49:09.582+00	2025-10-13 19:01:51.683+00
215	t	integrated	\N	\N	2025-10-13 19:03:06.152+00	2025-10-13 19:03:13.984+00	\N	success	9jxl03jCcqg17oOy	2025-10-27 19:49:09.582+00	2025-10-13 19:03:06.121+00
210	t	integrated	\N	\N	2025-10-13 19:01:33.249+00	2025-10-13 19:01:51.664+00	\N	success	9jxl03jCcqg17oOy	2025-10-27 19:49:09.582+00	2025-10-13 19:01:33.242+00
212	f	integrated	\N	\N	2025-10-13 19:01:57.214+00	2025-10-13 19:01:57.767+00	\N	error	9jxl03jCcqg17oOy	2025-10-27 19:49:09.582+00	2025-10-13 19:01:57.204+00
209	f	manual	\N	\N	2025-10-13 19:01:33.221+00	2025-10-13 19:01:57.778+00	\N	error	1LaQnwqSoTxmnw3Z	2025-10-27 19:49:09.582+00	2025-10-13 19:01:33.201+00
214	t	integrated	\N	\N	2025-10-13 19:02:44.473+00	2025-10-13 19:03:06.015+00	\N	success	9jxl03jCcqg17oOy	2025-10-27 19:49:09.582+00	2025-10-13 19:02:44.466+00
216	t	integrated	\N	\N	2025-10-13 19:03:14.031+00	2025-10-13 19:03:23.657+00	\N	success	9jxl03jCcqg17oOy	2025-10-27 19:49:09.582+00	2025-10-13 19:03:14.019+00
213	t	manual	\N	\N	2025-10-13 19:02:44.446+00	2025-10-13 19:03:23.68+00	\N	success	1LaQnwqSoTxmnw3Z	2025-10-27 19:49:09.582+00	2025-10-13 19:02:44.423+00
\.


--
-- TOC entry 4348 (class 0 OID 18360)
-- Dependencies: 330
-- Data for Name: execution_metadata; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.execution_metadata (id, "executionId", key, value) FROM stdin;
\.


--
-- TOC entry 4350 (class 0 OID 18366)
-- Dependencies: 332
-- Data for Name: folder; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.folder (id, name, "parentFolderId", "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4351 (class 0 OID 18371)
-- Dependencies: 333
-- Data for Name: folder_tag; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.folder_tag ("folderId", "tagId") FROM stdin;
\.


--
-- TOC entry 4352 (class 0 OID 18374)
-- Dependencies: 334
-- Data for Name: insights_by_period; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.insights_by_period (id, "metaId", type, value, "periodUnit", "periodStart") FROM stdin;
1	1	1	49	0	2025-10-10 13:00:00+00
2	1	3	2	0	2025-10-10 13:00:00+00
3	1	1	97	0	2025-10-10 19:00:00+00
4	1	3	2	0	2025-10-10 19:00:00+00
5	2	2	1	0	2025-10-11 06:00:00+00
6	2	1	18572	0	2025-10-11 06:00:00+00
\.


--
-- TOC entry 4354 (class 0 OID 18379)
-- Dependencies: 336
-- Data for Name: insights_metadata; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.insights_metadata ("metaId", "workflowId", "projectId", "workflowName", "projectName") FROM stdin;
1	Q08T7oMX2dZslqV4	\N	Marketing Swarm - Major Announcement	Golfer Geek <golfergeek@orchestratorai.io>
2	1LaQnwqSoTxmnw3Z	\N	Marketing Swarm - Flexible LLM	Golfer Geek <golfergeek@orchestratorai.io>
\.


--
-- TOC entry 4356 (class 0 OID 18383)
-- Dependencies: 338
-- Data for Name: insights_raw; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.insights_raw (id, "metaId", type, value, "timestamp") FROM stdin;
\.


--
-- TOC entry 4358 (class 0 OID 18388)
-- Dependencies: 340
-- Data for Name: installed_nodes; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.installed_nodes (name, type, "latestVersion", package) FROM stdin;
\.


--
-- TOC entry 4359 (class 0 OID 18394)
-- Dependencies: 341
-- Data for Name: installed_packages; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.installed_packages ("packageName", "installedVersion", "authorName", "authorEmail", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4360 (class 0 OID 18399)
-- Dependencies: 342
-- Data for Name: invalid_auth_token; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.invalid_auth_token (token, "expiresAt") FROM stdin;
\.


--
-- TOC entry 4361 (class 0 OID 18404)
-- Dependencies: 343
-- Data for Name: migration_metadata; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.migration_metadata (migration_file, source, workflow_id, notes, applied_at) FROM stdin;
\.


--
-- TOC entry 4362 (class 0 OID 18410)
-- Dependencies: 344
-- Data for Name: migrations; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.migrations (id, "timestamp", name) FROM stdin;
1	1587669153312	InitialMigration1587669153312
2	1589476000887	WebhookModel1589476000887
3	1594828256133	CreateIndexStoppedAt1594828256133
4	1607431743768	MakeStoppedAtNullable1607431743768
5	1611144599516	AddWebhookId1611144599516
6	1617270242566	CreateTagEntity1617270242566
7	1620824779533	UniqueWorkflowNames1620824779533
8	1626176912946	AddwaitTill1626176912946
9	1630419189837	UpdateWorkflowCredentials1630419189837
10	1644422880309	AddExecutionEntityIndexes1644422880309
11	1646834195327	IncreaseTypeVarcharLimit1646834195327
12	1646992772331	CreateUserManagement1646992772331
13	1648740597343	LowerCaseUserEmail1648740597343
14	1652254514002	CommunityNodes1652254514002
15	1652367743993	AddUserSettings1652367743993
16	1652905585850	AddAPIKeyColumn1652905585850
17	1654090467022	IntroducePinData1654090467022
18	1658932090381	AddNodeIds1658932090381
19	1659902242948	AddJsonKeyPinData1659902242948
20	1660062385367	CreateCredentialsUserRole1660062385367
21	1663755770893	CreateWorkflowsEditorRole1663755770893
22	1664196174001	WorkflowStatistics1664196174001
23	1665484192212	CreateCredentialUsageTable1665484192212
24	1665754637025	RemoveCredentialUsageTable1665754637025
25	1669739707126	AddWorkflowVersionIdColumn1669739707126
26	1669823906995	AddTriggerCountColumn1669823906995
27	1671535397530	MessageEventBusDestinations1671535397530
28	1671726148421	RemoveWorkflowDataLoadedFlag1671726148421
29	1673268682475	DeleteExecutionsWithWorkflows1673268682475
30	1674138566000	AddStatusToExecutions1674138566000
31	1674509946020	CreateLdapEntities1674509946020
32	1675940580449	PurgeInvalidWorkflowConnections1675940580449
33	1676996103000	MigrateExecutionStatus1676996103000
34	1677236854063	UpdateRunningExecutionStatus1677236854063
35	1677501636754	CreateVariables1677501636754
36	1679416281778	CreateExecutionMetadataTable1679416281778
37	1681134145996	AddUserActivatedProperty1681134145996
38	1681134145997	RemoveSkipOwnerSetup1681134145997
39	1690000000000	MigrateIntegerKeysToString1690000000000
40	1690000000020	SeparateExecutionData1690000000020
41	1690000000030	RemoveResetPasswordColumns1690000000030
42	1690000000030	AddMfaColumns1690000000030
43	1690787606731	AddMissingPrimaryKeyOnExecutionData1690787606731
44	1691088862123	CreateWorkflowNameIndex1691088862123
45	1692967111175	CreateWorkflowHistoryTable1692967111175
46	1693491613982	ExecutionSoftDelete1693491613982
47	1693554410387	DisallowOrphanExecutions1693554410387
48	1694091729095	MigrateToTimestampTz1694091729095
49	1695128658538	AddWorkflowMetadata1695128658538
50	1695829275184	ModifyWorkflowHistoryNodesAndConnections1695829275184
51	1700571993961	AddGlobalAdminRole1700571993961
52	1705429061930	DropRoleMapping1705429061930
53	1711018413374	RemoveFailedExecutionStatus1711018413374
54	1711390882123	MoveSshKeysToDatabase1711390882123
55	1712044305787	RemoveNodesAccess1712044305787
56	1714133768519	CreateProject1714133768519
57	1714133768521	MakeExecutionStatusNonNullable1714133768521
58	1717498465931	AddActivatedAtUserSetting1717498465931
59	1720101653148	AddConstraintToExecutionMetadata1720101653148
60	1721377157740	FixExecutionMetadataSequence1721377157740
61	1723627610222	CreateInvalidAuthTokenTable1723627610222
62	1723796243146	RefactorExecutionIndices1723796243146
63	1724753530828	CreateAnnotationTables1724753530828
64	1724951148974	AddApiKeysTable1724951148974
65	1726606152711	CreateProcessedDataTable1726606152711
66	1727427440136	SeparateExecutionCreationFromStart1727427440136
67	1728659839644	AddMissingPrimaryKeyOnAnnotationTagMapping1728659839644
68	1729607673464	UpdateProcessedDataValueColumnToText1729607673464
69	1729607673469	AddProjectIcons1729607673469
70	1730386903556	CreateTestDefinitionTable1730386903556
71	1731404028106	AddDescriptionToTestDefinition1731404028106
72	1731582748663	MigrateTestDefinitionKeyToString1731582748663
73	1732271325258	CreateTestMetricTable1732271325258
74	1732549866705	CreateTestRun1732549866705
75	1733133775640	AddMockedNodesColumnToTestDefinition1733133775640
76	1734479635324	AddManagedColumnToCredentialsTable1734479635324
77	1736172058779	AddStatsColumnsToTestRun1736172058779
78	1736947513045	CreateTestCaseExecutionTable1736947513045
79	1737715421462	AddErrorColumnsToTestRuns1737715421462
80	1738709609940	CreateFolderTable1738709609940
81	1739549398681	CreateAnalyticsTables1739549398681
82	1740445074052	UpdateParentFolderIdColumn1740445074052
83	1741167584277	RenameAnalyticsToInsights1741167584277
84	1742918400000	AddScopesColumnToApiKeys1742918400000
85	1745322634000	ClearEvaluation1745322634000
86	1745587087521	AddWorkflowStatisticsRootCount1745587087521
87	1745934666076	AddWorkflowArchivedColumn1745934666076
88	1745934666077	DropRoleTable1745934666077
89	1747824239000	AddProjectDescriptionColumn1747824239000
90	1750252139166	AddLastActiveAtColumnToUser1750252139166
91	1750252139166	AddScopeTables1750252139166
92	1750252139167	AddRolesTables1750252139167
93	1750252139168	LinkRoleToUserTable1750252139168
94	1750252139170	RemoveOldRoleColumn1750252139170
95	1752669793000	AddInputsOutputsToTestCaseExecution1752669793000
96	1753953244168	LinkRoleToProjectRelationTable1753953244168
97	1754475614601	CreateDataStoreTables1754475614601
98	1754475614602	ReplaceDataStoreTablesWithDataTables1754475614602
99	1756906557570	AddTimestampsToRoleAndRoleIndexes1756906557570
\.


--
-- TOC entry 4364 (class 0 OID 18416)
-- Dependencies: 346
-- Data for Name: n8n_workflows; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.n8n_workflows (id, name, active, nodes, connections, settings, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4365 (class 0 OID 18424)
-- Dependencies: 347
-- Data for Name: processed_data; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.processed_data ("workflowId", context, "createdAt", "updatedAt", value) FROM stdin;
\.


--
-- TOC entry 4366 (class 0 OID 18431)
-- Dependencies: 348
-- Data for Name: project; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.project (id, name, type, "createdAt", "updatedAt", icon, description) FROM stdin;
i9Hx3voRXPvZMWtL	Golfer Geek <golfergeek@orchestratorai.io>	personal	2025-10-09 20:29:48.678+00	2025-10-09 20:45:39.243+00	\N	\N
\.


--
-- TOC entry 4367 (class 0 OID 18438)
-- Dependencies: 349
-- Data for Name: project_relation; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.project_relation ("projectId", "userId", role, "createdAt", "updatedAt") FROM stdin;
i9Hx3voRXPvZMWtL	9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	project:personalOwner	2025-10-09 20:29:48.678+00	2025-10-09 20:29:48.678+00
\.


--
-- TOC entry 4368 (class 0 OID 18445)
-- Dependencies: 350
-- Data for Name: role; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.role (slug, "displayName", description, "roleType", "systemRole", "createdAt", "updatedAt") FROM stdin;
global:owner	Owner	Owner	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
global:admin	Admin	Admin	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
global:member	Member	Member	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
project:admin	Project Admin	Project Admin	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:personalOwner	Project Owner	Project Owner	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:editor	Project Editor	Project Editor	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:viewer	Project Viewer	Project Viewer	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
credential:owner	Credential Owner	Credential Owner	credential	t	2025-10-09 20:29:49.31+00	2025-10-09 20:29:49.31+00
credential:user	Credential User	Credential User	credential	t	2025-10-09 20:29:49.31+00	2025-10-09 20:29:49.31+00
workflow:owner	Workflow Owner	Workflow Owner	workflow	t	2025-10-09 20:29:49.315+00	2025-10-09 20:29:49.315+00
workflow:editor	Workflow Editor	Workflow Editor	workflow	t	2025-10-09 20:29:49.315+00	2025-10-09 20:29:49.315+00
\.


--
-- TOC entry 4369 (class 0 OID 18453)
-- Dependencies: 351
-- Data for Name: role_scope; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.role_scope ("roleSlug", "scopeSlug") FROM stdin;
global:owner	annotationTag:create
global:owner	annotationTag:read
global:owner	annotationTag:update
global:owner	annotationTag:delete
global:owner	annotationTag:list
global:owner	auditLogs:manage
global:owner	banner:dismiss
global:owner	community:register
global:owner	communityPackage:install
global:owner	communityPackage:uninstall
global:owner	communityPackage:update
global:owner	communityPackage:list
global:owner	credential:share
global:owner	credential:move
global:owner	credential:create
global:owner	credential:read
global:owner	credential:update
global:owner	credential:delete
global:owner	credential:list
global:owner	externalSecretsProvider:sync
global:owner	externalSecretsProvider:create
global:owner	externalSecretsProvider:read
global:owner	externalSecretsProvider:update
global:owner	externalSecretsProvider:delete
global:owner	externalSecretsProvider:list
global:owner	externalSecret:list
global:owner	externalSecret:use
global:owner	eventBusDestination:test
global:owner	eventBusDestination:create
global:owner	eventBusDestination:read
global:owner	eventBusDestination:update
global:owner	eventBusDestination:delete
global:owner	eventBusDestination:list
global:owner	ldap:sync
global:owner	ldap:manage
global:owner	license:manage
global:owner	logStreaming:manage
global:owner	orchestration:read
global:owner	project:create
global:owner	project:read
global:owner	project:update
global:owner	project:delete
global:owner	project:list
global:owner	saml:manage
global:owner	securityAudit:generate
global:owner	sourceControl:pull
global:owner	sourceControl:push
global:owner	sourceControl:manage
global:owner	tag:create
global:owner	tag:read
global:owner	tag:update
global:owner	tag:delete
global:owner	tag:list
global:owner	user:resetPassword
global:owner	user:changeRole
global:owner	user:enforceMfa
global:owner	user:create
global:owner	user:read
global:owner	user:update
global:owner	user:delete
global:owner	user:list
global:owner	variable:create
global:owner	variable:read
global:owner	variable:update
global:owner	variable:delete
global:owner	variable:list
global:owner	workersView:manage
global:owner	workflow:share
global:owner	workflow:execute
global:owner	workflow:move
global:owner	workflow:create
global:owner	workflow:read
global:owner	workflow:update
global:owner	workflow:delete
global:owner	workflow:list
global:owner	folder:create
global:owner	folder:read
global:owner	folder:update
global:owner	folder:delete
global:owner	folder:list
global:owner	folder:move
global:owner	insights:list
global:owner	oidc:manage
global:owner	dataStore:list
global:owner	role:manage
global:admin	annotationTag:create
global:admin	annotationTag:read
global:admin	annotationTag:update
global:admin	annotationTag:delete
global:admin	annotationTag:list
global:admin	auditLogs:manage
global:admin	banner:dismiss
global:admin	community:register
global:admin	communityPackage:install
global:admin	communityPackage:uninstall
global:admin	communityPackage:update
global:admin	communityPackage:list
global:admin	credential:share
global:admin	credential:move
global:admin	credential:create
global:admin	credential:read
global:admin	credential:update
global:admin	credential:delete
global:admin	credential:list
global:admin	externalSecretsProvider:sync
global:admin	externalSecretsProvider:create
global:admin	externalSecretsProvider:read
global:admin	externalSecretsProvider:update
global:admin	externalSecretsProvider:delete
global:admin	externalSecretsProvider:list
global:admin	externalSecret:list
global:admin	externalSecret:use
global:admin	eventBusDestination:test
global:admin	eventBusDestination:create
global:admin	eventBusDestination:read
global:admin	eventBusDestination:update
global:admin	eventBusDestination:delete
global:admin	eventBusDestination:list
global:admin	ldap:sync
global:admin	ldap:manage
global:admin	license:manage
global:admin	logStreaming:manage
global:admin	orchestration:read
global:admin	project:create
global:admin	project:read
global:admin	project:update
global:admin	project:delete
global:admin	project:list
global:admin	saml:manage
global:admin	securityAudit:generate
global:admin	sourceControl:pull
global:admin	sourceControl:push
global:admin	sourceControl:manage
global:admin	tag:create
global:admin	tag:read
global:admin	tag:update
global:admin	tag:delete
global:admin	tag:list
global:admin	user:resetPassword
global:admin	user:changeRole
global:admin	user:enforceMfa
global:admin	user:create
global:admin	user:read
global:admin	user:update
global:admin	user:delete
global:admin	user:list
global:admin	variable:create
global:admin	variable:read
global:admin	variable:update
global:admin	variable:delete
global:admin	variable:list
global:admin	workersView:manage
global:admin	workflow:share
global:admin	workflow:execute
global:admin	workflow:move
global:admin	workflow:create
global:admin	workflow:read
global:admin	workflow:update
global:admin	workflow:delete
global:admin	workflow:list
global:admin	folder:create
global:admin	folder:read
global:admin	folder:update
global:admin	folder:delete
global:admin	folder:list
global:admin	folder:move
global:admin	insights:list
global:admin	oidc:manage
global:admin	dataStore:list
global:admin	role:manage
global:member	annotationTag:create
global:member	annotationTag:read
global:member	annotationTag:update
global:member	annotationTag:delete
global:member	annotationTag:list
global:member	eventBusDestination:test
global:member	eventBusDestination:list
global:member	tag:create
global:member	tag:read
global:member	tag:update
global:member	tag:list
global:member	user:list
global:member	variable:read
global:member	variable:list
global:member	dataStore:list
project:admin	credential:share
project:admin	credential:move
project:admin	credential:create
project:admin	credential:read
project:admin	credential:update
project:admin	credential:delete
project:admin	credential:list
project:admin	project:read
project:admin	project:update
project:admin	project:delete
project:admin	project:list
project:admin	sourceControl:push
project:admin	workflow:execute
project:admin	workflow:move
project:admin	workflow:create
project:admin	workflow:read
project:admin	workflow:update
project:admin	workflow:delete
project:admin	workflow:list
project:admin	folder:create
project:admin	folder:read
project:admin	folder:update
project:admin	folder:delete
project:admin	folder:list
project:admin	folder:move
project:admin	dataStore:create
project:admin	dataStore:read
project:admin	dataStore:update
project:admin	dataStore:delete
project:admin	dataStore:readRow
project:admin	dataStore:writeRow
project:admin	dataStore:listProject
project:personalOwner	credential:share
project:personalOwner	credential:move
project:personalOwner	credential:create
project:personalOwner	credential:read
project:personalOwner	credential:update
project:personalOwner	credential:delete
project:personalOwner	credential:list
project:personalOwner	project:read
project:personalOwner	project:list
project:personalOwner	workflow:share
project:personalOwner	workflow:execute
project:personalOwner	workflow:move
project:personalOwner	workflow:create
project:personalOwner	workflow:read
project:personalOwner	workflow:update
project:personalOwner	workflow:delete
project:personalOwner	workflow:list
project:personalOwner	folder:create
project:personalOwner	folder:read
project:personalOwner	folder:update
project:personalOwner	folder:delete
project:personalOwner	folder:list
project:personalOwner	folder:move
project:personalOwner	dataStore:create
project:personalOwner	dataStore:read
project:personalOwner	dataStore:update
project:personalOwner	dataStore:delete
project:personalOwner	dataStore:readRow
project:personalOwner	dataStore:writeRow
project:personalOwner	dataStore:listProject
project:editor	credential:create
project:editor	credential:read
project:editor	credential:update
project:editor	credential:delete
project:editor	credential:list
project:editor	project:read
project:editor	project:list
project:editor	workflow:execute
project:editor	workflow:create
project:editor	workflow:read
project:editor	workflow:update
project:editor	workflow:delete
project:editor	workflow:list
project:editor	folder:create
project:editor	folder:read
project:editor	folder:update
project:editor	folder:delete
project:editor	folder:list
project:editor	dataStore:create
project:editor	dataStore:read
project:editor	dataStore:update
project:editor	dataStore:delete
project:editor	dataStore:readRow
project:editor	dataStore:writeRow
project:editor	dataStore:listProject
project:viewer	credential:read
project:viewer	credential:list
project:viewer	project:read
project:viewer	project:list
project:viewer	workflow:read
project:viewer	workflow:list
project:viewer	folder:read
project:viewer	folder:list
project:viewer	dataStore:read
project:viewer	dataStore:readRow
project:viewer	dataStore:listProject
credential:owner	credential:share
credential:owner	credential:move
credential:owner	credential:read
credential:owner	credential:update
credential:owner	credential:delete
credential:user	credential:read
workflow:owner	workflow:share
workflow:owner	workflow:execute
workflow:owner	workflow:move
workflow:owner	workflow:read
workflow:owner	workflow:update
workflow:owner	workflow:delete
workflow:editor	workflow:execute
workflow:editor	workflow:read
workflow:editor	workflow:update
\.


--
-- TOC entry 4370 (class 0 OID 18456)
-- Dependencies: 352
-- Data for Name: scope; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.scope (slug, "displayName", description) FROM stdin;
annotationTag:create	Create Annotation Tag	Allows creating new annotation tags.
annotationTag:read	annotationTag:read	\N
annotationTag:update	annotationTag:update	\N
annotationTag:delete	annotationTag:delete	\N
annotationTag:list	annotationTag:list	\N
annotationTag:*	annotationTag:*	\N
auditLogs:manage	auditLogs:manage	\N
auditLogs:*	auditLogs:*	\N
banner:dismiss	banner:dismiss	\N
banner:*	banner:*	\N
community:register	community:register	\N
community:*	community:*	\N
communityPackage:install	communityPackage:install	\N
communityPackage:uninstall	communityPackage:uninstall	\N
communityPackage:update	communityPackage:update	\N
communityPackage:list	communityPackage:list	\N
communityPackage:manage	communityPackage:manage	\N
communityPackage:*	communityPackage:*	\N
credential:share	credential:share	\N
credential:move	credential:move	\N
credential:create	credential:create	\N
credential:read	credential:read	\N
credential:update	credential:update	\N
credential:delete	credential:delete	\N
credential:list	credential:list	\N
credential:*	credential:*	\N
externalSecretsProvider:sync	externalSecretsProvider:sync	\N
externalSecretsProvider:create	externalSecretsProvider:create	\N
externalSecretsProvider:read	externalSecretsProvider:read	\N
externalSecretsProvider:update	externalSecretsProvider:update	\N
externalSecretsProvider:delete	externalSecretsProvider:delete	\N
externalSecretsProvider:list	externalSecretsProvider:list	\N
externalSecretsProvider:*	externalSecretsProvider:*	\N
externalSecret:list	externalSecret:list	\N
externalSecret:use	externalSecret:use	\N
externalSecret:*	externalSecret:*	\N
eventBusDestination:test	eventBusDestination:test	\N
eventBusDestination:create	eventBusDestination:create	\N
eventBusDestination:read	eventBusDestination:read	\N
eventBusDestination:update	eventBusDestination:update	\N
eventBusDestination:delete	eventBusDestination:delete	\N
eventBusDestination:list	eventBusDestination:list	\N
eventBusDestination:*	eventBusDestination:*	\N
ldap:sync	ldap:sync	\N
ldap:manage	ldap:manage	\N
ldap:*	ldap:*	\N
license:manage	license:manage	\N
license:*	license:*	\N
logStreaming:manage	logStreaming:manage	\N
logStreaming:*	logStreaming:*	\N
orchestration:read	orchestration:read	\N
orchestration:list	orchestration:list	\N
orchestration:*	orchestration:*	\N
project:create	project:create	\N
project:read	project:read	\N
project:update	project:update	\N
project:delete	project:delete	\N
project:list	project:list	\N
project:*	project:*	\N
saml:manage	saml:manage	\N
saml:*	saml:*	\N
securityAudit:generate	securityAudit:generate	\N
securityAudit:*	securityAudit:*	\N
sourceControl:pull	sourceControl:pull	\N
sourceControl:push	sourceControl:push	\N
sourceControl:manage	sourceControl:manage	\N
sourceControl:*	sourceControl:*	\N
tag:create	tag:create	\N
tag:read	tag:read	\N
tag:update	tag:update	\N
tag:delete	tag:delete	\N
tag:list	tag:list	\N
tag:*	tag:*	\N
user:resetPassword	user:resetPassword	\N
user:changeRole	user:changeRole	\N
user:enforceMfa	user:enforceMfa	\N
user:create	user:create	\N
user:read	user:read	\N
user:update	user:update	\N
user:delete	user:delete	\N
user:list	user:list	\N
user:*	user:*	\N
variable:create	variable:create	\N
variable:read	variable:read	\N
variable:update	variable:update	\N
variable:delete	variable:delete	\N
variable:list	variable:list	\N
variable:*	variable:*	\N
workersView:manage	workersView:manage	\N
workersView:*	workersView:*	\N
workflow:share	workflow:share	\N
workflow:execute	workflow:execute	\N
workflow:move	workflow:move	\N
workflow:activate	workflow:activate	\N
workflow:deactivate	workflow:deactivate	\N
workflow:create	workflow:create	\N
workflow:read	workflow:read	\N
workflow:update	workflow:update	\N
workflow:delete	workflow:delete	\N
workflow:list	workflow:list	\N
workflow:*	workflow:*	\N
folder:create	folder:create	\N
folder:read	folder:read	\N
folder:update	folder:update	\N
folder:delete	folder:delete	\N
folder:list	folder:list	\N
folder:move	folder:move	\N
folder:*	folder:*	\N
insights:list	insights:list	\N
insights:*	insights:*	\N
oidc:manage	oidc:manage	\N
oidc:*	oidc:*	\N
dataStore:create	dataStore:create	\N
dataStore:read	dataStore:read	\N
dataStore:update	dataStore:update	\N
dataStore:delete	dataStore:delete	\N
dataStore:list	dataStore:list	\N
dataStore:readRow	dataStore:readRow	\N
dataStore:writeRow	dataStore:writeRow	\N
dataStore:listProject	dataStore:listProject	\N
dataStore:*	dataStore:*	\N
execution:delete	execution:delete	\N
execution:read	execution:read	\N
execution:retry	execution:retry	\N
execution:list	execution:list	\N
execution:get	execution:get	\N
execution:*	execution:*	\N
workflowTags:update	workflowTags:update	\N
workflowTags:list	workflowTags:list	\N
workflowTags:*	workflowTags:*	\N
role:manage	role:manage	\N
role:*	role:*	\N
*	*	\N
\.


--
-- TOC entry 4371 (class 0 OID 18461)
-- Dependencies: 353
-- Data for Name: settings; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.settings (key, value, "loadOnStartup") FROM stdin;
ui.banners.dismissed	["V1"]	t
features.ldap	{"loginEnabled":false,"loginLabel":"","connectionUrl":"","allowUnauthorizedCerts":false,"connectionSecurity":"none","connectionPort":389,"baseDn":"","bindingAdminDn":"","bindingAdminPassword":"","firstNameAttribute":"","lastNameAttribute":"","emailAttribute":"","loginIdAttribute":"","ldapIdAttribute":"","userFilter":"","synchronizationEnabled":false,"synchronizationInterval":60,"searchPageSize":0,"searchTimeout":60}	t
userManagement.authenticationMethod	email	t
features.sourceControl.sshKeys	{"encryptedPrivateKey":"U2FsdGVkX18uK1cYPYc2Qqvf+aKSdY6oHbf5l0BCwR6cf7koIhxfqGl+fjXlNo08E0mNGYTUYMEfXX1oTf0cri5avihshJrZjx4I4bkSM3G7jG38t/k257KVEnBTkzPYkHHgNMS2PuYEirq08jIo83eUjJzec55QRDMAAb0qrQz5qnvBcxAyXRjkWwbQIK6LM8BNBKOLhHNXuiN5fCqHmru+RMY36gzX1B/z3tfvU575nAvKItVy9C5AR9YqeuGuSyFbtvxHVyaOhnM7guVg8nm0pHZoTR548mbIcRX4yYHwAYBpC2RWa6KT0PqdRDufoEGcD6ODbbmJHCcN7673B5XCkoj6XbNLLKBAu1d+0YPAzZWQq7/Z2pk3iHrlNWMpmcYOnxa8IIjeXO2AsdNlhhsrPs8OUTnCVslRGh8Eugee9SQpeCYhkGauFl1Mich0NCWCFc8j6ZTve4RN4rLLVGk9XrKfq5qSC8DfNStQPbM32ZFZXB0MMWWusOtFEkFUjQncmgHQo+kHZTQqtQrS5nI/RzxGMi/t4XGN4WIwP/EwmC4VtxrWTn9E6oH0KKJr","publicKey":"ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPOfUCG5hekveeuBOAeFv0t01F7srLLyVCFZA3gmZ2Gm n8n deploy key"}	t
features.sourceControl	{"branchName":"main","keyGeneratorType":"ed25519"}	t
license.cert	eyJsaWNlbnNlS2V5IjoiLS0tLS1CRUdJTiBMSUNFTlNFIEtFWS0tLS0tXG5lcHRyT3JndFBHWjlwRDlncGtCQWd1YlpiWUxRQjVqSDJlYVBFMVhIQSt0RWpReWRqVzNwVDQ0MGFtUFdiNnlWXG5xOGhWdUxNOGpVSjFUVUpsbzRreExmbnNMYzl5endXeUExcmRKY0lvd1I5TFFOd0I2Zk9WL0w3YUhzcXZPN3plXG5hblVUaHVoSDFZbFo3dmZEQ3RnYVhyeUJpc1RCZ3g5QUkrTjJIR2dkb1JRblE4c0lwb2FoakpxbUxtYmhxUDY3XG51Y1NMTmpudUJOUEx3OFRpT3M1RUpZZ3pYdHB3bWgyM1FsOGcveDdFYzJaRXpzWE4zV2VOSGk4bHVzSjhid2lmXG5wY0ZYU2M2Ti8xUkxFKzAyampsMWtVMldLOUllY1BCSzhvYnREZTZ3cXRYQ3ViTDNpRzg5UHAyVHFVVkg0aFlvXG5vemFvMXdBWnIxeXc2VE5vZUhBbmhnPT18fFUyRnNkR1ZrWDEvMjMrWDF4aHRGRFpDY0c1RHM5MUNpZUU0NFdwXG53S0NLWTJxbHVmNC9pNWRON1d5TCtxMSs4M3drSXp4TlhXRXRXMVRvQUtjYi96SjRhK3E5UkVObnMxZzhlanNrXG50cUMyNVZzeUhUR2w3dGhSZUMrVmJxSWNkMStkNnFVYUtBZ21WY0VGMjdtd2tPVlVBQjZoM3pDdGNTaTFUaytKXG5lc1N3RDA2dHJkY0ZUdWZjaytRUlJDMHVKcVdpeUU0RzlxeWRqMXlFcmZZRGVuQXBUbUxOa2NUNEZabkU0WHljXG5LdUNjZ0FXQm8vc2VFYldhYWUrRXl4M1VKcUZUd1hSS1pPZEJ1b0s3QlFTVG96aEcrblA5MzBxRVY2aDJnV3hDXG5tMGVYMFgvMkpoSFQ5OWFIV0ppUGJoU0ptdmdud1d0b3ZhTmFzN3ZjQnBvbnUyL2NDTWRmamRlNzVRTFd4S1REXG53Mi9GNllYeEwyUzVwSDU4ZnIyS01xMGNIbnIzd254cytjaTc2TC8yQjFpT3VmVzdLWGJpUnMrOFIvVDMrK3MzXG54NVhqblJtaHRkUTcxMDBpQnkyZWxUVzF0SmQ0ZEdReEdGSDdZV1BPRHhMQzloYkRVaUN0VWNrQUphSHR6R1pnXG4vWjJlY2lCT2w1b21ka0o4bUROdWNMWHYwNXJKNkd5MVk4eUJiOWVsTHhKdUEvNDBlWjBXZnJubDFOWGpmaUtiXG5Ga1hDMTFwekNzY29yZXZnUUN3eEI2eFVOdGdzRWk1RkJUYkxPdEZabUhvYWZCOXBvbmk4czlWQVVRUFRxcWZ2XG5CYzZOZ2VwWmVEdVF1ZFV2UVUrVWJLeSsvSnpiYkt3WW45R3VrN2VjOW5RU1NZdVE2OU54M1pHUlNweVd1c1I1XG5iNFdwcldGWDZjY0xIVnF3Y0x3YXJ2cFF0MDJ6WENINmo2ZngwSTVOWFIwMm1Fd2lHMHd4MWswRUlHdGNyR2ptXG5LdlFQbmYxS2tpbzIyTjVjUEU2QjRmL0FVVitmNGc5YkFjbTQzMXp1MVROWDJLRVhUZWhJcUNyM2M3M2NPcEJ0XG5YMzdwNjNEd0F6V1RQZWtPMXp0WmlVR0EwdjhvdnQ4a0hCVW5vby9iNUJ6MDFUZWN0K2NQMU5sRFZtcTkzSXpnXG5IR1VxUWg5L3ZPV0c0Y3lTOEVkeERPZkNSdUorM2JPaGNNazJxTkNybStaSnJwM0xaRUtwTjBqWDJLRXAyWERrXG55R0t6OEVTVXFNMTZZclAvT0ZieGJuSXovbTF6aUN3MGdhT1N0R1ZockdnUkxseWwwZ29RUWpaODE2TXhCMmhxXG40RTVhUnZoRmVrSHRqTXkyRmROL05pV05Zb1Rycnlhb04zWU1CbWpLL29jdE1Kcy8wb1F5OE5Md0NTaGlNYzRHXG5uRGl0cXhBTGNvYmRmdDlncHJnM2tuTGMvdzRDNkxacFJGSzJMTTVQaVJuRTc0SXFtSVZWaU4wSytRWnpFV2pXXG5Eams3WGc5V2NGbVp4QWdrMHJMZkRYdzU1THprS1huN0tPck92OVJhK3p0YzRremJjbFMwd1V4U29RVFV2VUlPXG5Cc1NrS0QzMkt2Z25VYmtsSGJ2d1oxdmh3cm1xUk8rbG1WUVBnaDBVK01rY2hRTHc5SzVqMUh2UUkvci9DSXBHXG5lYzArSUl2aTQvQlJKRjRKZytucGd5bVdDKzVueEpLOFJackIzSW9yZzJYUW85NkY1b3hsQXhLeDBNMjlWbm92XG5mdnkxSlpZSS9lT3F6VG1TUWp5OURqOHRlZHFKRFNETllBTUswWURIUlp0eExIYUtpYnRaVUU2eUJZR2lmMGVrXG5yUlFoWWZqMWZ2UnJON1ZHREJHTlZkN05iZU53ajhLMDlqcGdKSlgzeVBoZXFRc3o0b3haQzhEN3RlMFRlakxNXG5RaGUwTVpSblBKTTA5dUZ6bHVMTkIrTjdWZVN4UG1UbjFJaGxsQnp0ZkxTSEgveCtzZUx3RytvVTFMMmN6ZEFoXG5FQzM3dXk5YWY5WlBDLzdpZ0VlN3Qyb2o2SzhSTW1VQWZudm16TGliYWhXckIrUk1kSWgreStYK1lzWHdyS2RVXG55SVdaRWhQQmhiWHBFUzh3RW1rZHlKOXNadTZxNUxjc2tXeDlhRW95WGFHUFIwalA5ZFQ1NEdYMFZyVnVBeUZpXG5CZERpNFVGemxHUFRSNW1yTG5Sam0yN3h0L2lZdFFLYXBmNHQvRmEwOUh6dnI5K1NqMUlBVkJVaUVIUlQ4bjBrXG4rQ2VUb0ZCY0c4V05yczMwTGN0b1E0OVpTMU1VeFN2cXFDRC9WNmowWW00b254OVVTbEdSQW4wa2szMEFoaHUxXG5LV0lodW91bkw1L1hCWGcydS9sMmJraVFFdDZIaEF0eW14cEc4VFBtVmorTlFvSE4wM0xsclJiS2IvbWJnWWJJXG5YeUlnOEhtSGN5VGRqOGQrUmRySGlpK013dUUvcFBaVzNvK3gxVjVxZ3FWelU2L0YrY2JXSDZFQnd4UmdjendPXG5FZ3ZEYkhIS1I2SnZmRUR0VmRFcnlLY2ltZWJSL2ZMd3hxcktlRzNRY0N3a3ozSGkxSTF4cTAwS2FFa0ZZSXU1XG5WNkp1RzFZaWY0Um91RjloVlVLYlZHL0o1ZEpBTENWWkQ0alFRL2ovUnhwN1FSeVl6L01kVTE2MjNuVmRZSjBxXG5NOSthZlZ3Z0ZKT2JKQndVb3ZSd2E3WWxUNmlCdlY2OG1tQ3VEamJGbGpsUmZSK1JOWmp0ZE5ZSzVjQVRUczEyXG4zMGhlcVh5Zm9MMU1NMnNBZFJaZkhSUFVpRERWSk9ROTViMmNVSEJrdGFFcVk5V1VFYVdRSlNLYTg2MFQzajdTXG5rK2lpUDZVVjhzK3kyU2dUaXNKOXRYN1dYWk41Ly92M3VjdVQvZXE3dGNjMEZpVDE4SlhGTUNpbHpPSmRqVkR5XG5DRll4NkRBODI4QUp4bTh3T2hmZDBEdkRNVXgyYlp0Z0ZhdlVYd2pVUlBOTTYzUzBqcGdmZ0tqaVJlMlhzM0pEXG5iRUlDRTBqYjBCSk5BNUg2bTFJajdUajFKU2JBZlBMVnlMVjZQMEdUQ2ZjWWhsSEE9PXx8UXRMYys3eUV0VGdTXG5EL3dQSzU3VlJXd0t6TUg4djJqL2tUY09oR1JtVnd3MFdpSTFGN0hibWx0ajJEMWhveGZSL2RFMnorOW1HY2FKXG4xVFdYZTFVSkZwMitPWHZ3anpDdmpKOHlQejBlNmU0U2xubDRMVjRJdEdUNmV3U29wdk9nb0lYdjFwcmxwa1YzXG5xN1BvTmx5WTdGTW9nTkRKYnlVRERYNVVpa2MraEVlVk9KRW9KSjJsVHdNTEZrQXdnUHFHOFdQZkVySlU3OWtMXG55aFJvV0lWWjlnaHNyOGJwMElqb0tPMVE2S1B1VTZVakNnQUt5d3JwR1VrTzB1UnhKa3Zsa0Y5UEo4UmJjY1VGXG5jTTJ6L2NHTHdiWjI3aERFZlZPUzVRNjIzYW93MWJ6TldvN0E3L3pVazNsZ0oxakRrTGF3UmpyMjk5c3dCb2ljXG44WHFjdlRYWGdBPT1cbi0tLS0tRU5EIExJQ0VOU0UgS0VZLS0tLS0iLCJ4NTA5IjoiLS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tXG5NSUlFRERDQ0FmUUNDUUNxZzJvRFQ4MHh3akFOQmdrcWhraUc5dzBCQVFVRkFEQklNUXN3Q1FZRFZRUUdFd0pFXG5SVEVQTUEwR0ExVUVDQXdHUW1WeWJHbHVNUTh3RFFZRFZRUUhEQVpDWlhKc2FXNHhGekFWQmdOVkJBTU1EbXhwXG5ZMlZ1YzJVdWJqaHVMbWx2TUI0WERUSXlNRFl5TkRBME1UQTBNRm9YRFRJek1EWXlOREEwTVRBME1Gb3dTREVMXG5NQWtHQTFVRUJoTUNSRVV4RHpBTkJnTlZCQWdNQmtKbGNteHBiakVQTUEwR0ExVUVCd3dHUW1WeWJHbHVNUmN3XG5GUVlEVlFRRERBNXNhV05sYm5ObExtNDRiaTVwYnpDQ0FTSXdEUVlKS29aSWh2Y05BUUVCQlFBRGdnRVBBRENDXG5BUW9DZ2dFQkFNQk0wNVhCNDRnNXhmbUNMd2RwVVR3QVQ4K0NCa3lMS0ZzZXprRDVLLzZXaGFYL1hyc2QvUWQwXG4yMEo3d2w1V2RIVTRjVkJtRlJqVndWemtsQ0syeVlKaThtang4c1hzR3E5UTFsYlVlTUtmVjlkc2dmdWhubEFTXG50blFaZ2x1Z09uRjJGZ1JoWGIvakswdHhUb2FvK2JORTZyNGdJRXpwa3RITEJUWXZ2aXVKbXJlZjdXYlBSdDRJXG5uZDlEN2xoeWJlYnloVjdrdXpqUUEvcFBLSFRGczhNVEhaOGhZVXhSeXJwbTMrTVl6UUQrYmpBMlUxRkljdGFVXG53UVhZV2FON3QydVR3Q3Q5ekFLc21ZL1dlT2J2bDNUWk41T05MQXp5V0dDdWxtNWN3S1IzeGJsQlp6WG5CNmdzXG5Pbk4yT0FkU3RjelRWQ3ljbThwY0ZVcnl0S1NLa0dFQ0F3RUFBVEFOQmdrcWhraUc5dzBCQVFVRkFBT0NBZ0VBXG5sSjAxd2NuMXZqWFhDSHVvaTdSMERKMWxseDErZGFmcXlFcVBBMjdKdStMWG1WVkdYUW9yUzFiOHhqVXFVa2NaXG5UQndiV0ZPNXo1ZFptTnZuYnlqYXptKzZvT2cwUE1hWXhoNlRGd3NJMlBPYmM3YkZ2MmVheXdQdC8xQ3BuYzQwXG5xVU1oZnZSeC9HQ1pQQ1d6My8yUlBKV1g5alFEU0hYQ1hxOEJXK0kvM2N1TERaeVkzZkVZQkIwcDNEdlZtYWQ2XG42V0hRYVVyaU4wL0xxeVNPcC9MWmdsbC90MDI5Z1dWdDA1WmliR29LK2NWaFpFY3NMY1VJaHJqMnVGR0ZkM0ltXG5KTGcxSktKN2pLU0JVUU9kSU1EdnNGVUY3WWRNdk11ckNZQTJzT05OOENaK0k1eFFWMUtTOWV2R0hNNWZtd2dTXG5PUEZ2UHp0RENpMC8xdVc5dE9nSHBvcnVvZGFjdCtFWk5rQVRYQ3ZaaXUydy9xdEtSSkY0VTRJVEVtNWFXMGt3XG42enVDOHh5SWt0N3ZoZHM0OFV1UlNHSDlqSnJBZW1sRWl6dEdJTGhHRHF6UUdZYmxoVVFGR01iQmI3amhlTHlDXG5MSjFXT0c2MkYxc3B4Q0tCekVXNXg2cFIxelQxbWhFZ2Q0TWtMYTZ6UFRwYWNyZDk1QWd4YUdLRUxhMVJXU0ZwXG5NdmRoR2s0TnY3aG5iOHIrQnVNUkM2aWVkUE1DelhxL001MGNOOEFnOGJ3K0oxYUZvKzBFSzJoV0phN2tpRStzXG45R3ZGalNkekNGbFVQaEtra1Vaa1NvNWFPdGNRcTdKdTZrV0JoTG9GWUtncHJscDFRVkIwc0daQTZvNkR0cWphXG5HNy9SazZ2YmFZOHdzTllLMnpCWFRUOG5laDVab1JaL1BKTFV0RUV0YzdZPVxuLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLSJ9	f
userManagement.isInstanceOwnerSetUp	true	t
\.


--
-- TOC entry 4372 (class 0 OID 18467)
-- Dependencies: 354
-- Data for Name: shared_credentials; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.shared_credentials ("credentialsId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
7tuOlNCTiyjK0BzN	i9Hx3voRXPvZMWtL	credential:owner	2025-10-10 12:48:44.887+00	2025-10-10 12:48:44.887+00
hz52TIdzOn7p9IzY	i9Hx3voRXPvZMWtL	credential:owner	2025-10-11 02:59:30.013+00	2025-10-11 02:59:30.013+00
\.


--
-- TOC entry 4373 (class 0 OID 18474)
-- Dependencies: 355
-- Data for Name: shared_workflow; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.shared_workflow ("workflowId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
1LaQnwqSoTxmnw3Z	i9Hx3voRXPvZMWtL	workflow:owner	2025-10-09 23:01:45.917+00	2025-10-09 23:01:45.917+00
9jxl03jCcqg17oOy	i9Hx3voRXPvZMWtL	workflow:owner	2025-10-09 23:01:53.794+00	2025-10-09 23:01:53.794+00
Q08T7oMX2dZslqV4	i9Hx3voRXPvZMWtL	workflow:owner	2025-10-09 23:04:05.011+00	2025-10-09 23:04:05.011+00
\.


--
-- TOC entry 4374 (class 0 OID 18481)
-- Dependencies: 356
-- Data for Name: tag_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.tag_entity (name, "createdAt", "updatedAt", id) FROM stdin;
\.


--
-- TOC entry 4375 (class 0 OID 18486)
-- Dependencies: 357
-- Data for Name: test_case_execution; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.test_case_execution (id, "testRunId", "executionId", status, "runAt", "completedAt", "errorCode", "errorDetails", metrics, "createdAt", "updatedAt", inputs, outputs) FROM stdin;
\.


--
-- TOC entry 4376 (class 0 OID 18493)
-- Dependencies: 358
-- Data for Name: test_run; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.test_run (id, "workflowId", status, "errorCode", "errorDetails", "runAt", "completedAt", metrics, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4377 (class 0 OID 18500)
-- Dependencies: 359
-- Data for Name: user; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n."user" (id, email, "firstName", "lastName", password, "personalizationAnswers", "createdAt", "updatedAt", settings, disabled, "mfaEnabled", "mfaSecret", "mfaRecoveryCodes", "lastActiveAt", "roleSlug") FROM stdin;
9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	golfergeek@orchestratorai.io	Golfer	Geek	$2a$10$.wsFrf65OUi01Os6m0j89emQDEepZJeP.siSBoNA3cbFlCCFrFHby	{"version":"v4","personalization_survey_submitted_at":"2025-10-09T20:45:55.451Z","personalization_survey_n8n_version":"1.113.3","companySize":"<20","companyType":"saas","role":"business-owner","reportedSource":"youtube"}	2025-10-09 20:29:48.187+00	2025-10-27 05:00:39.621+00	{"userActivated":true,"easyAIWorkflowOnboarded":true,"firstSuccessfulWorkflowId":"9jxl03jCcqg17oOy","userActivatedAt":1760149441660}	f	f	\N	\N	2025-10-27	global:owner
\.


--
-- TOC entry 4378 (class 0 OID 18511)
-- Dependencies: 360
-- Data for Name: user_api_keys; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.user_api_keys (id, "userId", label, "apiKey", "createdAt", "updatedAt", scopes) FROM stdin;
zQTzYfs7ExLSDksn	9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	OrchestratorAI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5ZjEyYjBmZi0zNzJiLTRkNDYtYjhlYS0zMGMxNGE0YTE0YTIiLCJpc3MiOiJuOG4iLCJhdWQiOiJwdWJsaWMtYXBpIiwiaWF0IjoxNzYwMDQyOTA4fQ.kGRjGIPvyOptWjzFAatIt0KZbG7leeRYoNhyifC73BM	2025-10-09 20:48:28.884+00	2025-10-09 20:48:28.884+00	["credential:create","credential:delete","credential:move","project:create","project:delete","project:list","project:update","securityAudit:generate","sourceControl:pull","tag:create","tag:delete","tag:list","tag:read","tag:update","user:changeRole","user:create","user:delete","user:enforceMfa","user:list","user:read","variable:create","variable:delete","variable:list","variable:update","workflow:create","workflow:delete","workflow:list","workflow:move","workflow:read","workflow:update","workflowTags:update","workflowTags:list","workflow:activate","workflow:deactivate","execution:delete","execution:read","execution:retry","execution:list"]
\.


--
-- TOC entry 4379 (class 0 OID 18518)
-- Dependencies: 361
-- Data for Name: variables; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.variables (key, type, value, id) FROM stdin;
\.


--
-- TOC entry 4380 (class 0 OID 18522)
-- Dependencies: 362
-- Data for Name: webhook_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.webhook_entity ("webhookPath", method, node, "webhookId", "pathLength", "workflowId") FROM stdin;
marketing-swarm-flexible	POST	Webhook	\N	\N	1LaQnwqSoTxmnw3Z
marketing-swarm	POST	Webhook Trigger	\N	\N	Q08T7oMX2dZslqV4
\.


--
-- TOC entry 4381 (class 0 OID 18527)
-- Dependencies: 363
-- Data for Name: workflow_entity; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflow_entity (name, active, nodes, connections, "createdAt", "updatedAt", settings, "staticData", "pinData", "versionId", "triggerCount", id, meta, "parentFolderId", "isArchived") FROM stdin;
Helper: LLM Task	f	[{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || \\"http://host.docker.internal:7100/webhooks/status\\"}}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $json.taskId,\\n  status: 'running',\\n  timestamp: new Date().toISOString(),\\n  step: $json.stepName,\\n  message: `Starting ${$json.stepName || 'task'}`,\\n  sequence: $json.sequence,\\n  totalSteps: $json.totalSteps,\\n  conversationId: $json.conversationId,\\n  userId: $json.userId\\n}) }}","options":{}},"id":"send-start-status","name":"Send Start Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[288,176],"continueOnFail":true},{"parameters":{"rules":{"values":[{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"leftValue":"={{ $json.provider }}","rightValue":"openai","operator":{"type":"string","operation":"equals"},"id":"a1593526-252b-40e7-b755-414c0363680d"}],"combinator":"and"}},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"46d844e4-2f30-44cb-87c6-618ed4c789d3","leftValue":"={{ $json.provider }}","rightValue":"ollama","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"}},{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":1},"conditions":[{"id":"9331fc1c-d594-4900-81b6-89021334541c","leftValue":"=  {{ $json.provider }}","rightValue":"anthropic","operator":{"type":"string","operation":"equals","name":"filter.operator.equals"}}],"combinator":"and"}}]},"options":{"fallbackOutput":0}},"id":"select-provider","name":"Select Provider","type":"n8n-nodes-base.switch","typeVersion":3,"position":[256,432]},{"parameters":{"method":"POST","url":"https://api.anthropic.com/v1/messages","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Trigger').item.json.model || 'claude-3-sonnet-20240229',\\\\n  messages: [{ role: 'user', content: $('Trigger').item.json.prompt }],\\\\n  temperature: $('Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{}},"id":"anthropic-request","name":"Anthropic Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[576,512]},{"parameters":{"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.message.content }}","id":"30f4cc34-cbec-4fca-8b91-e20aa43ddd65"},{"name":"provider","type":"string","value":"openai","id":"541ecad6-3b94-4836-96b0-b9781b984082"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"60f6d0c1-0884-4c00-bacc-53c73c86c2c2"}]},"options":{}},"id":"normalize-openai","name":"Normalize OpenAI","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,112]},{"parameters":{"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.output }}","id":"926dda93-2e9e-4dfc-8bc0-117cdd7411ec"},{"name":"provider","type":"string","value":"ollama","id":"e3f38e7d-5f10-4f83-93e4-a07d98b0d9ec"},{"name":"model","type":"string","value":"={{ $('Edit Fields').item.json.model }}","id":"97cf8ec6-5dfd-422c-b9ff-834a7af9af05"},{"name":"usage","type":"object","value":"={{ { prompt_tokens: $json.prompt_eval_count, completion_tokens: $json.eval_count } }}","id":"13a20d07-fc9f-4bac-aec5-98f4007f2b27"}]},"options":{}},"id":"normalize-ollama","name":"Normalize Ollama","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,304]},{"parameters":{"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.content[0].text }}"},{"name":"provider","type":"string","value":"anthropic"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"options":{}},"id":"normalize-anthropic","name":"Normalize Anthropic","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1200,528]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Edit Fields').item.json.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: $('Edit Fields').item.json.stepName,\\n  message: `Completed ${$('Edit Fields').item.json.stepName || 'task'}`,\\n  sequence: $('Edit Fields').item.json.sequence,\\n  totalSteps: $('Edit Fields').item.json.totalSteps,\\n  conversationId: $('Edit Fields').item.json.conversationId,\\n  userId: $('Edit Fields').item.json.userId\\n}) }}","options":{}},"id":"send-end-status","name":"Send End Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1584,224],"continueOnFail":true},{"parameters":{},"id":"execute-workflow-trigger","name":"Trigger","type":"n8n-nodes-base.executeWorkflowTrigger","typeVersion":1,"position":[-144,400]},{"parameters":{"assignments":{"assignments":[{"id":"12f8c18a-7b6e-4614-85bf-229053383b5c","name":"taskId","value":"={{ $json.taskId }}","type":"string"},{"id":"9028a85d-49ec-4801-a5a4-2d69221316ab","name":"conversationId","value":"={{ $json.conversationId}}","type":"string"},{"id":"3ff69eae-d1d9-4914-bc6b-373025caf3cd","name":"userId","value":"={{ $json.userId }}","type":"string"},{"id":"56ff3fd3-baf6-47c6-9d39-ac0b0ee08fe1","name":"provider","value":"={{ $json.provider }}","type":"string"},{"id":"ccff1938-95b6-4aa9-a5c2-920db7438e80","name":"model","value":"={{ $json.model }}","type":"string"},{"id":"78a2244a-5425-45ee-8aa2-b1fe99b5148d","name":"systemMessage","value":"={{ $json.systemMessage }}","type":"string"},{"id":"8e5dd07f-7174-48d1-b8e9-88e1d14ee329","name":"userMessage","value":"={{ $json.userMessage }}","type":"string"},{"id":"caaafbf9-3b3f-4af7-a781-5a4777759fe5","name":"stepName","value":"={{ $json.stepName }} ","type":"string"},{"id":"61b1529b-9cb1-4b73-b469-b835fc78767a","name":"sequence","value":"={{ $json.sequence }}","type":"number"},{"id":"c5163f91-4647-4a7c-b7b7-346abb4acb25","name":"statusWebhook","value":"={{ $json.statusWebhook }}","type":"string"},{"id":"3f34c0ff-db77-42a1-9d41-90abe27a1150","name":"=totalSteps","value":"={{ $json.totalSteps }}","type":"number"}]},"options":{}},"type":"n8n-nodes-base.set","typeVersion":3.4,"position":[96,288],"id":"81c83945-6bd0-41bb-9a6d-7c8eb2db9338","name":"Edit Fields"},{"parameters":{},"type":"n8n-nodes-base.noOp","typeVersion":1,"position":[1584,384],"id":"9d553c6b-ecae-4157-acf2-c5d6dff83eaa","name":"No Operation, do nothing"},{"parameters":{"options":{}},"type":"@n8n/n8n-nodes-langchain.lmChatOllama","typeVersion":1,"position":[928,400],"id":"84dbc11a-2747-4d17-ab88-d368279feb87","name":"Ollama Chat Model","credentials":{"ollamaApi":{"id":"hz52TIdzOn7p9IzY","name":"Ollama account"}}},{"parameters":{"modelId":{"__rl":true,"value":"={{ $json.model }}","mode":"id"},"messages":{"values":[{"content":"={{ $json['userMessage'] }}"},{"content":"={{ $json['systemMessage'] }}","role":"system"}]},"options":{}},"type":"@n8n/n8n-nodes-langchain.openAi","typeVersion":1.8,"position":[576,112],"id":"0f6dbcf1-2458-4881-8c32-a4619529064e","name":"OpenAI","credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"promptType":"define","text":"={{ $json['userMessage'] }}","options":{"systemMessage":"={{ $json['systemMessage'] }}"}},"type":"@n8n/n8n-nodes-langchain.agent","typeVersion":2.2,"position":[576,288],"id":"9ad2d867-3295-49ee-bfe9-d5641c47dcf1","name":"Ollama"},{"parameters":{"jsCode":"console.log('Received data:', JSON.stringify($input.all(), null, 2));\\nreturn $input.all();"},"type":"n8n-nodes-base.code","typeVersion":2,"position":[16,560],"id":"09f5c425-7ea8-45e3-82f2-55e072314d39","name":"Code in JavaScript"}]	{"Send Start Status":{"main":[[]]},"Select Provider":{"main":[[{"node":"OpenAI","type":"main","index":0}],[{"node":"Ollama","type":"main","index":0}],[{"node":"Anthropic Request","type":"main","index":0}],[],[]]},"Anthropic Request":{"main":[[{"node":"Normalize Anthropic","type":"main","index":0}]]},"Normalize OpenAI":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Ollama":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Normalize Anthropic":{"main":[[{"node":"Send End Status","type":"main","index":0},{"node":"No Operation, do nothing","type":"main","index":0}]]},"Trigger":{"main":[[{"node":"Edit Fields","type":"main","index":0},{"node":"Code in JavaScript","type":"main","index":0}]]},"Edit Fields":{"main":[[{"node":"Send Start Status","type":"main","index":0},{"node":"Select Provider","type":"main","index":0}]]},"Ollama Chat Model":{"ai_languageModel":[[{"node":"Ollama","type":"ai_languageModel","index":0}]]},"OpenAI":{"main":[[{"node":"Normalize OpenAI","type":"main","index":0}]]},"Ollama":{"main":[[{"node":"Normalize Ollama","type":"main","index":0}]]}}	2025-10-08 18:29:22.544+00	2025-10-11 06:27:38.143+00	{}	\N	{}	50dd25f5-908f-42f1-ab0c-eb475aab702c	0	9jxl03jCcqg17oOy	{"templateCredsSetupCompleted":true}	\N	f
Marketing Swarm - Major Announcement	t	[{"parameters":{"httpMethod":"POST","path":"marketing-swarm","responseMode":"responseNode","options":{}},"id":"webhook","name":"Webhook Trigger","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[112,112],"webhookId":"7f338c6b-a9bb-446b-9a1d-702739d89a51"},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"started","id":"dc91eaac-9dec-4613-a6b0-fc3db7a22a7d"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}","id":"22bd8856-784c-4ea2-b492-b5e12aea4616"},{"name":"executionId","type":"string","value":"={{ $execution.id }}","id":"4e7561bc-0907-4c69-9fd8-41a5a581154a"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}","id":"61326e64-42e5-417b-93d2-a521721bfe17"},{"name":"step","type":"string","value":"initialization","id":"f4d66a0c-32a4-4e9c-a9b4-b1fd733262bd"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}","id":"ab39d56d-368a-4c63-8bf8-6ae40b687351"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}","id":"b7375362-9b87-4da9-b1f7-66858474dab7"},{"name":"sequence","type":"number","value":1,"id":"79aaca09-b9cb-41e3-9b26-59ea458fe670"},{"name":"totalSteps","type":"number","value":5,"id":"e4dd4e33-f247-4f50-b678-7946403bfb37"}]},"options":{}},"id":"statusStart","name":"Status: Started","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,0]},{"parameters":{"method":"POST","url":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusStart","name":"Send Status: Started","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[512,0]},{"parameters":{"prompt":"=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.","options":{"maxTokens":1000,"temperature":0.7},"requestOptions":{}},"id":"webPost","name":"Generate Web Post","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[304,208],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"web_post_complete"},{"name":"webPost","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":2},{"name":"totalSteps","type":"number","value":5}]},"options":{}},"id":"statusWebPost","name":"Status: Web Post Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[512,208]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusWebPost","name":"Send Status: Web Post","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[704,112]},{"parameters":{"prompt":"=Create SEO-optimized content for: {{ $json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD.","options":{"maxTokens":800,"temperature":0.5},"requestOptions":{}},"id":"seoContent","name":"Generate SEO Content","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[704,304],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"seo_complete"},{"name":"seoContent","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":3},{"name":"totalSteps","type":"number","value":5}]},"options":{}},"id":"statusSEO","name":"Status: SEO Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[912,304]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusSEO","name":"Send Status: SEO","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1104,208]},{"parameters":{"prompt":"=Create social media posts for: {{ $json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags.","options":{"maxTokens":1200,"temperature":0.8},"requestOptions":{}},"id":"socialMedia","name":"Generate Social Media","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[1104,400],"credentials":{"openAiApi":{"id":"7tuOlNCTiyjK0BzN","name":"OpenAi account"}}},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"social_media_complete"},{"name":"socialMedia","type":"string","value":"={{ $('Generate Social Media').item.json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":4},{"name":"totalSteps","type":"number","value":5}]},"options":{}},"id":"statusSocial","name":"Status: Social Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1312,400]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusSocial","name":"Send Status: Social","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1504,304]},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"webPost","type":"string","value":"={{ $('Status: Web Post Done').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Status: SEO Done').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Status: Social Done').item.json.socialMedia }}"},{"name":"sequence","type":"number","value":5},{"name":"totalSteps","type":"number","value":5}]},"options":{}},"id":"finalOutput","name":"Final Output","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1504,512]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusComplete","name":"Send Status: Complete","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1712,512]},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Final Output').item.json.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Final Output').item.json.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Final Output').item.json.userId }}"},{"name":"executionId","type":"string","value":"={{ $('Final Output').item.json.executionId }}"},{"name":"timestamp","type":"string","value":"={{ $('Final Output').item.json.timestamp }}"},{"name":"webPost","type":"string","value":"={{ $('Final Output').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Final Output').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Final Output').item.json.socialMedia }}"}]},"options":{}},"id":"finalResponse","name":"Final Response","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1920,512]},{"parameters":{"respondWith":"json","responseBody":"={{ $json }}","options":{}},"id":"respondWebhook","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[2112,512]}]	{"Webhook Trigger":{"main":[[{"node":"Status: Started","type":"main","index":0},{"node":"Generate Web Post","type":"main","index":0}]]},"Status: Started":{"main":[[{"node":"Send Status: Started","type":"main","index":0}]]},"Generate Web Post":{"main":[[{"node":"Status: Web Post Done","type":"main","index":0}]]},"Status: Web Post Done":{"main":[[{"node":"Send Status: Web Post","type":"main","index":0},{"node":"Generate SEO Content","type":"main","index":0}]]},"Generate SEO Content":{"main":[[{"node":"Status: SEO Done","type":"main","index":0}]]},"Status: SEO Done":{"main":[[{"node":"Send Status: SEO","type":"main","index":0},{"node":"Generate Social Media","type":"main","index":0}]]},"Generate Social Media":{"main":[[{"node":"Status: Social Done","type":"main","index":0}]]},"Status: Social Done":{"main":[[{"node":"Send Status: Social","type":"main","index":0},{"node":"Final Output","type":"main","index":0}]]},"Final Output":{"main":[[{"node":"Send Status: Complete","type":"main","index":0}]]},"Send Status: Complete":{"main":[[{"node":"Final Response","type":"main","index":0}]]},"Final Response":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}}	2025-10-09 23:04:05.011+00	2025-10-10 19:58:25.658+00	{"saveDataErrorExecution":"none","callerPolicy":"workflowsFromSameOwner","executionOrder":"v1","saveDataSuccessExecution":"all"}	\N	{}	3cf7eef1-a38b-43c4-916e-4ea32f5a4e9b	1	Q08T7oMX2dZslqV4	\N	\N	f
Marketing Swarm - Flexible LLM	t	[{"parameters":{"httpMethod":"POST","path":"marketing-swarm-flexible","responseMode":"responseNode","options":{}},"id":"webhook","name":"Webhook","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[-16,304],"webhookId":"marketing-swarm-flex"},{"parameters":{"workflowId":{"__rl":true,"value":"9jxl03jCcqg17oOy","mode":"id"},"options":{}},"id":"web-post-task","name":"Web Post Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,144]},{"parameters":{"workflowId":{"__rl":true,"value":"9jxl03jCcqg17oOy","mode":"id","cachedResultUrl":"/workflow/9jxl03jCcqg17oOy"},"options":{}},"id":"seo-task","name":"SEO Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,304]},{"parameters":{"workflowId":{"__rl":true,"value":"9jxl03jCcqg17oOy","mode":"id","cachedResultUrl":"/workflow/9jxl03jCcqg17oOy"},"options":{}},"id":"social-task","name":"Social Media Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[912,480]},{"parameters":{"method":"POST","url":"={{ $('Webhook').item.json.body.statusWebHook }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\n  taskId: $('Webhook').item.json.body.taskId,\\n  status: 'completed',\\n  timestamp: new Date().toISOString(),\\n  step: 'swarm completed',\\n  message: 'Marketing Swarm workflow completed',\\n  sequence: 4,\\n  totalSteps: 4,\\n  conversationId: $('Webhook').item.json.body.conversationId,\\n  userId: $('WebHook').item.json.userId,\\n}) }}","options":{}},"id":"send-final-status","name":"Send Final Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1760,96],"continueOnFail":true},{"parameters":{"respondWith":"json","responseBody":"={{ JSON.stringify({\\n  \\"web post\\": $json.webPost,\\n  \\"seo\\": $json.seoContent,\\n  \\"social media\\": $json.socialMedia\\n}) }}","options":{}},"id":"respond","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[1760,240]},{"parameters":{"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}","id":"0e7e1195-46be-4104-ae35-19107420019d"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}","id":"997b9201-041c-4053-81f2-7e1f69ffe070"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}","id":"37100b7a-3727-4855-824f-2725e80d0440"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}","id":"c26c5743-8792-41fc-807a-65cc83a14ca1"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}","id":"f95fd7fb-df93-4dd3-8450-2830ce517fcd"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}","id":"56763026-b467-4e4b-b3fb-7842b63c1caf"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebHook }}","id":"5b5c4d3a-93bf-4f2d-aadf-e31b89a41079"},{"id":"a95859db-69f5-46c2-a895-883b3659deac","name":"systemMessage","value":"You are a social media content strategist. Create engaging social media posts (NOT blog posts) for multiple platforms: Twitter/X (280 chars with hashtags), LinkedIn (professional tone, 1300 chars max), and Facebook (conversational, 500 chars). Focus on hooks, engagement, and platform-specific best practices. Include relevant hashtags and emojis where appropriate.","type":"string"},{"id":"5c7b8969-c60a-42df-b9dc-84849e0f10a2","name":"userMessage","value":"={{ $json.body.announcement }}","type":"string"},{"id":"7b8664d1-0f50-4a1d-ad16-3867967041f8","name":"stepName","value":"Create Social Media","type":"string"},{"id":"291d34dd-2292-4cea-9432-3ae16b054053","name":"sequence","value":"3","type":"string"},{"id":"8cc15d2f-cab2-4691-b5ec-954ded016211","name":"totalSteps","value":"3","type":"string"}]},"options":{}},"id":"99b3b396-8e31-444e-aa5e-f652105cf9a7","name":"Social Media","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,480]},{"parameters":{"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}","id":"0e7e1195-46be-4104-ae35-19107420019d"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}","id":"997b9201-041c-4053-81f2-7e1f69ffe070"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}","id":"37100b7a-3727-4855-824f-2725e80d0440"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}","id":"c26c5743-8792-41fc-807a-65cc83a14ca1"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}","id":"f95fd7fb-df93-4dd3-8450-2830ce517fcd"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}","id":"56763026-b467-4e4b-b3fb-7842b63c1caf"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","id":"5b5c4d3a-93bf-4f2d-aadf-e31b89a41079"},{"id":"a95859db-69f5-46c2-a895-883b3659deac","name":"systemMessage","value":"You are an expert SEO specialist. Generate comprehensive SEO-optimized content including: meta title (60 chars max), meta description (155 chars max), 5-10 relevant keywords, H1 heading, and JSON-LD structured data for the given topic. Focus on search intent, readability, and technical SEO best practices.","type":"string"},{"id":"5c7b8969-c60a-42df-b9dc-84849e0f10a2","name":"userMessage","value":"={{ $json.body.announcement }}","type":"string"},{"id":"7b8664d1-0f50-4a1d-ad16-3867967041f8","name":"stepName","value":"Create SEO","type":"string"},{"id":"291d34dd-2292-4cea-9432-3ae16b054053","name":"sequence","value":2,"type":"number"},{"id":"8cc15d2f-cab2-4691-b5ec-954ded016211","name":"totalSteps","value":3,"type":"number"}]},"options":{}},"id":"c035862f-b3ef-48e8-b7d3-8226b0a0642a","name":"SEO","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,304]},{"parameters":{"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}","id":"0e7e1195-46be-4104-ae35-19107420019d"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}","id":"997b9201-041c-4053-81f2-7e1f69ffe070"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}","id":"37100b7a-3727-4855-824f-2725e80d0440"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}","id":"c26c5743-8792-41fc-807a-65cc83a14ca1"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}","id":"f95fd7fb-df93-4dd3-8450-2830ce517fcd"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}","id":"56763026-b467-4e4b-b3fb-7842b63c1caf"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","id":"5b5c4d3a-93bf-4f2d-aadf-e31b89a41079"},{"id":"a95859db-69f5-46c2-a895-883b3659deac","name":"systemMessage","value":"You are a brilliant blog post writer who specializes in being both entertaining and informative, and you're best known for being able to write posts for all audiences. ","type":"string"},{"id":"5c7b8969-c60a-42df-b9dc-84849e0f10a2","name":"userMessage","value":"={{ $json.body.announcement }}","type":"string"},{"id":"7b8664d1-0f50-4a1d-ad16-3867967041f8","name":"stepName","value":"Write Blog Post","type":"string"},{"id":"291d34dd-2292-4cea-9432-3ae16b054053","name":"sequence","value":1,"type":"number"},{"id":"8cc15d2f-cab2-4691-b5ec-954ded016211","name":"totalSteps","value":3,"type":"number"}]},"options":{}},"id":"extract-config","name":"Web Post","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,144]},{"parameters":{"numberInputs":3},"type":"n8n-nodes-base.merge","typeVersion":3.2,"position":[1264,224],"id":"9a602287-8e53-45f0-a320-517acc8c7912","name":"Merge"},{"parameters":{"jsCode":"// Get all 3 items from the merge\\nconst items = $input.all();\\n\\n// Combine them into a single object\\nreturn [{\\n  json: {\\n    webPost: items[0].json.text,\\n    seoContent: items[1].json.text,\\n    socialMedia: items[2].json.text\\n  }\\n}];"},"type":"n8n-nodes-base.code","typeVersion":2,"position":[1520,240],"id":"df59f646-cdbe-4d71-b958-db6a17c2d003","name":"Code in JavaScript"}]	{"Webhook":{"main":[[{"node":"Web Post","type":"main","index":0},{"node":"SEO","type":"main","index":0},{"node":"Social Media","type":"main","index":0}]]},"Web Post Task":{"main":[[{"node":"Merge","type":"main","index":0}]]},"SEO Task":{"main":[[{"node":"Merge","type":"main","index":1}]]},"Social Media Task":{"main":[[{"node":"Merge","type":"main","index":2}]]},"Send Final Status":{"main":[[]]},"Social Media":{"main":[[{"node":"Social Media Task","type":"main","index":0}]]},"SEO":{"main":[[{"node":"SEO Task","type":"main","index":0}]]},"Web Post":{"main":[[{"node":"Web Post Task","type":"main","index":0}]]},"Merge":{"main":[[{"node":"Code in JavaScript","type":"main","index":0}]]},"Code in JavaScript":{"main":[[{"node":"Respond to Webhook","type":"main","index":0},{"node":"Send Final Status","type":"main","index":0}]]}}	2025-10-08 18:41:15.406+00	2025-10-11 06:28:32.046+00	{}	\N	{}	9011a749-9328-4c75-9d7a-1578048ca754	1	1LaQnwqSoTxmnw3Z	\N	\N	f
\.


--
-- TOC entry 4382 (class 0 OID 18537)
-- Dependencies: 364
-- Data for Name: workflow_history; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflow_history ("versionId", "workflowId", authors, "createdAt", "updatedAt", nodes, connections) FROM stdin;
\.


--
-- TOC entry 4383 (class 0 OID 18544)
-- Dependencies: 365
-- Data for Name: workflow_statistics; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflow_statistics (count, "latestEvent", name, "workflowId", "rootCount") FROM stdin;
1	2025-10-10 12:47:55.156+00	data_loaded	Q08T7oMX2dZslqV4	1
4	2025-10-10 19:43:22.505+00	production_error	Q08T7oMX2dZslqV4	4
7	2025-10-10 19:46:12.765+00	manual_error	Q08T7oMX2dZslqV4	0
1	2025-10-10 20:11:02.386+00	data_loaded	1LaQnwqSoTxmnw3Z	1
26	2025-10-11 06:25:37.41+00	manual_success	9jxl03jCcqg17oOy	0
1	2025-10-11 06:29:01.481+00	production_success	1LaQnwqSoTxmnw3Z	1
1	2025-10-10 20:56:11.538+00	data_loaded	9jxl03jCcqg17oOy	1
30	2025-10-11 03:20:52.507+00	manual_error	9jxl03jCcqg17oOy	0
9	2025-10-13 19:01:57.785+00	production_error	9jxl03jCcqg17oOy	0
31	2025-10-13 19:01:57.792+00	manual_error	1LaQnwqSoTxmnw3Z	0
83	2025-10-13 19:03:23.665+00	production_success	9jxl03jCcqg17oOy	0
20	2025-10-13 19:03:23.693+00	manual_success	1LaQnwqSoTxmnw3Z	0
\.


--
-- TOC entry 4384 (class 0 OID 18549)
-- Dependencies: 366
-- Data for Name: workflows_tags; Type: TABLE DATA; Schema: n8n; Owner: postgres
--

COPY n8n.workflows_tags ("workflowId", "tagId") FROM stdin;
\.


--
-- TOC entry 4417 (class 0 OID 0)
-- Dependencies: 319
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.auth_provider_sync_history_id_seq', 1, false);


--
-- TOC entry 4418 (class 0 OID 0)
-- Dependencies: 326
-- Name: execution_annotations_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.execution_annotations_id_seq', 1, false);


--
-- TOC entry 4419 (class 0 OID 0)
-- Dependencies: 329
-- Name: execution_entity_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.execution_entity_id_seq', 216, true);


--
-- TOC entry 4420 (class 0 OID 0)
-- Dependencies: 331
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.execution_metadata_temp_id_seq', 1, false);


--
-- TOC entry 4421 (class 0 OID 0)
-- Dependencies: 335
-- Name: insights_by_period_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.insights_by_period_id_seq', 6, true);


--
-- TOC entry 4422 (class 0 OID 0)
-- Dependencies: 337
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n."insights_metadata_metaId_seq"', 2, true);


--
-- TOC entry 4423 (class 0 OID 0)
-- Dependencies: 339
-- Name: insights_raw_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.insights_raw_id_seq', 10, true);


--
-- TOC entry 4424 (class 0 OID 0)
-- Dependencies: 345
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: postgres
--

SELECT pg_catalog.setval('n8n.migrations_id_seq', 99, true);


--
-- TOC entry 4113 (class 2606 OID 19393)
-- Name: test_run PK_011c050f566e9db509a0fadb9b9; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_run
    ADD CONSTRAINT "PK_011c050f566e9db509a0fadb9b9" PRIMARY KEY (id);


--
-- TOC entry 4064 (class 2606 OID 19395)
-- Name: installed_packages PK_08cc9197c39b028c1e9beca225940576fd1a5804; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.installed_packages
    ADD CONSTRAINT "PK_08cc9197c39b028c1e9beca225940576fd1a5804" PRIMARY KEY ("packageName");


--
-- TOC entry 4047 (class 2606 OID 19397)
-- Name: execution_metadata PK_17a0b6284f8d626aae88e1c16e4; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_metadata
    ADD CONSTRAINT "PK_17a0b6284f8d626aae88e1c16e4" PRIMARY KEY (id);


--
-- TOC entry 4088 (class 2606 OID 19399)
-- Name: project_relation PK_1caaa312a5d7184a003be0f0cb6; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "PK_1caaa312a5d7184a003be0f0cb6" PRIMARY KEY ("projectId", "userId");


--
-- TOC entry 4052 (class 2606 OID 19401)
-- Name: folder_tag PK_27e4e00852f6b06a925a4d83a3e; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "PK_27e4e00852f6b06a925a4d83a3e" PRIMARY KEY ("folderId", "tagId");


--
-- TOC entry 4092 (class 2606 OID 19403)
-- Name: role PK_35c9b140caaf6da09cfabb0d675; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role
    ADD CONSTRAINT "PK_35c9b140caaf6da09cfabb0d675" PRIMARY KEY (slug);


--
-- TOC entry 4084 (class 2606 OID 19405)
-- Name: project PK_4d68b1358bb5b766d3e78f32f57; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project
    ADD CONSTRAINT "PK_4d68b1358bb5b766d3e78f32f57" PRIMARY KEY (id);


--
-- TOC entry 4066 (class 2606 OID 19407)
-- Name: invalid_auth_token PK_5779069b7235b256d91f7af1a15; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.invalid_auth_token
    ADD CONSTRAINT "PK_5779069b7235b256d91f7af1a15" PRIMARY KEY (token);


--
-- TOC entry 4103 (class 2606 OID 19409)
-- Name: shared_workflow PK_5ba87620386b847201c9531c58f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "PK_5ba87620386b847201c9531c58f" PRIMARY KEY ("workflowId", "projectId");


--
-- TOC entry 4050 (class 2606 OID 19411)
-- Name: folder PK_6278a41a706740c94c02e288df8; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "PK_6278a41a706740c94c02e288df8" PRIMARY KEY (id);


--
-- TOC entry 4025 (class 2606 OID 19413)
-- Name: data_table_column PK_673cb121ee4a8a5e27850c72c51; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "PK_673cb121ee4a8a5e27850c72c51" PRIMARY KEY (id);


--
-- TOC entry 4011 (class 2606 OID 19415)
-- Name: annotation_tag_entity PK_69dfa041592c30bbc0d4b84aa00; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.annotation_tag_entity
    ADD CONSTRAINT "PK_69dfa041592c30bbc0d4b84aa00" PRIMARY KEY (id);


--
-- TOC entry 4036 (class 2606 OID 19417)
-- Name: execution_annotations PK_7afcf93ffa20c4252869a7c6a23; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotations
    ADD CONSTRAINT "PK_7afcf93ffa20c4252869a7c6a23" PRIMARY KEY (id);


--
-- TOC entry 4072 (class 2606 OID 19419)
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- TOC entry 4062 (class 2606 OID 19421)
-- Name: installed_nodes PK_8ebd28194e4f792f96b5933423fc439df97d9689; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.installed_nodes
    ADD CONSTRAINT "PK_8ebd28194e4f792f96b5933423fc439df97d9689" PRIMARY KEY (name);


--
-- TOC entry 4101 (class 2606 OID 19423)
-- Name: shared_credentials PK_8ef3a59796a228913f251779cff; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "PK_8ef3a59796a228913f251779cff" PRIMARY KEY ("credentialsId", "projectId");


--
-- TOC entry 4110 (class 2606 OID 19425)
-- Name: test_case_execution PK_90c121f77a78a6580e94b794bce; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "PK_90c121f77a78a6580e94b794bce" PRIMARY KEY (id);


--
-- TOC entry 4122 (class 2606 OID 19427)
-- Name: user_api_keys PK_978fa5caa3468f463dac9d92e69; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.user_api_keys
    ADD CONSTRAINT "PK_978fa5caa3468f463dac9d92e69" PRIMARY KEY (id);


--
-- TOC entry 4033 (class 2606 OID 19429)
-- Name: execution_annotation_tags PK_979ec03d31294cca484be65d11f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "PK_979ec03d31294cca484be65d11f" PRIMARY KEY ("annotationId", "tagId");


--
-- TOC entry 4129 (class 2606 OID 19431)
-- Name: webhook_entity PK_b21ace2e13596ccd87dc9bf4ea6; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.webhook_entity
    ADD CONSTRAINT "PK_b21ace2e13596ccd87dc9bf4ea6" PRIMARY KEY ("webhookPath", method);


--
-- TOC entry 4055 (class 2606 OID 19433)
-- Name: insights_by_period PK_b606942249b90cc39b0265f0575; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_by_period
    ADD CONSTRAINT "PK_b606942249b90cc39b0265f0575" PRIMARY KEY (id);


--
-- TOC entry 4137 (class 2606 OID 19435)
-- Name: workflow_history PK_b6572dd6173e4cd06fe79937b58; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_history
    ADD CONSTRAINT "PK_b6572dd6173e4cd06fe79937b58" PRIMARY KEY ("versionId");


--
-- TOC entry 4097 (class 2606 OID 19437)
-- Name: scope PK_bfc45df0481abd7f355d6187da1; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.scope
    ADD CONSTRAINT "PK_bfc45df0481abd7f355d6187da1" PRIMARY KEY (slug);


--
-- TOC entry 4082 (class 2606 OID 19439)
-- Name: processed_data PK_ca04b9d8dc72de268fe07a65773; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.processed_data
    ADD CONSTRAINT "PK_ca04b9d8dc72de268fe07a65773" PRIMARY KEY ("workflowId", context);


--
-- TOC entry 4099 (class 2606 OID 19441)
-- Name: settings PK_dc0fe14e6d9943f268e7b119f69ab8bd; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.settings
    ADD CONSTRAINT "PK_dc0fe14e6d9943f268e7b119f69ab8bd" PRIMARY KEY (key);


--
-- TOC entry 4021 (class 2606 OID 19443)
-- Name: data_table PK_e226d0001b9e6097cbfe70617cb; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "PK_e226d0001b9e6097cbfe70617cb" PRIMARY KEY (id);


--
-- TOC entry 4115 (class 2606 OID 19445)
-- Name: user PK_ea8f538c94b6e352418254ed6474a81f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "PK_ea8f538c94b6e352418254ed6474a81f" PRIMARY KEY (id);


--
-- TOC entry 4060 (class 2606 OID 19447)
-- Name: insights_raw PK_ec15125755151e3a7e00e00014f; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_raw
    ADD CONSTRAINT "PK_ec15125755151e3a7e00e00014f" PRIMARY KEY (id);


--
-- TOC entry 4058 (class 2606 OID 19449)
-- Name: insights_metadata PK_f448a94c35218b6208ce20cf5a1; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "PK_f448a94c35218b6208ce20cf5a1" PRIMARY KEY ("metaId");


--
-- TOC entry 4095 (class 2606 OID 19451)
-- Name: role_scope PK_role_scope; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "PK_role_scope" PRIMARY KEY ("roleSlug", "scopeSlug");


--
-- TOC entry 4027 (class 2606 OID 19453)
-- Name: data_table_column UQ_8082ec4890f892f0bc77473a123; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "UQ_8082ec4890f892f0bc77473a123" UNIQUE ("dataTableId", name);


--
-- TOC entry 4023 (class 2606 OID 19455)
-- Name: data_table UQ_b23096ef747281ac944d28e8b0d; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "UQ_b23096ef747281ac944d28e8b0d" UNIQUE ("projectId", name);


--
-- TOC entry 4117 (class 2606 OID 19457)
-- Name: user UQ_e12875dfb3b1d92d7d7c5377e2; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e2" UNIQUE (email);


--
-- TOC entry 4013 (class 2606 OID 19459)
-- Name: auth_identity auth_identity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_identity
    ADD CONSTRAINT auth_identity_pkey PRIMARY KEY ("providerId", "providerType");


--
-- TOC entry 4015 (class 2606 OID 19461)
-- Name: auth_provider_sync_history auth_provider_sync_history_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_provider_sync_history
    ADD CONSTRAINT auth_provider_sync_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4017 (class 2606 OID 19463)
-- Name: credentials_entity credentials_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.credentials_entity
    ADD CONSTRAINT credentials_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 4029 (class 2606 OID 19465)
-- Name: event_destinations event_destinations_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.event_destinations
    ADD CONSTRAINT event_destinations_pkey PRIMARY KEY (id);


--
-- TOC entry 4038 (class 2606 OID 19467)
-- Name: execution_data execution_data_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_data
    ADD CONSTRAINT execution_data_pkey PRIMARY KEY ("executionId");


--
-- TOC entry 4070 (class 2606 OID 19469)
-- Name: migration_metadata migration_metadata_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migration_metadata
    ADD CONSTRAINT migration_metadata_pkey PRIMARY KEY (migration_file);


--
-- TOC entry 4078 (class 2606 OID 19471)
-- Name: n8n_workflows n8n_workflows_name_key; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.n8n_workflows
    ADD CONSTRAINT n8n_workflows_name_key UNIQUE (name);


--
-- TOC entry 4080 (class 2606 OID 19473)
-- Name: n8n_workflows n8n_workflows_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.n8n_workflows
    ADD CONSTRAINT n8n_workflows_pkey PRIMARY KEY (id);


--
-- TOC entry 4044 (class 2606 OID 19475)
-- Name: execution_entity pk_e3e63bbf986767844bbe1166d4e; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_entity
    ADD CONSTRAINT pk_e3e63bbf986767844bbe1166d4e PRIMARY KEY (id);


--
-- TOC entry 4139 (class 2606 OID 19477)
-- Name: workflow_statistics pk_workflow_statistics; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_statistics
    ADD CONSTRAINT pk_workflow_statistics PRIMARY KEY ("workflowId", name);


--
-- TOC entry 4142 (class 2606 OID 19479)
-- Name: workflows_tags pk_workflows_tags; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT pk_workflows_tags PRIMARY KEY ("workflowId", "tagId");


--
-- TOC entry 4107 (class 2606 OID 19481)
-- Name: tag_entity tag_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.tag_entity
    ADD CONSTRAINT tag_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 4125 (class 2606 OID 19483)
-- Name: variables variables_key_key; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.variables
    ADD CONSTRAINT variables_key_key UNIQUE (key);


--
-- TOC entry 4127 (class 2606 OID 19485)
-- Name: variables variables_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.variables
    ADD CONSTRAINT variables_pkey PRIMARY KEY (id);


--
-- TOC entry 4134 (class 2606 OID 19487)
-- Name: workflow_entity workflow_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_entity
    ADD CONSTRAINT workflow_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 4048 (class 1259 OID 19574)
-- Name: IDX_14f68deffaf858465715995508; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_14f68deffaf858465715995508" ON n8n.folder USING btree ("projectId", id);


--
-- TOC entry 4056 (class 1259 OID 19575)
-- Name: IDX_1d8ab99d5861c9388d2dc1cf73; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_1d8ab99d5861c9388d2dc1cf73" ON n8n.insights_metadata USING btree ("workflowId");


--
-- TOC entry 4135 (class 1259 OID 19576)
-- Name: IDX_1e31657f5fe46816c34be7c1b4; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_1e31657f5fe46816c34be7c1b4" ON n8n.workflow_history USING btree ("workflowId");


--
-- TOC entry 4119 (class 1259 OID 19577)
-- Name: IDX_1ef35bac35d20bdae979d917a3; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_1ef35bac35d20bdae979d917a3" ON n8n.user_api_keys USING btree ("apiKey");


--
-- TOC entry 4085 (class 1259 OID 19578)
-- Name: IDX_5f0643f6717905a05164090dde; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_5f0643f6717905a05164090dde" ON n8n.project_relation USING btree ("userId");


--
-- TOC entry 4053 (class 1259 OID 19579)
-- Name: IDX_60b6a84299eeb3f671dfec7693; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_60b6a84299eeb3f671dfec7693" ON n8n.insights_by_period USING btree ("periodStart", type, "periodUnit", "metaId");


--
-- TOC entry 4086 (class 1259 OID 19580)
-- Name: IDX_61448d56d61802b5dfde5cdb00; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_61448d56d61802b5dfde5cdb00" ON n8n.project_relation USING btree ("projectId");


--
-- TOC entry 4120 (class 1259 OID 19581)
-- Name: IDX_63d7bbae72c767cf162d459fcc; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_63d7bbae72c767cf162d459fcc" ON n8n.user_api_keys USING btree ("userId", label);


--
-- TOC entry 4108 (class 1259 OID 19582)
-- Name: IDX_8e4b4774db42f1e6dda3452b2a; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_8e4b4774db42f1e6dda3452b2a" ON n8n.test_case_execution USING btree ("testRunId");


--
-- TOC entry 4034 (class 1259 OID 19583)
-- Name: IDX_97f863fa83c4786f1956508496; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_97f863fa83c4786f1956508496" ON n8n.execution_annotations USING btree ("executionId");


--
-- TOC entry 4030 (class 1259 OID 19584)
-- Name: IDX_a3697779b366e131b2bbdae297; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_a3697779b366e131b2bbdae297" ON n8n.execution_annotation_tags USING btree ("tagId");


--
-- TOC entry 4009 (class 1259 OID 19585)
-- Name: IDX_ae51b54c4bb430cf92f48b623f; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_ae51b54c4bb430cf92f48b623f" ON n8n.annotation_tag_entity USING btree (name);


--
-- TOC entry 4031 (class 1259 OID 19586)
-- Name: IDX_c1519757391996eb06064f0e7c; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_c1519757391996eb06064f0e7c" ON n8n.execution_annotation_tags USING btree ("annotationId");


--
-- TOC entry 4045 (class 1259 OID 19587)
-- Name: IDX_cec8eea3bf49551482ccb4933e; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_cec8eea3bf49551482ccb4933e" ON n8n.execution_metadata USING btree ("executionId", key);


--
-- TOC entry 4111 (class 1259 OID 19588)
-- Name: IDX_d6870d3b6e4c185d33926f423c; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_d6870d3b6e4c185d33926f423c" ON n8n.test_run USING btree ("workflowId");


--
-- TOC entry 4039 (class 1259 OID 19589)
-- Name: IDX_execution_entity_deletedAt; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_execution_entity_deletedAt" ON n8n.execution_entity USING btree ("deletedAt");


--
-- TOC entry 4093 (class 1259 OID 19590)
-- Name: IDX_role_scope_scopeSlug; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_role_scope_scopeSlug" ON n8n.role_scope USING btree ("scopeSlug");


--
-- TOC entry 4131 (class 1259 OID 19591)
-- Name: IDX_workflow_entity_name; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX "IDX_workflow_entity_name" ON n8n.workflow_entity USING btree (name);


--
-- TOC entry 4018 (class 1259 OID 19592)
-- Name: idx_07fde106c0b471d8cc80a64fc8; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_07fde106c0b471d8cc80a64fc8 ON n8n.credentials_entity USING btree (type);


--
-- TOC entry 4130 (class 1259 OID 19593)
-- Name: idx_16f4436789e804e3e1c9eeb240; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_16f4436789e804e3e1c9eeb240 ON n8n.webhook_entity USING btree ("webhookId", method, "pathLength");


--
-- TOC entry 4104 (class 1259 OID 19594)
-- Name: idx_812eb05f7451ca757fb98444ce; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX idx_812eb05f7451ca757fb98444ce ON n8n.tag_entity USING btree (name);


--
-- TOC entry 4040 (class 1259 OID 19595)
-- Name: idx_execution_entity_stopped_at_status_deleted_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_execution_entity_stopped_at_status_deleted_at ON n8n.execution_entity USING btree ("stoppedAt", status, "deletedAt") WHERE (("stoppedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 4041 (class 1259 OID 19596)
-- Name: idx_execution_entity_wait_till_status_deleted_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_execution_entity_wait_till_status_deleted_at ON n8n.execution_entity USING btree ("waitTill", status, "deletedAt") WHERE (("waitTill" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 4042 (class 1259 OID 19597)
-- Name: idx_execution_entity_workflow_id_started_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_execution_entity_workflow_id_started_at ON n8n.execution_entity USING btree ("workflowId", "startedAt") WHERE (("startedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 4067 (class 1259 OID 19598)
-- Name: idx_migration_metadata_source; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_migration_metadata_source ON n8n.migration_metadata USING btree (source);


--
-- TOC entry 4068 (class 1259 OID 19599)
-- Name: idx_migration_metadata_workflow; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_migration_metadata_workflow ON n8n.migration_metadata USING btree (workflow_id);


--
-- TOC entry 4073 (class 1259 OID 19600)
-- Name: idx_n8n_workflows_active; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_active ON n8n.n8n_workflows USING btree (active);


--
-- TOC entry 4074 (class 1259 OID 19601)
-- Name: idx_n8n_workflows_name; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_name ON n8n.n8n_workflows USING btree (name);


--
-- TOC entry 4075 (class 1259 OID 19602)
-- Name: idx_n8n_workflows_updated; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_updated ON n8n.n8n_workflows USING btree (updated_at);


--
-- TOC entry 4076 (class 1259 OID 19603)
-- Name: idx_n8n_workflows_updated_at; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_n8n_workflows_updated_at ON n8n.n8n_workflows USING btree (updated_at DESC);


--
-- TOC entry 4140 (class 1259 OID 19604)
-- Name: idx_workflows_tags_workflow_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX idx_workflows_tags_workflow_id ON n8n.workflows_tags USING btree ("workflowId");


--
-- TOC entry 4019 (class 1259 OID 19605)
-- Name: pk_credentials_entity_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_credentials_entity_id ON n8n.credentials_entity USING btree (id);


--
-- TOC entry 4105 (class 1259 OID 19606)
-- Name: pk_tag_entity_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_tag_entity_id ON n8n.tag_entity USING btree (id);


--
-- TOC entry 4123 (class 1259 OID 19607)
-- Name: pk_variables_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_variables_id ON n8n.variables USING btree (id);


--
-- TOC entry 4132 (class 1259 OID 19608)
-- Name: pk_workflow_entity_id; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE UNIQUE INDEX pk_workflow_entity_id ON n8n.workflow_entity USING btree (id);


--
-- TOC entry 4089 (class 1259 OID 19609)
-- Name: project_relation_role_idx; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX project_relation_role_idx ON n8n.project_relation USING btree (role);


--
-- TOC entry 4090 (class 1259 OID 19610)
-- Name: project_relation_role_project_idx; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX project_relation_role_project_idx ON n8n.project_relation USING btree ("projectId", role);


--
-- TOC entry 4118 (class 1259 OID 19611)
-- Name: user_role_idx; Type: INDEX; Schema: n8n; Owner: postgres
--

CREATE INDEX user_role_idx ON n8n."user" USING btree ("roleSlug");


--
-- TOC entry 4162 (class 2606 OID 19711)
-- Name: processed_data FK_06a69a7032c97a763c2c7599464; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.processed_data
    ADD CONSTRAINT "FK_06a69a7032c97a763c2c7599464" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4157 (class 2606 OID 19716)
-- Name: insights_metadata FK_1d8ab99d5861c9388d2dc1cf733; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "FK_1d8ab99d5861c9388d2dc1cf733" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE SET NULL;


--
-- TOC entry 4179 (class 2606 OID 19721)
-- Name: workflow_history FK_1e31657f5fe46816c34be7c1b4b; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_history
    ADD CONSTRAINT "FK_1e31657f5fe46816c34be7c1b4b" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4158 (class 2606 OID 19726)
-- Name: insights_metadata FK_2375a1eda085adb16b24615b69c; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "FK_2375a1eda085adb16b24615b69c" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE SET NULL;


--
-- TOC entry 4151 (class 2606 OID 19731)
-- Name: execution_metadata FK_31d0b4c93fb85ced26f6005cda3; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_metadata
    ADD CONSTRAINT "FK_31d0b4c93fb85ced26f6005cda3" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4168 (class 2606 OID 19736)
-- Name: shared_credentials FK_416f66fc846c7c442970c094ccf; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "FK_416f66fc846c7c442970c094ccf" FOREIGN KEY ("credentialsId") REFERENCES n8n.credentials_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4163 (class 2606 OID 19741)
-- Name: project_relation FK_5f0643f6717905a05164090dde7; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_5f0643f6717905a05164090dde7" FOREIGN KEY ("userId") REFERENCES n8n."user"(id) ON DELETE CASCADE;


--
-- TOC entry 4164 (class 2606 OID 19746)
-- Name: project_relation FK_61448d56d61802b5dfde5cdb002; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_61448d56d61802b5dfde5cdb002" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4156 (class 2606 OID 19751)
-- Name: insights_by_period FK_6414cfed98daabbfdd61a1cfbc0; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_by_period
    ADD CONSTRAINT "FK_6414cfed98daabbfdd61a1cfbc0" FOREIGN KEY ("metaId") REFERENCES n8n.insights_metadata("metaId") ON DELETE CASCADE;


--
-- TOC entry 4159 (class 2606 OID 19756)
-- Name: insights_raw FK_6e2e33741adef2a7c5d66befa4e; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.insights_raw
    ADD CONSTRAINT "FK_6e2e33741adef2a7c5d66befa4e" FOREIGN KEY ("metaId") REFERENCES n8n.insights_metadata("metaId") ON DELETE CASCADE;


--
-- TOC entry 4160 (class 2606 OID 19761)
-- Name: installed_nodes FK_73f857fc5dce682cef8a99c11dbddbc969618951; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.installed_nodes
    ADD CONSTRAINT "FK_73f857fc5dce682cef8a99c11dbddbc969618951" FOREIGN KEY (package) REFERENCES n8n.installed_packages("packageName") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4152 (class 2606 OID 19766)
-- Name: folder FK_804ea52f6729e3940498bd54d78; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "FK_804ea52f6729e3940498bd54d78" FOREIGN KEY ("parentFolderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4169 (class 2606 OID 19771)
-- Name: shared_credentials FK_812c2852270da1247756e77f5a4; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "FK_812c2852270da1247756e77f5a4" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4172 (class 2606 OID 19776)
-- Name: test_case_execution FK_8e4b4774db42f1e6dda3452b2af; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "FK_8e4b4774db42f1e6dda3452b2af" FOREIGN KEY ("testRunId") REFERENCES n8n.test_run(id) ON DELETE CASCADE;


--
-- TOC entry 4145 (class 2606 OID 19781)
-- Name: data_table_column FK_930b6e8faaf88294cef23484160; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "FK_930b6e8faaf88294cef23484160" FOREIGN KEY ("dataTableId") REFERENCES n8n.data_table(id) ON DELETE CASCADE;


--
-- TOC entry 4154 (class 2606 OID 19786)
-- Name: folder_tag FK_94a60854e06f2897b2e0d39edba; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "FK_94a60854e06f2897b2e0d39edba" FOREIGN KEY ("folderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4148 (class 2606 OID 19791)
-- Name: execution_annotations FK_97f863fa83c4786f19565084960; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotations
    ADD CONSTRAINT "FK_97f863fa83c4786f19565084960" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4146 (class 2606 OID 19796)
-- Name: execution_annotation_tags FK_a3697779b366e131b2bbdae2976; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "FK_a3697779b366e131b2bbdae2976" FOREIGN KEY ("tagId") REFERENCES n8n.annotation_tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4170 (class 2606 OID 19801)
-- Name: shared_workflow FK_a45ea5f27bcfdc21af9b4188560; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "FK_a45ea5f27bcfdc21af9b4188560" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4153 (class 2606 OID 19806)
-- Name: folder FK_a8260b0b36939c6247f385b8221; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "FK_a8260b0b36939c6247f385b8221" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4147 (class 2606 OID 19811)
-- Name: execution_annotation_tags FK_c1519757391996eb06064f0e7c8; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "FK_c1519757391996eb06064f0e7c8" FOREIGN KEY ("annotationId") REFERENCES n8n.execution_annotations(id) ON DELETE CASCADE;


--
-- TOC entry 4144 (class 2606 OID 19816)
-- Name: data_table FK_c2a794257dee48af7c9abf681de; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "FK_c2a794257dee48af7c9abf681de" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4165 (class 2606 OID 19821)
-- Name: project_relation FK_c6b99592dc96b0d836d7a21db91; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_c6b99592dc96b0d836d7a21db91" FOREIGN KEY (role) REFERENCES n8n.role(slug);


--
-- TOC entry 4174 (class 2606 OID 19826)
-- Name: test_run FK_d6870d3b6e4c185d33926f423c8; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_run
    ADD CONSTRAINT "FK_d6870d3b6e4c185d33926f423c8" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4171 (class 2606 OID 19831)
-- Name: shared_workflow FK_daa206a04983d47d0a9c34649ce; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "FK_daa206a04983d47d0a9c34649ce" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4155 (class 2606 OID 19836)
-- Name: folder_tag FK_dc88164176283de80af47621746; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "FK_dc88164176283de80af47621746" FOREIGN KEY ("tagId") REFERENCES n8n.tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4176 (class 2606 OID 19841)
-- Name: user_api_keys FK_e131705cbbc8fb589889b02d457; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.user_api_keys
    ADD CONSTRAINT "FK_e131705cbbc8fb589889b02d457" FOREIGN KEY ("userId") REFERENCES n8n."user"(id) ON DELETE CASCADE;


--
-- TOC entry 4173 (class 2606 OID 19846)
-- Name: test_case_execution FK_e48965fac35d0f5b9e7f51d8c44; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "FK_e48965fac35d0f5b9e7f51d8c44" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE SET NULL;


--
-- TOC entry 4175 (class 2606 OID 19851)
-- Name: user FK_eaea92ee7bfb9c1b6cd01505d56; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "FK_eaea92ee7bfb9c1b6cd01505d56" FOREIGN KEY ("roleSlug") REFERENCES n8n.role(slug);


--
-- TOC entry 4166 (class 2606 OID 19856)
-- Name: role_scope FK_role; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "FK_role" FOREIGN KEY ("roleSlug") REFERENCES n8n.role(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4167 (class 2606 OID 19861)
-- Name: role_scope FK_scope; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "FK_scope" FOREIGN KEY ("scopeSlug") REFERENCES n8n.scope(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4143 (class 2606 OID 19866)
-- Name: auth_identity auth_identity_userId_fkey; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.auth_identity
    ADD CONSTRAINT "auth_identity_userId_fkey" FOREIGN KEY ("userId") REFERENCES n8n."user"(id);


--
-- TOC entry 4149 (class 2606 OID 19871)
-- Name: execution_data execution_data_fk; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_data
    ADD CONSTRAINT execution_data_fk FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4150 (class 2606 OID 19876)
-- Name: execution_entity fk_execution_entity_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.execution_entity
    ADD CONSTRAINT fk_execution_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4177 (class 2606 OID 19881)
-- Name: webhook_entity fk_webhook_entity_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.webhook_entity
    ADD CONSTRAINT fk_webhook_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4178 (class 2606 OID 19886)
-- Name: workflow_entity fk_workflow_parent_folder; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_entity
    ADD CONSTRAINT fk_workflow_parent_folder FOREIGN KEY ("parentFolderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4180 (class 2606 OID 19891)
-- Name: workflow_statistics fk_workflow_statistics_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflow_statistics
    ADD CONSTRAINT fk_workflow_statistics_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4181 (class 2606 OID 19896)
-- Name: workflows_tags fk_workflows_tags_tag_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_tag_id FOREIGN KEY ("tagId") REFERENCES n8n.tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4182 (class 2606 OID 19901)
-- Name: workflows_tags fk_workflows_tags_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4161 (class 2606 OID 19906)
-- Name: migration_metadata migration_metadata_workflow_id_fkey; Type: FK CONSTRAINT; Schema: n8n; Owner: postgres
--

ALTER TABLE ONLY n8n.migration_metadata
    ADD CONSTRAINT migration_metadata_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES n8n.n8n_workflows(id);


--
-- TOC entry 4392 (class 0 OID 0)
-- Dependencies: 4390
-- Name: DATABASE postgres; Type: ACL; Schema: -; Owner: postgres
--

GRANT CREATE ON DATABASE postgres TO supabase_etl_admin;
GRANT ALL ON DATABASE postgres TO dashboard_user;


--
-- TOC entry 2761 (class 826 OID 20089)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: n8n; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA n8n GRANT ALL ON SEQUENCES TO postgres;


--
-- TOC entry 2762 (class 826 OID 20090)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: n8n; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA n8n GRANT ALL ON TABLES TO postgres;


-- Completed on 2025-10-27 20:01:40 UTC

--
-- PostgreSQL database dump complete
--

