--
-- PostgreSQL database dump
--

-- Dumped from database version 15.8
-- Dumped by pg_dump version 15.8

-- Started on 2025-10-09 23:06:19 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 18 (class 2615 OID 16758)
-- Name: n8n; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA n8n;


--
-- TOC entry 4297 (class 0 OID 0)
-- Dependencies: 18
-- Name: SCHEMA n8n; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA n8n IS 'Schema for n8n workflow automation tables and data';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 354 (class 1259 OID 20076)
-- Name: annotation_tag_entity; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.annotation_tag_entity (
    id character varying(16) NOT NULL,
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 339 (class 1259 OID 19603)
-- Name: auth_identity; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.auth_identity (
    "userId" uuid,
    "providerId" character varying(64) NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 341 (class 1259 OID 19616)
-- Name: auth_provider_sync_history; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.auth_provider_sync_history (
    id integer NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "runMode" text NOT NULL,
    status text NOT NULL,
    "startedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    scanned integer NOT NULL,
    created integer NOT NULL,
    updated integer NOT NULL,
    disabled integer NOT NULL,
    error text
);


--
-- TOC entry 340 (class 1259 OID 19615)
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE; Schema: n8n; Owner: -
--

CREATE SEQUENCE n8n.auth_provider_sync_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4298 (class 0 OID 0)
-- Dependencies: 340
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: -
--

ALTER SEQUENCE n8n.auth_provider_sync_history_id_seq OWNED BY n8n.auth_provider_sync_history.id;


--
-- TOC entry 326 (class 1259 OID 19319)
-- Name: credentials_entity; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.credentials_entity (
    name character varying(128) NOT NULL,
    data text NOT NULL,
    type character varying(128) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL,
    "isManaged" boolean DEFAULT false NOT NULL
);


--
-- TOC entry 371 (class 1259 OID 20462)
-- Name: data_table; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.data_table (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 372 (class 1259 OID 20476)
-- Name: data_table_column; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.data_table_column (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    type character varying(32) NOT NULL,
    index integer NOT NULL,
    "dataTableId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 4299 (class 0 OID 0)
-- Dependencies: 372
-- Name: COLUMN data_table_column.type; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.data_table_column.type IS 'Expected: string, number, boolean, or date (not enforced as a constraint)';


--
-- TOC entry 4300 (class 0 OID 0)
-- Dependencies: 372
-- Name: COLUMN data_table_column.index; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.data_table_column.index IS 'Column order, starting from 0 (0 = first column)';


--
-- TOC entry 338 (class 1259 OID 19572)
-- Name: event_destinations; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.event_destinations (
    id uuid NOT NULL,
    destination jsonb NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 355 (class 1259 OID 20084)
-- Name: execution_annotation_tags; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.execution_annotation_tags (
    "annotationId" integer NOT NULL,
    "tagId" character varying(24) NOT NULL
);


--
-- TOC entry 353 (class 1259 OID 20060)
-- Name: execution_annotations; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.execution_annotations (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    vote character varying(6),
    note text,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 352 (class 1259 OID 20059)
-- Name: execution_annotations_id_seq; Type: SEQUENCE; Schema: n8n; Owner: -
--

CREATE SEQUENCE n8n.execution_annotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4301 (class 0 OID 0)
-- Dependencies: 352
-- Name: execution_annotations_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: -
--

ALTER SEQUENCE n8n.execution_annotations_id_seq OWNED BY n8n.execution_annotations.id;


--
-- TOC entry 343 (class 1259 OID 19711)
-- Name: execution_data; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.execution_data (
    "executionId" integer NOT NULL,
    "workflowData" json NOT NULL,
    data text NOT NULL
);


--
-- TOC entry 328 (class 1259 OID 19329)
-- Name: execution_entity; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.execution_entity (
    id integer NOT NULL,
    finished boolean NOT NULL,
    mode character varying NOT NULL,
    "retryOf" character varying,
    "retrySuccessId" character varying,
    "startedAt" timestamp(3) with time zone,
    "stoppedAt" timestamp(3) with time zone,
    "waitTill" timestamp(3) with time zone,
    status character varying NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "deletedAt" timestamp(3) with time zone,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 327 (class 1259 OID 19328)
-- Name: execution_entity_id_seq; Type: SEQUENCE; Schema: n8n; Owner: -
--

CREATE SEQUENCE n8n.execution_entity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4302 (class 0 OID 0)
-- Dependencies: 327
-- Name: execution_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: -
--

ALTER SEQUENCE n8n.execution_entity_id_seq OWNED BY n8n.execution_entity.id;


--
-- TOC entry 350 (class 1259 OID 20035)
-- Name: execution_metadata; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.execution_metadata (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL
);


--
-- TOC entry 349 (class 1259 OID 20034)
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE; Schema: n8n; Owner: -
--

CREATE SEQUENCE n8n.execution_metadata_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4303 (class 0 OID 0)
-- Dependencies: 349
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: -
--

ALTER SEQUENCE n8n.execution_metadata_temp_id_seq OWNED BY n8n.execution_metadata.id;


--
-- TOC entry 358 (class 1259 OID 20228)
-- Name: folder; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.folder (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "parentFolderId" character varying(36),
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 359 (class 1259 OID 20246)
-- Name: folder_tag; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.folder_tag (
    "folderId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


--
-- TOC entry 365 (class 1259 OID 20342)
-- Name: insights_by_period; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.insights_by_period (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "periodUnit" integer NOT NULL,
    "periodStart" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 4304 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN insights_by_period.type; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.insights_by_period.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- TOC entry 4305 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN insights_by_period."periodUnit"; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.insights_by_period."periodUnit" IS '0: hour, 1: day, 2: week';


--
-- TOC entry 364 (class 1259 OID 20341)
-- Name: insights_by_period_id_seq; Type: SEQUENCE; Schema: n8n; Owner: -
--

ALTER TABLE n8n.insights_by_period ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n.insights_by_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 361 (class 1259 OID 20313)
-- Name: insights_metadata; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.insights_metadata (
    "metaId" integer NOT NULL,
    "workflowId" character varying(16),
    "projectId" character varying(36),
    "workflowName" character varying(128) NOT NULL,
    "projectName" character varying(255) NOT NULL
);


--
-- TOC entry 360 (class 1259 OID 20312)
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE; Schema: n8n; Owner: -
--

ALTER TABLE n8n.insights_metadata ALTER COLUMN "metaId" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n."insights_metadata_metaId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 363 (class 1259 OID 20330)
-- Name: insights_raw; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.insights_raw (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "timestamp" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 4306 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN insights_raw.type; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.insights_raw.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- TOC entry 362 (class 1259 OID 20329)
-- Name: insights_raw_id_seq; Type: SEQUENCE; Schema: n8n; Owner: -
--

ALTER TABLE n8n.insights_raw ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME n8n.insights_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 336 (class 1259 OID 19521)
-- Name: installed_nodes; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.installed_nodes (
    name character varying(200) NOT NULL,
    type character varying(200) NOT NULL,
    "latestVersion" integer DEFAULT 1 NOT NULL,
    package character varying(241) NOT NULL
);


--
-- TOC entry 335 (class 1259 OID 19514)
-- Name: installed_packages; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.installed_packages (
    "packageName" character varying(214) NOT NULL,
    "installedVersion" character varying(50) NOT NULL,
    "authorName" character varying(70),
    "authorEmail" character varying(70),
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 351 (class 1259 OID 20049)
-- Name: invalid_auth_token; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.invalid_auth_token (
    token character varying(512) NOT NULL,
    "expiresAt" timestamp(3) with time zone NOT NULL
);


--
-- TOC entry 318 (class 1259 OID 19009)
-- Name: migration_metadata; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.migration_metadata (
    migration_file text NOT NULL,
    source text NOT NULL,
    workflow_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    synced_at timestamp with time zone DEFAULT now(),
    notes text,
    CONSTRAINT migration_metadata_source_check CHECK ((source = ANY (ARRAY['dev'::text, 'prod'::text, 'staging'::text])))
);


--
-- TOC entry 4307 (class 0 OID 0)
-- Dependencies: 318
-- Name: TABLE migration_metadata; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON TABLE n8n.migration_metadata IS 'Tracks n8n workflow migration sources and metadata (moved to n8n schema for better organization)';


--
-- TOC entry 4308 (class 0 OID 0)
-- Dependencies: 318
-- Name: COLUMN migration_metadata.source; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.migration_metadata.source IS 'Origin of the migration: dev, prod, or staging';


--
-- TOC entry 4309 (class 0 OID 0)
-- Dependencies: 318
-- Name: COLUMN migration_metadata.workflow_id; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.migration_metadata.workflow_id IS 'References the n8n workflow this migration manages';


--
-- TOC entry 325 (class 1259 OID 19310)
-- Name: migrations; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


--
-- TOC entry 324 (class 1259 OID 19309)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: n8n; Owner: -
--

CREATE SEQUENCE n8n.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4310 (class 0 OID 0)
-- Dependencies: 324
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: n8n; Owner: -
--

ALTER SEQUENCE n8n.migrations_id_seq OWNED BY n8n.migrations.id;


--
-- TOC entry 317 (class 1259 OID 18993)
-- Name: n8n_workflows; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.n8n_workflows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true,
    nodes jsonb DEFAULT '[]'::jsonb NOT NULL,
    connections jsonb DEFAULT '{}'::jsonb NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 4311 (class 0 OID 0)
-- Dependencies: 317
-- Name: TABLE n8n_workflows; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON TABLE n8n.n8n_workflows IS 'Stores n8n workflow definitions for sync between environments (moved from public schema)';


--
-- TOC entry 357 (class 1259 OID 20117)
-- Name: processed_data; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.processed_data (
    "workflowId" character varying(36) NOT NULL,
    context character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    value text NOT NULL
);


--
-- TOC entry 345 (class 1259 OID 19954)
-- Name: project; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.project (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    icon json,
    description character varying(512)
);


--
-- TOC entry 346 (class 1259 OID 19961)
-- Name: project_relation; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.project_relation (
    "projectId" character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    role character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 369 (class 1259 OID 20398)
-- Name: role; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.role (
    slug character varying(128) NOT NULL,
    "displayName" text,
    description text,
    "roleType" text,
    "systemRole" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 4312 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN role.slug; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.role.slug IS 'Unique identifier of the role for example: "global:owner"';


--
-- TOC entry 4313 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN role."displayName"; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.role."displayName" IS 'Name used to display in the UI';


--
-- TOC entry 4314 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN role.description; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.role.description IS 'Text describing the scope in more detail of users';


--
-- TOC entry 4315 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN role."roleType"; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.role."roleType" IS 'Type of the role, e.g., global, project, or workflow';


--
-- TOC entry 4316 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN role."systemRole"; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.role."systemRole" IS 'Indicates if the role is managed by the system and cannot be edited';


--
-- TOC entry 370 (class 1259 OID 20406)
-- Name: role_scope; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.role_scope (
    "roleSlug" character varying(128) NOT NULL,
    "scopeSlug" character varying(128) NOT NULL
);


--
-- TOC entry 368 (class 1259 OID 20391)
-- Name: scope; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.scope (
    slug character varying(128) NOT NULL,
    "displayName" text,
    description text
);


--
-- TOC entry 4317 (class 0 OID 0)
-- Dependencies: 368
-- Name: COLUMN scope.slug; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.scope.slug IS 'Unique identifier of the scope for example: "project:create"';


--
-- TOC entry 4318 (class 0 OID 0)
-- Dependencies: 368
-- Name: COLUMN scope."displayName"; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.scope."displayName" IS 'Name used to display in the UI';


--
-- TOC entry 4319 (class 0 OID 0)
-- Dependencies: 368
-- Name: COLUMN scope.description; Type: COMMENT; Schema: n8n; Owner: -
--

COMMENT ON COLUMN n8n.scope.description IS 'Text describing the scope in more detail of users';


--
-- TOC entry 334 (class 1259 OID 19506)
-- Name: settings; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.settings (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    "loadOnStartup" boolean DEFAULT false NOT NULL
);


--
-- TOC entry 347 (class 1259 OID 19989)
-- Name: shared_credentials; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.shared_credentials (
    "credentialsId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 348 (class 1259 OID 20015)
-- Name: shared_workflow; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.shared_workflow (
    "workflowId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 331 (class 1259 OID 19357)
-- Name: tag_entity; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.tag_entity (
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL
);


--
-- TOC entry 367 (class 1259 OID 20369)
-- Name: test_case_execution; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.test_case_execution (
    id character varying(36) NOT NULL,
    "testRunId" character varying(36) NOT NULL,
    "executionId" integer,
    status character varying NOT NULL,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    "errorCode" character varying,
    "errorDetails" json,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    inputs json,
    outputs json
);


--
-- TOC entry 366 (class 1259 OID 20354)
-- Name: test_run; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.test_run (
    id character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    status character varying NOT NULL,
    "errorCode" character varying,
    "errorDetails" json,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


--
-- TOC entry 333 (class 1259 OID 19443)
-- Name: user; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n."user" (
    id uuid DEFAULT uuid_in((OVERLAY(OVERLAY(md5((((random())::text || ':'::text) || (clock_timestamp())::text)) PLACING '4'::text FROM 13) PLACING to_hex((floor(((random() * (((11 - 8) + 1))::double precision) + (8)::double precision)))::integer) FROM 17))::cstring) NOT NULL,
    email character varying(255),
    "firstName" character varying(32),
    "lastName" character varying(32),
    password character varying(255),
    "personalizationAnswers" json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    disabled boolean DEFAULT false NOT NULL,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaSecret" text,
    "mfaRecoveryCodes" text,
    "lastActiveAt" date,
    "roleSlug" character varying(128) DEFAULT 'global:member'::character varying NOT NULL
);


--
-- TOC entry 356 (class 1259 OID 20101)
-- Name: user_api_keys; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.user_api_keys (
    id character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    label character varying(100) NOT NULL,
    "apiKey" character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    scopes json
);


--
-- TOC entry 342 (class 1259 OID 19627)
-- Name: variables; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.variables (
    key character varying(50) NOT NULL,
    type character varying(50) DEFAULT 'string'::character varying NOT NULL,
    value character varying(255),
    id character varying(36) NOT NULL
);


--
-- TOC entry 330 (class 1259 OID 19347)
-- Name: webhook_entity; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.webhook_entity (
    "webhookPath" character varying NOT NULL,
    method character varying NOT NULL,
    node character varying NOT NULL,
    "webhookId" character varying,
    "pathLength" integer,
    "workflowId" character varying(36) NOT NULL
);


--
-- TOC entry 329 (class 1259 OID 19339)
-- Name: workflow_entity; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.workflow_entity (
    name character varying(128) NOT NULL,
    active boolean NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    "staticData" json,
    "pinData" json,
    "versionId" character(36),
    "triggerCount" integer DEFAULT 0 NOT NULL,
    id character varying(36) NOT NULL,
    meta json,
    "parentFolderId" character varying(36) DEFAULT NULL::character varying,
    "isArchived" boolean DEFAULT false NOT NULL
);


--
-- TOC entry 344 (class 1259 OID 19725)
-- Name: workflow_history; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.workflow_history (
    "versionId" character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    authors character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL
);


--
-- TOC entry 337 (class 1259 OID 19542)
-- Name: workflow_statistics; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.workflow_statistics (
    count integer DEFAULT 0,
    "latestEvent" timestamp(3) with time zone,
    name character varying(128) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "rootCount" integer DEFAULT 0
);


--
-- TOC entry 332 (class 1259 OID 19364)
-- Name: workflows_tags; Type: TABLE; Schema: n8n; Owner: -
--

CREATE TABLE n8n.workflows_tags (
    "workflowId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


--
-- TOC entry 3879 (class 2604 OID 19619)
-- Name: auth_provider_sync_history id; Type: DEFAULT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.auth_provider_sync_history ALTER COLUMN id SET DEFAULT nextval('n8n.auth_provider_sync_history_id_seq'::regclass);


--
-- TOC entry 3894 (class 2604 OID 20063)
-- Name: execution_annotations id; Type: DEFAULT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_annotations ALTER COLUMN id SET DEFAULT nextval('n8n.execution_annotations_id_seq'::regclass);


--
-- TOC entry 3854 (class 2604 OID 19332)
-- Name: execution_entity id; Type: DEFAULT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_entity ALTER COLUMN id SET DEFAULT nextval('n8n.execution_entity_id_seq'::regclass);


--
-- TOC entry 3893 (class 2604 OID 20038)
-- Name: execution_metadata id; Type: DEFAULT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_metadata ALTER COLUMN id SET DEFAULT nextval('n8n.execution_metadata_temp_id_seq'::regclass);


--
-- TOC entry 3850 (class 2604 OID 19313)
-- Name: migrations id; Type: DEFAULT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.migrations ALTER COLUMN id SET DEFAULT nextval('n8n.migrations_id_seq'::regclass);


--
-- TOC entry 4273 (class 0 OID 20076)
-- Dependencies: 354
-- Data for Name: annotation_tag_entity; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.annotation_tag_entity (id, name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4258 (class 0 OID 19603)
-- Dependencies: 339
-- Data for Name: auth_identity; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.auth_identity ("userId", "providerId", "providerType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4260 (class 0 OID 19616)
-- Dependencies: 341
-- Data for Name: auth_provider_sync_history; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.auth_provider_sync_history (id, "providerType", "runMode", status, "startedAt", "endedAt", scanned, created, updated, disabled, error) FROM stdin;
\.


--
-- TOC entry 4245 (class 0 OID 19319)
-- Dependencies: 326
-- Data for Name: credentials_entity; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.credentials_entity (name, data, type, "createdAt", "updatedAt", id, "isManaged") FROM stdin;
\.


--
-- TOC entry 4290 (class 0 OID 20462)
-- Dependencies: 371
-- Data for Name: data_table; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.data_table (id, name, "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4291 (class 0 OID 20476)
-- Dependencies: 372
-- Data for Name: data_table_column; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.data_table_column (id, name, type, index, "dataTableId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4257 (class 0 OID 19572)
-- Dependencies: 338
-- Data for Name: event_destinations; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.event_destinations (id, destination, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4274 (class 0 OID 20084)
-- Dependencies: 355
-- Data for Name: execution_annotation_tags; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.execution_annotation_tags ("annotationId", "tagId") FROM stdin;
\.


--
-- TOC entry 4272 (class 0 OID 20060)
-- Dependencies: 353
-- Data for Name: execution_annotations; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.execution_annotations (id, "executionId", vote, note, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4262 (class 0 OID 19711)
-- Dependencies: 343
-- Data for Name: execution_data; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.execution_data ("executionId", "workflowData", data) FROM stdin;
\.


--
-- TOC entry 4247 (class 0 OID 19329)
-- Dependencies: 328
-- Data for Name: execution_entity; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.execution_entity (id, finished, mode, "retryOf", "retrySuccessId", "startedAt", "stoppedAt", "waitTill", status, "workflowId", "deletedAt", "createdAt") FROM stdin;
\.


--
-- TOC entry 4269 (class 0 OID 20035)
-- Dependencies: 350
-- Data for Name: execution_metadata; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.execution_metadata (id, "executionId", key, value) FROM stdin;
\.


--
-- TOC entry 4277 (class 0 OID 20228)
-- Dependencies: 358
-- Data for Name: folder; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.folder (id, name, "parentFolderId", "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4278 (class 0 OID 20246)
-- Dependencies: 359
-- Data for Name: folder_tag; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.folder_tag ("folderId", "tagId") FROM stdin;
\.


--
-- TOC entry 4284 (class 0 OID 20342)
-- Dependencies: 365
-- Data for Name: insights_by_period; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.insights_by_period (id, "metaId", type, value, "periodUnit", "periodStart") FROM stdin;
\.


--
-- TOC entry 4280 (class 0 OID 20313)
-- Dependencies: 361
-- Data for Name: insights_metadata; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.insights_metadata ("metaId", "workflowId", "projectId", "workflowName", "projectName") FROM stdin;
\.


--
-- TOC entry 4282 (class 0 OID 20330)
-- Dependencies: 363
-- Data for Name: insights_raw; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.insights_raw (id, "metaId", type, value, "timestamp") FROM stdin;
\.


--
-- TOC entry 4255 (class 0 OID 19521)
-- Dependencies: 336
-- Data for Name: installed_nodes; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.installed_nodes (name, type, "latestVersion", package) FROM stdin;
\.


--
-- TOC entry 4254 (class 0 OID 19514)
-- Dependencies: 335
-- Data for Name: installed_packages; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.installed_packages ("packageName", "installedVersion", "authorName", "authorEmail", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4270 (class 0 OID 20049)
-- Dependencies: 351
-- Data for Name: invalid_auth_token; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.invalid_auth_token (token, "expiresAt") FROM stdin;
\.


--
-- TOC entry 4242 (class 0 OID 19009)
-- Dependencies: 318
-- Data for Name: migration_metadata; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.migration_metadata (migration_file, source, workflow_id, created_at, synced_at, notes) FROM stdin;
\.


--
-- TOC entry 4244 (class 0 OID 19310)
-- Dependencies: 325
-- Data for Name: migrations; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.migrations (id, "timestamp", name) FROM stdin;
1	1587669153312	InitialMigration1587669153312
2	1589476000887	WebhookModel1589476000887
3	1594828256133	CreateIndexStoppedAt1594828256133
4	1607431743768	MakeStoppedAtNullable1607431743768
5	1611144599516	AddWebhookId1611144599516
6	1617270242566	CreateTagEntity1617270242566
7	1620824779533	UniqueWorkflowNames1620824779533
8	1626176912946	AddwaitTill1626176912946
9	1630419189837	UpdateWorkflowCredentials1630419189837
10	1644422880309	AddExecutionEntityIndexes1644422880309
11	1646834195327	IncreaseTypeVarcharLimit1646834195327
12	1646992772331	CreateUserManagement1646992772331
13	1648740597343	LowerCaseUserEmail1648740597343
14	1652254514002	CommunityNodes1652254514002
15	1652367743993	AddUserSettings1652367743993
16	1652905585850	AddAPIKeyColumn1652905585850
17	1654090467022	IntroducePinData1654090467022
18	1658932090381	AddNodeIds1658932090381
19	1659902242948	AddJsonKeyPinData1659902242948
20	1660062385367	CreateCredentialsUserRole1660062385367
21	1663755770893	CreateWorkflowsEditorRole1663755770893
22	1664196174001	WorkflowStatistics1664196174001
23	1665484192212	CreateCredentialUsageTable1665484192212
24	1665754637025	RemoveCredentialUsageTable1665754637025
25	1669739707126	AddWorkflowVersionIdColumn1669739707126
26	1669823906995	AddTriggerCountColumn1669823906995
27	1671535397530	MessageEventBusDestinations1671535397530
28	1671726148421	RemoveWorkflowDataLoadedFlag1671726148421
29	1673268682475	DeleteExecutionsWithWorkflows1673268682475
30	1674138566000	AddStatusToExecutions1674138566000
31	1674509946020	CreateLdapEntities1674509946020
32	1675940580449	PurgeInvalidWorkflowConnections1675940580449
33	1676996103000	MigrateExecutionStatus1676996103000
34	1677236854063	UpdateRunningExecutionStatus1677236854063
35	1677501636754	CreateVariables1677501636754
36	1679416281778	CreateExecutionMetadataTable1679416281778
37	1681134145996	AddUserActivatedProperty1681134145996
38	1681134145997	RemoveSkipOwnerSetup1681134145997
39	1690000000000	MigrateIntegerKeysToString1690000000000
40	1690000000020	SeparateExecutionData1690000000020
41	1690000000030	RemoveResetPasswordColumns1690000000030
42	1690000000030	AddMfaColumns1690000000030
43	1690787606731	AddMissingPrimaryKeyOnExecutionData1690787606731
44	1691088862123	CreateWorkflowNameIndex1691088862123
45	1692967111175	CreateWorkflowHistoryTable1692967111175
46	1693491613982	ExecutionSoftDelete1693491613982
47	1693554410387	DisallowOrphanExecutions1693554410387
48	1694091729095	MigrateToTimestampTz1694091729095
49	1695128658538	AddWorkflowMetadata1695128658538
50	1695829275184	ModifyWorkflowHistoryNodesAndConnections1695829275184
51	1700571993961	AddGlobalAdminRole1700571993961
52	1705429061930	DropRoleMapping1705429061930
53	1711018413374	RemoveFailedExecutionStatus1711018413374
54	1711390882123	MoveSshKeysToDatabase1711390882123
55	1712044305787	RemoveNodesAccess1712044305787
56	1714133768519	CreateProject1714133768519
57	1714133768521	MakeExecutionStatusNonNullable1714133768521
58	1717498465931	AddActivatedAtUserSetting1717498465931
59	1720101653148	AddConstraintToExecutionMetadata1720101653148
60	1721377157740	FixExecutionMetadataSequence1721377157740
61	1723627610222	CreateInvalidAuthTokenTable1723627610222
62	1723796243146	RefactorExecutionIndices1723796243146
63	1724753530828	CreateAnnotationTables1724753530828
64	1724951148974	AddApiKeysTable1724951148974
65	1726606152711	CreateProcessedDataTable1726606152711
66	1727427440136	SeparateExecutionCreationFromStart1727427440136
67	1728659839644	AddMissingPrimaryKeyOnAnnotationTagMapping1728659839644
68	1729607673464	UpdateProcessedDataValueColumnToText1729607673464
69	1729607673469	AddProjectIcons1729607673469
70	1730386903556	CreateTestDefinitionTable1730386903556
71	1731404028106	AddDescriptionToTestDefinition1731404028106
72	1731582748663	MigrateTestDefinitionKeyToString1731582748663
73	1732271325258	CreateTestMetricTable1732271325258
74	1732549866705	CreateTestRun1732549866705
75	1733133775640	AddMockedNodesColumnToTestDefinition1733133775640
76	1734479635324	AddManagedColumnToCredentialsTable1734479635324
77	1736172058779	AddStatsColumnsToTestRun1736172058779
78	1736947513045	CreateTestCaseExecutionTable1736947513045
79	1737715421462	AddErrorColumnsToTestRuns1737715421462
80	1738709609940	CreateFolderTable1738709609940
81	1739549398681	CreateAnalyticsTables1739549398681
82	1740445074052	UpdateParentFolderIdColumn1740445074052
83	1741167584277	RenameAnalyticsToInsights1741167584277
84	1742918400000	AddScopesColumnToApiKeys1742918400000
85	1745322634000	ClearEvaluation1745322634000
86	1745587087521	AddWorkflowStatisticsRootCount1745587087521
87	1745934666076	AddWorkflowArchivedColumn1745934666076
88	1745934666077	DropRoleTable1745934666077
89	1747824239000	AddProjectDescriptionColumn1747824239000
90	1750252139166	AddLastActiveAtColumnToUser1750252139166
91	1750252139166	AddScopeTables1750252139166
92	1750252139167	AddRolesTables1750252139167
93	1750252139168	LinkRoleToUserTable1750252139168
94	1750252139170	RemoveOldRoleColumn1750252139170
95	1752669793000	AddInputsOutputsToTestCaseExecution1752669793000
96	1753953244168	LinkRoleToProjectRelationTable1753953244168
97	1754475614601	CreateDataStoreTables1754475614601
98	1754475614602	ReplaceDataStoreTablesWithDataTables1754475614602
99	1756906557570	AddTimestampsToRoleAndRoleIndexes1756906557570
\.


--
-- TOC entry 4241 (class 0 OID 18993)
-- Dependencies: 317
-- Data for Name: n8n_workflows; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.n8n_workflows (id, name, active, nodes, connections, settings, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4276 (class 0 OID 20117)
-- Dependencies: 357
-- Data for Name: processed_data; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.processed_data ("workflowId", context, "createdAt", "updatedAt", value) FROM stdin;
\.


--
-- TOC entry 4264 (class 0 OID 19954)
-- Dependencies: 345
-- Data for Name: project; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.project (id, name, type, "createdAt", "updatedAt", icon, description) FROM stdin;
i9Hx3voRXPvZMWtL	Golfer Geek <golfergeek@orchestratorai.io>	personal	2025-10-09 20:29:48.678+00	2025-10-09 20:45:39.243+00	\N	\N
\.


--
-- TOC entry 4265 (class 0 OID 19961)
-- Dependencies: 346
-- Data for Name: project_relation; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.project_relation ("projectId", "userId", role, "createdAt", "updatedAt") FROM stdin;
i9Hx3voRXPvZMWtL	9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	project:personalOwner	2025-10-09 20:29:48.678+00	2025-10-09 20:29:48.678+00
\.


--
-- TOC entry 4288 (class 0 OID 20398)
-- Dependencies: 369
-- Data for Name: role; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.role (slug, "displayName", description, "roleType", "systemRole", "createdAt", "updatedAt") FROM stdin;
global:owner	Owner	Owner	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
global:admin	Admin	Admin	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
global:member	Member	Member	global	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.285+00
project:admin	Project Admin	Project Admin	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:personalOwner	Project Owner	Project Owner	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:editor	Project Editor	Project Editor	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
project:viewer	Project Viewer	Project Viewer	project	t	2025-10-09 20:29:49.222+00	2025-10-09 20:29:49.301+00
credential:owner	Credential Owner	Credential Owner	credential	t	2025-10-09 20:29:49.31+00	2025-10-09 20:29:49.31+00
credential:user	Credential User	Credential User	credential	t	2025-10-09 20:29:49.31+00	2025-10-09 20:29:49.31+00
workflow:owner	Workflow Owner	Workflow Owner	workflow	t	2025-10-09 20:29:49.315+00	2025-10-09 20:29:49.315+00
workflow:editor	Workflow Editor	Workflow Editor	workflow	t	2025-10-09 20:29:49.315+00	2025-10-09 20:29:49.315+00
\.


--
-- TOC entry 4289 (class 0 OID 20406)
-- Dependencies: 370
-- Data for Name: role_scope; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.role_scope ("roleSlug", "scopeSlug") FROM stdin;
global:owner	annotationTag:create
global:owner	annotationTag:read
global:owner	annotationTag:update
global:owner	annotationTag:delete
global:owner	annotationTag:list
global:owner	auditLogs:manage
global:owner	banner:dismiss
global:owner	community:register
global:owner	communityPackage:install
global:owner	communityPackage:uninstall
global:owner	communityPackage:update
global:owner	communityPackage:list
global:owner	credential:share
global:owner	credential:move
global:owner	credential:create
global:owner	credential:read
global:owner	credential:update
global:owner	credential:delete
global:owner	credential:list
global:owner	externalSecretsProvider:sync
global:owner	externalSecretsProvider:create
global:owner	externalSecretsProvider:read
global:owner	externalSecretsProvider:update
global:owner	externalSecretsProvider:delete
global:owner	externalSecretsProvider:list
global:owner	externalSecret:list
global:owner	externalSecret:use
global:owner	eventBusDestination:test
global:owner	eventBusDestination:create
global:owner	eventBusDestination:read
global:owner	eventBusDestination:update
global:owner	eventBusDestination:delete
global:owner	eventBusDestination:list
global:owner	ldap:sync
global:owner	ldap:manage
global:owner	license:manage
global:owner	logStreaming:manage
global:owner	orchestration:read
global:owner	project:create
global:owner	project:read
global:owner	project:update
global:owner	project:delete
global:owner	project:list
global:owner	saml:manage
global:owner	securityAudit:generate
global:owner	sourceControl:pull
global:owner	sourceControl:push
global:owner	sourceControl:manage
global:owner	tag:create
global:owner	tag:read
global:owner	tag:update
global:owner	tag:delete
global:owner	tag:list
global:owner	user:resetPassword
global:owner	user:changeRole
global:owner	user:enforceMfa
global:owner	user:create
global:owner	user:read
global:owner	user:update
global:owner	user:delete
global:owner	user:list
global:owner	variable:create
global:owner	variable:read
global:owner	variable:update
global:owner	variable:delete
global:owner	variable:list
global:owner	workersView:manage
global:owner	workflow:share
global:owner	workflow:execute
global:owner	workflow:move
global:owner	workflow:create
global:owner	workflow:read
global:owner	workflow:update
global:owner	workflow:delete
global:owner	workflow:list
global:owner	folder:create
global:owner	folder:read
global:owner	folder:update
global:owner	folder:delete
global:owner	folder:list
global:owner	folder:move
global:owner	insights:list
global:owner	oidc:manage
global:owner	dataStore:list
global:owner	role:manage
global:admin	annotationTag:create
global:admin	annotationTag:read
global:admin	annotationTag:update
global:admin	annotationTag:delete
global:admin	annotationTag:list
global:admin	auditLogs:manage
global:admin	banner:dismiss
global:admin	community:register
global:admin	communityPackage:install
global:admin	communityPackage:uninstall
global:admin	communityPackage:update
global:admin	communityPackage:list
global:admin	credential:share
global:admin	credential:move
global:admin	credential:create
global:admin	credential:read
global:admin	credential:update
global:admin	credential:delete
global:admin	credential:list
global:admin	externalSecretsProvider:sync
global:admin	externalSecretsProvider:create
global:admin	externalSecretsProvider:read
global:admin	externalSecretsProvider:update
global:admin	externalSecretsProvider:delete
global:admin	externalSecretsProvider:list
global:admin	externalSecret:list
global:admin	externalSecret:use
global:admin	eventBusDestination:test
global:admin	eventBusDestination:create
global:admin	eventBusDestination:read
global:admin	eventBusDestination:update
global:admin	eventBusDestination:delete
global:admin	eventBusDestination:list
global:admin	ldap:sync
global:admin	ldap:manage
global:admin	license:manage
global:admin	logStreaming:manage
global:admin	orchestration:read
global:admin	project:create
global:admin	project:read
global:admin	project:update
global:admin	project:delete
global:admin	project:list
global:admin	saml:manage
global:admin	securityAudit:generate
global:admin	sourceControl:pull
global:admin	sourceControl:push
global:admin	sourceControl:manage
global:admin	tag:create
global:admin	tag:read
global:admin	tag:update
global:admin	tag:delete
global:admin	tag:list
global:admin	user:resetPassword
global:admin	user:changeRole
global:admin	user:enforceMfa
global:admin	user:create
global:admin	user:read
global:admin	user:update
global:admin	user:delete
global:admin	user:list
global:admin	variable:create
global:admin	variable:read
global:admin	variable:update
global:admin	variable:delete
global:admin	variable:list
global:admin	workersView:manage
global:admin	workflow:share
global:admin	workflow:execute
global:admin	workflow:move
global:admin	workflow:create
global:admin	workflow:read
global:admin	workflow:update
global:admin	workflow:delete
global:admin	workflow:list
global:admin	folder:create
global:admin	folder:read
global:admin	folder:update
global:admin	folder:delete
global:admin	folder:list
global:admin	folder:move
global:admin	insights:list
global:admin	oidc:manage
global:admin	dataStore:list
global:admin	role:manage
global:member	annotationTag:create
global:member	annotationTag:read
global:member	annotationTag:update
global:member	annotationTag:delete
global:member	annotationTag:list
global:member	eventBusDestination:test
global:member	eventBusDestination:list
global:member	tag:create
global:member	tag:read
global:member	tag:update
global:member	tag:list
global:member	user:list
global:member	variable:read
global:member	variable:list
global:member	dataStore:list
project:admin	credential:share
project:admin	credential:move
project:admin	credential:create
project:admin	credential:read
project:admin	credential:update
project:admin	credential:delete
project:admin	credential:list
project:admin	project:read
project:admin	project:update
project:admin	project:delete
project:admin	project:list
project:admin	sourceControl:push
project:admin	workflow:execute
project:admin	workflow:move
project:admin	workflow:create
project:admin	workflow:read
project:admin	workflow:update
project:admin	workflow:delete
project:admin	workflow:list
project:admin	folder:create
project:admin	folder:read
project:admin	folder:update
project:admin	folder:delete
project:admin	folder:list
project:admin	folder:move
project:admin	dataStore:create
project:admin	dataStore:read
project:admin	dataStore:update
project:admin	dataStore:delete
project:admin	dataStore:readRow
project:admin	dataStore:writeRow
project:admin	dataStore:listProject
project:personalOwner	credential:share
project:personalOwner	credential:move
project:personalOwner	credential:create
project:personalOwner	credential:read
project:personalOwner	credential:update
project:personalOwner	credential:delete
project:personalOwner	credential:list
project:personalOwner	project:read
project:personalOwner	project:list
project:personalOwner	workflow:share
project:personalOwner	workflow:execute
project:personalOwner	workflow:move
project:personalOwner	workflow:create
project:personalOwner	workflow:read
project:personalOwner	workflow:update
project:personalOwner	workflow:delete
project:personalOwner	workflow:list
project:personalOwner	folder:create
project:personalOwner	folder:read
project:personalOwner	folder:update
project:personalOwner	folder:delete
project:personalOwner	folder:list
project:personalOwner	folder:move
project:personalOwner	dataStore:create
project:personalOwner	dataStore:read
project:personalOwner	dataStore:update
project:personalOwner	dataStore:delete
project:personalOwner	dataStore:readRow
project:personalOwner	dataStore:writeRow
project:personalOwner	dataStore:listProject
project:editor	credential:create
project:editor	credential:read
project:editor	credential:update
project:editor	credential:delete
project:editor	credential:list
project:editor	project:read
project:editor	project:list
project:editor	workflow:execute
project:editor	workflow:create
project:editor	workflow:read
project:editor	workflow:update
project:editor	workflow:delete
project:editor	workflow:list
project:editor	folder:create
project:editor	folder:read
project:editor	folder:update
project:editor	folder:delete
project:editor	folder:list
project:editor	dataStore:create
project:editor	dataStore:read
project:editor	dataStore:update
project:editor	dataStore:delete
project:editor	dataStore:readRow
project:editor	dataStore:writeRow
project:editor	dataStore:listProject
project:viewer	credential:read
project:viewer	credential:list
project:viewer	project:read
project:viewer	project:list
project:viewer	workflow:read
project:viewer	workflow:list
project:viewer	folder:read
project:viewer	folder:list
project:viewer	dataStore:read
project:viewer	dataStore:readRow
project:viewer	dataStore:listProject
credential:owner	credential:share
credential:owner	credential:move
credential:owner	credential:read
credential:owner	credential:update
credential:owner	credential:delete
credential:user	credential:read
workflow:owner	workflow:share
workflow:owner	workflow:execute
workflow:owner	workflow:move
workflow:owner	workflow:read
workflow:owner	workflow:update
workflow:owner	workflow:delete
workflow:editor	workflow:execute
workflow:editor	workflow:read
workflow:editor	workflow:update
\.


--
-- TOC entry 4287 (class 0 OID 20391)
-- Dependencies: 368
-- Data for Name: scope; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.scope (slug, "displayName", description) FROM stdin;
annotationTag:create	Create Annotation Tag	Allows creating new annotation tags.
annotationTag:read	annotationTag:read	\N
annotationTag:update	annotationTag:update	\N
annotationTag:delete	annotationTag:delete	\N
annotationTag:list	annotationTag:list	\N
annotationTag:*	annotationTag:*	\N
auditLogs:manage	auditLogs:manage	\N
auditLogs:*	auditLogs:*	\N
banner:dismiss	banner:dismiss	\N
banner:*	banner:*	\N
community:register	community:register	\N
community:*	community:*	\N
communityPackage:install	communityPackage:install	\N
communityPackage:uninstall	communityPackage:uninstall	\N
communityPackage:update	communityPackage:update	\N
communityPackage:list	communityPackage:list	\N
communityPackage:manage	communityPackage:manage	\N
communityPackage:*	communityPackage:*	\N
credential:share	credential:share	\N
credential:move	credential:move	\N
credential:create	credential:create	\N
credential:read	credential:read	\N
credential:update	credential:update	\N
credential:delete	credential:delete	\N
credential:list	credential:list	\N
credential:*	credential:*	\N
externalSecretsProvider:sync	externalSecretsProvider:sync	\N
externalSecretsProvider:create	externalSecretsProvider:create	\N
externalSecretsProvider:read	externalSecretsProvider:read	\N
externalSecretsProvider:update	externalSecretsProvider:update	\N
externalSecretsProvider:delete	externalSecretsProvider:delete	\N
externalSecretsProvider:list	externalSecretsProvider:list	\N
externalSecretsProvider:*	externalSecretsProvider:*	\N
externalSecret:list	externalSecret:list	\N
externalSecret:use	externalSecret:use	\N
externalSecret:*	externalSecret:*	\N
eventBusDestination:test	eventBusDestination:test	\N
eventBusDestination:create	eventBusDestination:create	\N
eventBusDestination:read	eventBusDestination:read	\N
eventBusDestination:update	eventBusDestination:update	\N
eventBusDestination:delete	eventBusDestination:delete	\N
eventBusDestination:list	eventBusDestination:list	\N
eventBusDestination:*	eventBusDestination:*	\N
ldap:sync	ldap:sync	\N
ldap:manage	ldap:manage	\N
ldap:*	ldap:*	\N
license:manage	license:manage	\N
license:*	license:*	\N
logStreaming:manage	logStreaming:manage	\N
logStreaming:*	logStreaming:*	\N
orchestration:read	orchestration:read	\N
orchestration:list	orchestration:list	\N
orchestration:*	orchestration:*	\N
project:create	project:create	\N
project:read	project:read	\N
project:update	project:update	\N
project:delete	project:delete	\N
project:list	project:list	\N
project:*	project:*	\N
saml:manage	saml:manage	\N
saml:*	saml:*	\N
securityAudit:generate	securityAudit:generate	\N
securityAudit:*	securityAudit:*	\N
sourceControl:pull	sourceControl:pull	\N
sourceControl:push	sourceControl:push	\N
sourceControl:manage	sourceControl:manage	\N
sourceControl:*	sourceControl:*	\N
tag:create	tag:create	\N
tag:read	tag:read	\N
tag:update	tag:update	\N
tag:delete	tag:delete	\N
tag:list	tag:list	\N
tag:*	tag:*	\N
user:resetPassword	user:resetPassword	\N
user:changeRole	user:changeRole	\N
user:enforceMfa	user:enforceMfa	\N
user:create	user:create	\N
user:read	user:read	\N
user:update	user:update	\N
user:delete	user:delete	\N
user:list	user:list	\N
user:*	user:*	\N
variable:create	variable:create	\N
variable:read	variable:read	\N
variable:update	variable:update	\N
variable:delete	variable:delete	\N
variable:list	variable:list	\N
variable:*	variable:*	\N
workersView:manage	workersView:manage	\N
workersView:*	workersView:*	\N
workflow:share	workflow:share	\N
workflow:execute	workflow:execute	\N
workflow:move	workflow:move	\N
workflow:activate	workflow:activate	\N
workflow:deactivate	workflow:deactivate	\N
workflow:create	workflow:create	\N
workflow:read	workflow:read	\N
workflow:update	workflow:update	\N
workflow:delete	workflow:delete	\N
workflow:list	workflow:list	\N
workflow:*	workflow:*	\N
folder:create	folder:create	\N
folder:read	folder:read	\N
folder:update	folder:update	\N
folder:delete	folder:delete	\N
folder:list	folder:list	\N
folder:move	folder:move	\N
folder:*	folder:*	\N
insights:list	insights:list	\N
insights:*	insights:*	\N
oidc:manage	oidc:manage	\N
oidc:*	oidc:*	\N
dataStore:create	dataStore:create	\N
dataStore:read	dataStore:read	\N
dataStore:update	dataStore:update	\N
dataStore:delete	dataStore:delete	\N
dataStore:list	dataStore:list	\N
dataStore:readRow	dataStore:readRow	\N
dataStore:writeRow	dataStore:writeRow	\N
dataStore:listProject	dataStore:listProject	\N
dataStore:*	dataStore:*	\N
execution:delete	execution:delete	\N
execution:read	execution:read	\N
execution:retry	execution:retry	\N
execution:list	execution:list	\N
execution:get	execution:get	\N
execution:*	execution:*	\N
workflowTags:update	workflowTags:update	\N
workflowTags:list	workflowTags:list	\N
workflowTags:*	workflowTags:*	\N
role:manage	role:manage	\N
role:*	role:*	\N
*	*	\N
\.


--
-- TOC entry 4253 (class 0 OID 19506)
-- Dependencies: 334
-- Data for Name: settings; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.settings (key, value, "loadOnStartup") FROM stdin;
ui.banners.dismissed	["V1"]	t
features.ldap	{"loginEnabled":false,"loginLabel":"","connectionUrl":"","allowUnauthorizedCerts":false,"connectionSecurity":"none","connectionPort":389,"baseDn":"","bindingAdminDn":"","bindingAdminPassword":"","firstNameAttribute":"","lastNameAttribute":"","emailAttribute":"","loginIdAttribute":"","ldapIdAttribute":"","userFilter":"","synchronizationEnabled":false,"synchronizationInterval":60,"searchPageSize":0,"searchTimeout":60}	t
userManagement.authenticationMethod	email	t
features.sourceControl.sshKeys	{"encryptedPrivateKey":"U2FsdGVkX18uK1cYPYc2Qqvf+aKSdY6oHbf5l0BCwR6cf7koIhxfqGl+fjXlNo08E0mNGYTUYMEfXX1oTf0cri5avihshJrZjx4I4bkSM3G7jG38t/k257KVEnBTkzPYkHHgNMS2PuYEirq08jIo83eUjJzec55QRDMAAb0qrQz5qnvBcxAyXRjkWwbQIK6LM8BNBKOLhHNXuiN5fCqHmru+RMY36gzX1B/z3tfvU575nAvKItVy9C5AR9YqeuGuSyFbtvxHVyaOhnM7guVg8nm0pHZoTR548mbIcRX4yYHwAYBpC2RWa6KT0PqdRDufoEGcD6ODbbmJHCcN7673B5XCkoj6XbNLLKBAu1d+0YPAzZWQq7/Z2pk3iHrlNWMpmcYOnxa8IIjeXO2AsdNlhhsrPs8OUTnCVslRGh8Eugee9SQpeCYhkGauFl1Mich0NCWCFc8j6ZTve4RN4rLLVGk9XrKfq5qSC8DfNStQPbM32ZFZXB0MMWWusOtFEkFUjQncmgHQo+kHZTQqtQrS5nI/RzxGMi/t4XGN4WIwP/EwmC4VtxrWTn9E6oH0KKJr","publicKey":"ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPOfUCG5hekveeuBOAeFv0t01F7srLLyVCFZA3gmZ2Gm n8n deploy key"}	t
features.sourceControl	{"branchName":"main","keyGeneratorType":"ed25519"}	t
userManagement.isInstanceOwnerSetUp	true	t
license.cert	eyJsaWNlbnNlS2V5IjoiLS0tLS1CRUdJTiBMSUNFTlNFIEtFWS0tLS0tXG5MVFJaSUUwaHVKUWl0VzNXRElEWUlxSmdCYXZNT0VtRjk2TVY4TFhrYm1zTTB0YWZQS1hNdGE2MEJWTk9VVTNzXG5NWWhSa21oZy9rOWFNYWtseS91aGVmS3hDaC9PSWhNNkYwTG9Ydm12cCtINHZHK0hYNWtnbHFIak1ERm9QUTZwXG5BUVlJajVwSnpGVnVSSTZTK1lUMHltcW5zeTJUaSt3NExpa2hTM2NPUG9DUFNKRnVqc2tBREl4emRrSDgxUWtRXG5ZRUMycHNOSkx5L05uckdpVks2MnRrNWZEdzZlSzhBZHRwU1RYeGoxTHJ2NDNWVGlPUmkxMG14UGkydjFIbUtzXG50RW9SMks0aVUwOGxXRFM4cUJqdUhINEw0UXFvamFaeDl5dW9idUNzTG1QY1FEOEJsck1KcU9MT0RGeXZBaURHXG5oTko4VkZvRmlpTkN5V3JwV2JyU0l3PT18fFUyRnNkR1ZrWDE4dTdDMTYwSkdScG42SHFaaUZyK28rdHFRMHdDXG55TEtTamF6Q251bk1EUWYwdU1SNFRnTTZqSTF2WUlWWUFtRlFyMXA4VGlzdGpqckMrMnBMZTArNG1nZjRxVnlvXG53TGFpbjJXSHB0ckdwdXUrbSszSGUrNE1EQ2NDZzNPa0JwMXlNSTZZR0VtbXhONnNHTEVyM2FNQ2F2NGF5aGRCXG5nRjN4ZlQwWVk4WmQ2Z3cxa3pUaXF3d2J4bWs5VHM5RGlsQy9uczVxd3NlQXYybWZlczhXSHpiUDBoejhTbVVUXG5EaVlVUjJyYkNMQnk0ZGl6RjFtMkgyY1o2SGtZeFpGUlZjU05NekF0aEc5emNOVThWRWZ3RXFSME9XR2w2Y0kwXG5pYWZLM2NrM2YrRXg2VzlCNmJPME9Xbi9scVFPZ3p1YTYxaXFwQVdtVXRWTDBHUWhPa01EMnpOY3VDWFVlSDQ5XG5JbkVMb3k5bDhzM0ZjTExUZW5LUDFXUjFTYTZScjg1UEhHY1BKTk4yT0Z6WTFsV0c2YVF3aEliQVZWRk8zdm5mXG50WHBvTkoyY3FOOW9BNWptRkRtdE1mQzNxSmpST0d2Q0ZnZkZ0STFDYXA4dllFR2JYb0V0T3hhckJ4WGtTeHBpXG5rTFhZQ2IvQW5hckwrN2FqMStvRDVXL0NvMHRKbzg4UHlEUzgrNXJQOWd5TVoyUFMzWkx6VTVFZjBrOTFzdjBuXG5wSG1iS1lTUWx3S0JSZUdONEV1cy81Q1MvVzJ5NE8rMkpETEZZRUtYbSt4bUVzK21xa2tTanNGbmlNZ1V2N2pOXG5mSjFpTy9tL1RDTDh1ODdlRitleExxZjg4a1dVZ3d1dmFHMzlmb215ZU9rUGRyTjArdUJHSHpWWVhwVDF4SzBkXG5sZUJERjJDckhTSmxPU2U5OGU1L3NLWEdQY0tNMGNXeTdGWXJpZjhkSzRqZkNFVG1BUVU5Wk9nRG94dlQ5RzUxXG4vTGxjbGtnQmxudzFKa0l6S1JFcGp4T3MxTVk3K2Z1WXhTV1E3dERFR0xPWUpJWkRlWVpFc2IyTXF3OHNjUHdLXG5TanZJYitPd1R1SmZGN0NZakdvTEJjQmdkaVFzcERmUzZNdUd4a0dsUHo2ZmgxSHFSZHhldkFJbWUwV0VJT0VCXG4reTRZMVg4WFZCb05FN1NmQnFtQnVOZ0dOU3RmOHFOL2VKdGpyOXdyZEVJbjFUcXFSOFhEcnNManFmdlUvZmxuXG5NQ1I0RS9LQXI5YXF1Q21ndDJJWHFlaEZ3ZDlxVlJ4Snh4RjA1eVhsV01wejJTS2hSRTVIZ2QwcjNUS0lHWDNqXG5xYUVhRCs3VGt1WnRuc01DMXFRZEdtYjY3bHNlUnF5RXlBc2lHdmZUY2RxeU1MMklmNGZic2xKS0hRTXlMR3ZxXG4yV0NKQWI3VEIxSnl5aEVxTTRGL01XU1A1NlR4NHRTbmVSZlVscm9tMmdCOGMzR0NCb09CVWgvMm4xTlBydVgzXG5zUS9pZUlqVE1qTEphOU1RZlJic1JiVkJpOUh3M0R3dEVteEVjeUlmelQzUmxvMHBrWjB3S1hhL3p5YjVIa0RvXG4waHBFOEE5NDREQVMvdWxiL3BoVWlrZGg3VHd2U2lFTmhMelhjeVhWY3NqcE13Y0pSY2FxakJCK0pLSGxlTGNoXG5UckdaaSs2Wmc5OEphWjVuTDQ5RERacEgxU3FxdTV3bWgyOEIwc0hJYnZENmJqcVJNdFRsSExPaXFEMkoxWFpLXG5EQmR2S0RPYmhZOG4vWElKTStQbmIzY2lQcUNoZUJNWCtvb1VaZEVNWmRLK3l4blNqT09WWDBFckUyUzdiOWJJXG5ZeUVBeG5qQmVaQjYxdi9oOGpVUmV6Q1huTnd5bjFLSWtrLy9IMWRFbDdqeHpZaXUrbjV0eTI3RTI2T3EzdnpDXG5FcVdRRmlGY0xyWWNLK2kzM2dMR2VwYkJmUStTdmhXZndvRHU0N3R4Y1VOQkprc2pROWlhUHlISSt3TXlXamVkXG5JRm1RdWlLcG1sdG9RZEhNT3NIQnJ1SkpnbVFSN09ZRXErQW1wd3VhRUdRT0JaTUdUcmlBNm9mYkMxR09UVzFNXG42aThWKzB5SmJQUWV3SzdVa2Vsc1R3U2hwZ1RSK01Ba21UaHlaaDBURWR1T1ZrNTI0SHZPR3pTc0ozMU9NeW80XG43WkxkU3JzSFl1UXAwNjEySEFzZTRDUmttUGdkemtSMGc1RVZaRXdBZys1cjNOVC9VenpUY0RteDNUeFRxWXM2XG5OYUxqZU5EZGNqeFlpN3Z6c0x3eHpOUzdNbDhQaEhhdEE0enFyOExIdEtLdkZaYlF6OGhzaytGRHBpUzU5dVNQXG5TNXRvNUdzYUkxdE5uVjZyVjV0aW5ER01LUzd4YTNqSmNOVHFxZG1ITFJpWmRteW92Wkc1ZzRjMzQzSUtVc1N6XG4xQjlSWExObkI4VlFNR1pIVVlVWEJaNTVreG1LeDNWSTRFeVUydys5cEU5TmlreHB1MjU5Wk5uLzFVbEFBbUpVXG56eldwdWN4a2N5Y0NCbWhnTGYzNHdhcm5vUlZRUGh0cmtWbFRkK004ZlhJdUorRjdoSE9YMllJRmZNalFPQ1J2XG5KS1dZOWptR2RINklrbmpTSEhWTkRuUm41WXJtT3gzTzdEN25VRmJleEl1dXpaeFJZazFtQUhxL2Vna3MwWnRQXG5DbkRLVGJxNjVRY1RxTHBCa3VSc1R4Q3YvK3RHRXdWTjQwSWlMOXdyVkM3TUtiSTlSS3h0SjNJZ0QySm5PQTR4XG4rRlJ2RDVMTGFiUVRjUXZoZ2REYkE4WXZ3aVVRRmppeDlFTVZHQ3VUcnkvai9sajVPSWlHc3lheGxZWU0xQlJLXG5SRU5oMGFxZXlFRFVBTFAwcW1QamtZKzRBdmhoOHExREpjWVZodkwyMkIyd0FMODJaZmpyZmxKZFVDQUZ4N3hkXG5aMzI0eG9XK3B2dytjTnpDdVJPdGhWaUZTU1pKQk1PVnBDRms3ZWxwV2dDc1ZMN2psY2kwMHdaQThrTEVhaTg1XG52cnFhdEl6bHo4YkMzQUpScHVtK1hWYnZ6Y2RWbWJTdFVUOFZGc204WmtaVDA0bkE9PXx8T0d3T1J6ZG5IK2xzXG5KUW43UERqZXAxTEt6R0tiQU5lL01lanNUYXZySWRNQzR0eENPYkRMZWJ5OWgvNXc0WTM4NEVOZWhuZW9zdEtwXG5hVW93cFdSSEwrc0R1TUpNN3FMNExoeTVacE10U1AycSt4ZkVSWkdScEhJQU50SmMwcU1wOXhLQW1yOXBlclJRXG55Y2dTenNUMEdqV2YwVDVoQlk0cUVhbitOQWRhaEtVT0t0NTZrYURGRHZ6OEJiTjRHOVlHejgvNmcrVkxjUis1XG5UVWt3alJ0T3BxYStyWFB0anRpaHhESFpVMDNvL3h0eCtsQ3lMMmFlV28veE1mQzBvTXE3MjVnVzJVY0xNM1R3XG4yU0p2akh1Qjl1OTRTTkhiajRORWhDU08yWVZVUjVaemVic254M0JpcHdSVm5ESVNUSU15S1lGU0cwZVlCM29MXG4xTTEyRmI5aE5BPT1cbi0tLS0tRU5EIExJQ0VOU0UgS0VZLS0tLS0iLCJ4NTA5IjoiLS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tXG5NSUlFRERDQ0FmUUNDUUNxZzJvRFQ4MHh3akFOQmdrcWhraUc5dzBCQVFVRkFEQklNUXN3Q1FZRFZRUUdFd0pFXG5SVEVQTUEwR0ExVUVDQXdHUW1WeWJHbHVNUTh3RFFZRFZRUUhEQVpDWlhKc2FXNHhGekFWQmdOVkJBTU1EbXhwXG5ZMlZ1YzJVdWJqaHVMbWx2TUI0WERUSXlNRFl5TkRBME1UQTBNRm9YRFRJek1EWXlOREEwTVRBME1Gb3dTREVMXG5NQWtHQTFVRUJoTUNSRVV4RHpBTkJnTlZCQWdNQmtKbGNteHBiakVQTUEwR0ExVUVCd3dHUW1WeWJHbHVNUmN3XG5GUVlEVlFRRERBNXNhV05sYm5ObExtNDRiaTVwYnpDQ0FTSXdEUVlKS29aSWh2Y05BUUVCQlFBRGdnRVBBRENDXG5BUW9DZ2dFQkFNQk0wNVhCNDRnNXhmbUNMd2RwVVR3QVQ4K0NCa3lMS0ZzZXprRDVLLzZXaGFYL1hyc2QvUWQwXG4yMEo3d2w1V2RIVTRjVkJtRlJqVndWemtsQ0syeVlKaThtang4c1hzR3E5UTFsYlVlTUtmVjlkc2dmdWhubEFTXG50blFaZ2x1Z09uRjJGZ1JoWGIvakswdHhUb2FvK2JORTZyNGdJRXpwa3RITEJUWXZ2aXVKbXJlZjdXYlBSdDRJXG5uZDlEN2xoeWJlYnloVjdrdXpqUUEvcFBLSFRGczhNVEhaOGhZVXhSeXJwbTMrTVl6UUQrYmpBMlUxRkljdGFVXG53UVhZV2FON3QydVR3Q3Q5ekFLc21ZL1dlT2J2bDNUWk41T05MQXp5V0dDdWxtNWN3S1IzeGJsQlp6WG5CNmdzXG5Pbk4yT0FkU3RjelRWQ3ljbThwY0ZVcnl0S1NLa0dFQ0F3RUFBVEFOQmdrcWhraUc5dzBCQVFVRkFBT0NBZ0VBXG5sSjAxd2NuMXZqWFhDSHVvaTdSMERKMWxseDErZGFmcXlFcVBBMjdKdStMWG1WVkdYUW9yUzFiOHhqVXFVa2NaXG5UQndiV0ZPNXo1ZFptTnZuYnlqYXptKzZvT2cwUE1hWXhoNlRGd3NJMlBPYmM3YkZ2MmVheXdQdC8xQ3BuYzQwXG5xVU1oZnZSeC9HQ1pQQ1d6My8yUlBKV1g5alFEU0hYQ1hxOEJXK0kvM2N1TERaeVkzZkVZQkIwcDNEdlZtYWQ2XG42V0hRYVVyaU4wL0xxeVNPcC9MWmdsbC90MDI5Z1dWdDA1WmliR29LK2NWaFpFY3NMY1VJaHJqMnVGR0ZkM0ltXG5KTGcxSktKN2pLU0JVUU9kSU1EdnNGVUY3WWRNdk11ckNZQTJzT05OOENaK0k1eFFWMUtTOWV2R0hNNWZtd2dTXG5PUEZ2UHp0RENpMC8xdVc5dE9nSHBvcnVvZGFjdCtFWk5rQVRYQ3ZaaXUydy9xdEtSSkY0VTRJVEVtNWFXMGt3XG42enVDOHh5SWt0N3ZoZHM0OFV1UlNHSDlqSnJBZW1sRWl6dEdJTGhHRHF6UUdZYmxoVVFGR01iQmI3amhlTHlDXG5MSjFXT0c2MkYxc3B4Q0tCekVXNXg2cFIxelQxbWhFZ2Q0TWtMYTZ6UFRwYWNyZDk1QWd4YUdLRUxhMVJXU0ZwXG5NdmRoR2s0TnY3aG5iOHIrQnVNUkM2aWVkUE1DelhxL001MGNOOEFnOGJ3K0oxYUZvKzBFSzJoV0phN2tpRStzXG45R3ZGalNkekNGbFVQaEtra1Vaa1NvNWFPdGNRcTdKdTZrV0JoTG9GWUtncHJscDFRVkIwc0daQTZvNkR0cWphXG5HNy9SazZ2YmFZOHdzTllLMnpCWFRUOG5laDVab1JaL1BKTFV0RUV0YzdZPVxuLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLSJ9	f
\.


--
-- TOC entry 4266 (class 0 OID 19989)
-- Dependencies: 347
-- Data for Name: shared_credentials; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.shared_credentials ("credentialsId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4267 (class 0 OID 20015)
-- Dependencies: 348
-- Data for Name: shared_workflow; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.shared_workflow ("workflowId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
1LaQnwqSoTxmnw3Z	i9Hx3voRXPvZMWtL	workflow:owner	2025-10-09 23:01:45.917+00	2025-10-09 23:01:45.917+00
9jxl03jCcqg17oOy	i9Hx3voRXPvZMWtL	workflow:owner	2025-10-09 23:01:53.794+00	2025-10-09 23:01:53.794+00
Q08T7oMX2dZslqV4	i9Hx3voRXPvZMWtL	workflow:owner	2025-10-09 23:04:05.011+00	2025-10-09 23:04:05.011+00
\.


--
-- TOC entry 4250 (class 0 OID 19357)
-- Dependencies: 331
-- Data for Name: tag_entity; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.tag_entity (name, "createdAt", "updatedAt", id) FROM stdin;
\.


--
-- TOC entry 4286 (class 0 OID 20369)
-- Dependencies: 367
-- Data for Name: test_case_execution; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.test_case_execution (id, "testRunId", "executionId", status, "runAt", "completedAt", "errorCode", "errorDetails", metrics, "createdAt", "updatedAt", inputs, outputs) FROM stdin;
\.


--
-- TOC entry 4285 (class 0 OID 20354)
-- Dependencies: 366
-- Data for Name: test_run; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.test_run (id, "workflowId", status, "errorCode", "errorDetails", "runAt", "completedAt", metrics, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4252 (class 0 OID 19443)
-- Dependencies: 333
-- Data for Name: user; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n."user" (id, email, "firstName", "lastName", password, "personalizationAnswers", "createdAt", "updatedAt", settings, disabled, "mfaEnabled", "mfaSecret", "mfaRecoveryCodes", "lastActiveAt", "roleSlug") FROM stdin;
9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	golfergeek@orchestratorai.io	Golfer	Geek	$2a$10$5GQh3k/cRVa6iXMmTerh0uPGTsowKkMWHAcU/6QgXoVG3p5bOjx3u	{"version":"v4","personalization_survey_submitted_at":"2025-10-09T20:45:55.451Z","personalization_survey_n8n_version":"1.113.3","companySize":"<20","companyType":"saas","role":"business-owner","reportedSource":"youtube"}	2025-10-09 20:29:48.187+00	2025-10-09 20:45:55.484+00	{"userActivated": false}	f	f	\N	\N	2025-10-09	global:owner
\.


--
-- TOC entry 4275 (class 0 OID 20101)
-- Dependencies: 356
-- Data for Name: user_api_keys; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.user_api_keys (id, "userId", label, "apiKey", "createdAt", "updatedAt", scopes) FROM stdin;
zQTzYfs7ExLSDksn	9f12b0ff-372b-4d46-b8ea-30c14a4a14a2	OrchestratorAI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5ZjEyYjBmZi0zNzJiLTRkNDYtYjhlYS0zMGMxNGE0YTE0YTIiLCJpc3MiOiJuOG4iLCJhdWQiOiJwdWJsaWMtYXBpIiwiaWF0IjoxNzYwMDQyOTA4fQ.kGRjGIPvyOptWjzFAatIt0KZbG7leeRYoNhyifC73BM	2025-10-09 20:48:28.884+00	2025-10-09 20:48:28.884+00	["credential:create","credential:delete","credential:move","project:create","project:delete","project:list","project:update","securityAudit:generate","sourceControl:pull","tag:create","tag:delete","tag:list","tag:read","tag:update","user:changeRole","user:create","user:delete","user:enforceMfa","user:list","user:read","variable:create","variable:delete","variable:list","variable:update","workflow:create","workflow:delete","workflow:list","workflow:move","workflow:read","workflow:update","workflowTags:update","workflowTags:list","workflow:activate","workflow:deactivate","execution:delete","execution:read","execution:retry","execution:list"]
\.


--
-- TOC entry 4261 (class 0 OID 19627)
-- Dependencies: 342
-- Data for Name: variables; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.variables (key, type, value, id) FROM stdin;
\.


--
-- TOC entry 4249 (class 0 OID 19347)
-- Dependencies: 330
-- Data for Name: webhook_entity; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.webhook_entity ("webhookPath", method, node, "webhookId", "pathLength", "workflowId") FROM stdin;
\.


--
-- TOC entry 4248 (class 0 OID 19339)
-- Dependencies: 329
-- Data for Name: workflow_entity; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.workflow_entity (name, active, nodes, connections, "createdAt", "updatedAt", settings, "staticData", "pinData", "versionId", "triggerCount", id, meta, "parentFolderId", "isArchived") FROM stdin;
Marketing Swarm - Flexible LLM	f	[{"parameters":{"httpMethod":"POST","path":"marketing-swarm-flexible","options":{}},"id":"webhook","name":"Webhook","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[240,300],"webhookId":"marketing-swarm-flex"},{"parameters":{"assignments":{"assignments":[{"name":"provider","type":"string","value":"={{ $json.body.provider || 'openai' }}"},{"name":"model","type":"string","value":"={{ $json.body.model || 'gpt-4' }}"},{"name":"announcement","type":"string","value":"={{ $json.body.announcement }}"},{"name":"taskId","type":"string","value":"={{ $json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $json.body.userId }}"},{"name":"statusWebhook","type":"string","value":"={{ $json.body.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}"}]}},"id":"extract-config","name":"Extract Config","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[460,300]},{"parameters":{"method":"POST","url":"={{ $('Extract Config').item.json.statusWebhook }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Extract Config').item.json.taskId,\\\\n  status: 'running',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: 'workflow_started',\\\\n  message: 'Marketing Swarm workflow started',\\\\n  sequence: 0,\\\\n  totalSteps: 4,\\\\n  conversationId: $('Extract Config').item.json.conversationId,\\\\n  userId: $('Extract Config').item.json.userId\\\\n}) }}","options":{"ignoreResponseCode":true}},"id":"send-workflow-start","name":"Send Workflow Start","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[680,300],"continueOnFail":true},{"parameters":{"source":"database","workflowId":"={{ '9jxl03jCcqg17oOy' }}","fieldMapping":{"fields":[{"name":"provider","value":"={{ $('Extract Config').item.json.provider }}"},{"name":"model","value":"={{ $('Extract Config').item.json.model }}"},{"name":"prompt","value":"=Write a compelling web post announcement for: {{ $('Extract Config').item.json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML."},{"name":"sendStartStatus","value":"={{ true }}"},{"name":"sendEndStatus","value":"={{ true }}"},{"name":"statusWebhook","value":"={{ $('Extract Config').item.json.statusWebhook }}"},{"name":"taskId","value":"={{ $('Extract Config').item.json.taskId }}"},{"name":"conversationId","value":"={{ $('Extract Config').item.json.conversationId }}"},{"name":"userId","value":"={{ $('Extract Config').item.json.userId }}"},{"name":"stepName","value":"web_post"},{"name":"sequence","value":"={{ 1 }}"},{"name":"totalSteps","value":"={{ 4 }}"},{"name":"temperature","value":"={{ 0.7 }}"},{"name":"maxTokens","value":"={{ 1000 }}"}]}},"id":"web-post-task","name":"Web Post Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[900,180]},{"parameters":{"source":"database","workflowId":"={{ '9jxl03jCcqg17oOy' }}","fieldMapping":{"fields":[{"name":"provider","value":"={{ $('Extract Config').item.json.provider }}"},{"name":"model","value":"={{ $('Extract Config').item.json.model }}"},{"name":"prompt","value":"=Create SEO-optimized content for: {{ $('Extract Config').item.json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD."},{"name":"sendStartStatus","value":"={{ true }}"},{"name":"sendEndStatus","value":"={{ true }}"},{"name":"statusWebhook","value":"={{ $('Extract Config').item.json.statusWebhook }}"},{"name":"taskId","value":"={{ $('Extract Config').item.json.taskId }}"},{"name":"conversationId","value":"={{ $('Extract Config').item.json.conversationId }}"},{"name":"userId","value":"={{ $('Extract Config').item.json.userId }}"},{"name":"stepName","value":"seo_content"},{"name":"sequence","value":"={{ 2 }}"},{"name":"totalSteps","value":"={{ 4 }}"},{"name":"temperature","value":"={{ 0.5 }}"},{"name":"maxTokens","value":"={{ 800 }}"}]}},"id":"seo-task","name":"SEO Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[900,300]},{"parameters":{"source":"database","workflowId":"={{ '9jxl03jCcqg17oOy' }}","fieldMapping":{"fields":[{"name":"provider","value":"={{ $('Extract Config').item.json.provider }}"},{"name":"model","value":"={{ $('Extract Config').item.json.model }}"},{"name":"prompt","value":"=Create social media posts for: {{ $('Extract Config').item.json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags."},{"name":"sendStartStatus","value":"={{ true }}"},{"name":"sendEndStatus","value":"={{ true }}"},{"name":"statusWebhook","value":"={{ $('Extract Config').item.json.statusWebhook }}"},{"name":"taskId","value":"={{ $('Extract Config').item.json.taskId }}"},{"name":"conversationId","value":"={{ $('Extract Config').item.json.conversationId }}"},{"name":"userId","value":"={{ $('Extract Config').item.json.userId }}"},{"name":"stepName","value":"social_media"},{"name":"sequence","value":"={{ 3 }}"},{"name":"totalSteps","value":"={{ 4 }}"},{"name":"temperature","value":"={{ 0.8 }}"},{"name":"maxTokens","value":"={{ 1200 }}"}]}},"id":"social-task","name":"Social Media Task","type":"n8n-nodes-base.executeWorkflow","typeVersion":1.1,"position":[900,420]},{"parameters":{"assignments":{"assignments":[{"name":"webPost","type":"string","value":"={{ $('Web Post Task').item.json.text }}"},{"name":"seoContent","type":"string","value":"={{ $('SEO Task').item.json.text }}"},{"name":"socialMedia","type":"string","value":"={{ $('Social Media Task').item.json.text }}"}]}},"id":"combine-results","name":"Combine Results","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1120,300]},{"parameters":{"method":"POST","url":"={{ $('Extract Config').item.json.statusWebhook }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Extract Config').item.json.taskId,\\\\n  status: 'completed',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: 'workflow_completed',\\\\n  message: 'Marketing Swarm workflow completed',\\\\n  sequence: 4,\\\\n  totalSteps: 4,\\\\n  conversationId: $('Extract Config').item.json.conversationId,\\\\n  userId: $('Extract Config').item.json.userId,\\\\n  results: {\\\\n    webPost: $json.webPost,\\\\n    seoContent: $json.seoContent,\\\\n    socialMedia: $json.socialMedia\\\\n  }\\\\n}) }}","options":{"ignoreResponseCode":true}},"id":"send-final-status","name":"Send Final Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1340,300],"continueOnFail":true},{"parameters":{"respondWith":"json","responseBody":"={{ $json }}"},"id":"respond","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[1560,300]}]	{"Webhook":{"main":[[{"node":"Extract Config","type":"main","index":0}]]},"Extract Config":{"main":[[{"node":"Send Workflow Start","type":"main","index":0}]]},"Send Workflow Start":{"main":[[{"node":"Web Post Task","type":"main","index":0},{"node":"SEO Task","type":"main","index":0},{"node":"Social Media Task","type":"main","index":0}]]},"Web Post Task":{"main":[[{"node":"Combine Results","type":"main","index":0}]]},"SEO Task":{"main":[[{"node":"Combine Results","type":"main","index":0}]]},"Social Media Task":{"main":[[{"node":"Combine Results","type":"main","index":0}]]},"Combine Results":{"main":[[{"node":"Send Final Status","type":"main","index":0}]]},"Send Final Status":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}}	2025-10-08 18:41:15.406+00	2025-10-08 18:41:15.406+00	{}	\N	\N	2685c6ed-6ea7-4323-aba5-aace4131d87a	0	1LaQnwqSoTxmnw3Z	\N	\N	f
Helper: LLM Task	f	[{"parameters":{},"id":"execute-workflow-trigger","name":"Execute Workflow Trigger","type":"n8n-nodes-base.executeWorkflowTrigger","typeVersion":1,"position":[240,304]},{"parameters":{"conditions":{"boolean":[{"value1":"={{ $('Execute Workflow Trigger').item.json.sendStartStatus }}","value2":true}]},"options":{}},"id":"check-send-start","name":"Check Send Start Status","type":"n8n-nodes-base.if","typeVersion":2,"position":[464,304]},{"parameters":{"method":"POST","url":"={{ $('Execute Workflow Trigger').item.json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Execute Workflow Trigger').item.json.taskId,\\\\n  status: 'running',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: $('Execute Workflow Trigger').item.json.stepName,\\\\n  message: 'Starting ' + ($('Execute Workflow Trigger').item.json.stepName || 'task'),\\\\n  sequence: $('Execute Workflow Trigger').item.json.sequence,\\\\n  totalSteps: $('Execute Workflow Trigger').item.json.totalSteps,\\\\n  conversationId: $('Execute Workflow Trigger').item.json.conversationId,\\\\n  userId: $('Execute Workflow Trigger').item.json.userId\\\\n}) }}","options":{}},"id":"send-start-status","name":"Send Start Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[688,192],"continueOnFail":true},{"parameters":{"mode":"expression","output":null},"id":"select-provider","name":"Select Provider","type":"n8n-nodes-base.switch","typeVersion":3,"position":[688,432]},{"parameters":{"method":"POST","url":"https://api.openai.com/v1/chat/completions","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Execute Workflow Trigger').item.json.model || 'gpt-4',\\\\n  messages: [{ role: 'user', content: $('Execute Workflow Trigger').item.json.prompt }],\\\\n  temperature: $('Execute Workflow Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Execute Workflow Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{}},"id":"openai-request","name":"OpenAI Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[912,304]},{"parameters":{"method":"POST","url":"={{ $('Execute Workflow Trigger').item.json.baseUrl || 'http://host.docker.internal:11434/api/generate' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Execute Workflow Trigger').item.json.model || 'llama2',\\\\n  prompt: $('Execute Workflow Trigger').item.json.prompt,\\\\n  stream: false,\\\\n  options: {\\\\n    temperature: $('Execute Workflow Trigger').item.json.temperature || 0.7,\\\\n    num_predict: $('Execute Workflow Trigger').item.json.maxTokens || 1000\\\\n  }\\\\n}) }}","options":{}},"id":"ollama-request","name":"Ollama Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[912,432]},{"parameters":{"method":"POST","url":"https://api.anthropic.com/v1/messages","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  model: $('Execute Workflow Trigger').item.json.model || 'claude-3-sonnet-20240229',\\\\n  messages: [{ role: 'user', content: $('Execute Workflow Trigger').item.json.prompt }],\\\\n  temperature: $('Execute Workflow Trigger').item.json.temperature || 0.7,\\\\n  max_tokens: $('Execute Workflow Trigger').item.json.maxTokens || 1000\\\\n}) }}","options":{}},"id":"anthropic-request","name":"Anthropic Request","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[912,544]},{"parameters":{"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.choices[0].message.content }}"},{"name":"provider","type":"string","value":"openai"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"options":{}},"id":"normalize-openai","name":"Normalize OpenAI","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1120,304]},{"parameters":{"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.response }}"},{"name":"provider","type":"string","value":"ollama"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ { prompt_tokens: $json.prompt_eval_count, completion_tokens: $json.eval_count } }}"}]},"options":{}},"id":"normalize-ollama","name":"Normalize Ollama","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1120,432]},{"parameters":{"assignments":{"assignments":[{"name":"text","type":"string","value":"={{ $json.content[0].text }}"},{"name":"provider","type":"string","value":"anthropic"},{"name":"model","type":"string","value":"={{ $json.model }}"},{"name":"usage","type":"object","value":"={{ $json.usage }}"}]},"options":{}},"id":"normalize-anthropic","name":"Normalize Anthropic","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1120,544]},{"parameters":{"conditions":{"boolean":[{"value1":"={{ $('Execute Workflow Trigger').item.json.sendEndStatus }}","value2":true}]},"options":{}},"id":"check-send-end","name":"Check Send End Status","type":"n8n-nodes-base.if","typeVersion":2,"position":[1344,432]},{"parameters":{"method":"POST","url":"={{ $('Execute Workflow Trigger').item.json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify({\\\\n  taskId: $('Execute Workflow Trigger').item.json.taskId,\\\\n  status: 'completed',\\\\n  timestamp: new Date().toISOString(),\\\\n  step: $('Execute Workflow Trigger').item.json.stepName,\\\\n  message: 'Completed ' + ($('Execute Workflow Trigger').item.json.stepName || 'task'),\\\\n  sequence: $('Execute Workflow Trigger').item.json.sequence,\\\\n  totalSteps: $('Execute Workflow Trigger').item.json.totalSteps,\\\\n  conversationId: $('Execute Workflow Trigger').item.json.conversationId,\\\\n  userId: $('Execute Workflow Trigger').item.json.userId\\\\n}) }}","options":{}},"id":"send-end-status","name":"Send End Status","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1568,304],"continueOnFail":true}]	{"Execute Workflow Trigger":{"main":[[{"node":"Check Send Start Status","type":"main","index":0}]]},"Check Send Start Status":{"main":[[{"node":"Send Start Status","type":"main","index":0}],[{"node":"Select Provider","type":"main","index":0}]]},"Send Start Status":{"main":[[{"node":"Select Provider","type":"main","index":0}]]},"Select Provider":{"main":[[{"node":"OpenAI Request","type":"main","index":0}],[{"node":"Ollama Request","type":"main","index":0}],[{"node":"Anthropic Request","type":"main","index":0}]]},"OpenAI Request":{"main":[[{"node":"Normalize OpenAI","type":"main","index":0}]]},"Ollama Request":{"main":[[{"node":"Normalize Ollama","type":"main","index":0}]]},"Anthropic Request":{"main":[[{"node":"Normalize Anthropic","type":"main","index":0}]]},"Normalize OpenAI":{"main":[[{"node":"Check Send End Status","type":"main","index":0}]]},"Normalize Ollama":{"main":[[{"node":"Check Send End Status","type":"main","index":0}]]},"Normalize Anthropic":{"main":[[{"node":"Check Send End Status","type":"main","index":0}]]},"Check Send End Status":{"main":[[{"node":"Send End Status","type":"main","index":0}],[]]}}	2025-10-08 18:29:22.544+00	2025-10-08 18:44:54.356+00	{}	\N	{}	2892ac76-9646-46f4-9e0d-5b65555d6ff8	0	9jxl03jCcqg17oOy	\N	\N	f
Marketing Swarm - Major Announcement	f	[{"parameters":{"httpMethod":"POST","path":"marketing-swarm","options":{},"responseMode":"responseNode"},"id":"webhook","name":"Webhook Trigger","type":"n8n-nodes-base.webhook","typeVersion":2,"position":[112,112],"webhookId":"7f338c6b-a9bb-446b-9a1d-702739d89a51"},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"started"},{"name":"taskId","type":"string","value":"={{ $json.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"initialization"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":1},{"name":"totalSteps","type":"number","value":5}]}},"id":"statusStart","name":"Status: Started","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[304,0]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusStart","name":"Send Status: Started","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[512,0]},{"parameters":{"prompt":"=Write a compelling web post announcement for: {{ $json.announcement }}. Include headline, introduction, key features, and call-to-action. Format as HTML.","options":{"maxTokens":1000,"temperature":0.7},"requestOptions":{}},"id":"webPost","name":"Generate Web Post","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[304,208],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"web_post_complete"},{"name":"webPost","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":2},{"name":"totalSteps","type":"number","value":5}]}},"id":"statusWebPost","name":"Status: Web Post Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[512,208]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusWebPost","name":"Send Status: Web Post","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[704,100]},{"parameters":{"prompt":"=Create SEO-optimized content for: {{ $json.announcement }}. Include meta title, meta description, keywords, and structured data JSON-LD.","options":{"maxTokens":800,"temperature":0.5},"requestOptions":{}},"id":"seoContent","name":"Generate SEO Content","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[704,300],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"seo_complete"},{"name":"seoContent","type":"string","value":"={{ $json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":3},{"name":"totalSteps","type":"number","value":5}]}},"id":"statusSEO","name":"Status: SEO Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[912,300]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusSEO","name":"Send Status: SEO","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1104,200]},{"parameters":{"prompt":"=Create social media posts for: {{ $json.announcement }}. Generate posts for Twitter/X (280 chars), LinkedIn (professional, 1300 chars), and Facebook (engaging, 500 chars). Include relevant hashtags.","options":{"maxTokens":1200,"temperature":0.8},"requestOptions":{}},"id":"socialMedia","name":"Generate Social Media","type":"n8n-nodes-base.openAi","typeVersion":1.1,"position":[1104,400],"credentials":{"openAiApi":{"id":"B2oF5F10osX9S0yy","name":"OpenAi account"}}},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"in_progress"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"step","type":"string","value":"social_media_complete"},{"name":"socialMedia","type":"string","value":"={{ $('Generate Social Media').item.json.text }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"sequence","type":"number","value":4},{"name":"totalSteps","type":"number","value":5}]}},"id":"statusSocial","name":"Status: Social Done","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1312,400]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusSocial","name":"Send Status: Social","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1504,300]},{"parameters":{"assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Webhook Trigger').item.json.body.userId }}"},{"name":"executionId","type":"string","value":"={{ $execution.id }}"},{"name":"timestamp","type":"string","value":"={{ $now.toISO() }}"},{"name":"webPost","type":"string","value":"={{ $('Status: Web Post Done').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Status: SEO Done').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Status: Social Done').item.json.socialMedia }}"},{"name":"sequence","type":"number","value":5},{"name":"totalSteps","type":"number","value":5}]}},"id":"finalOutput","name":"Final Output","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1504,500]},{"parameters":{"method":"POST","url":"={{ $json.statusWebhook || 'http://host.docker.internal:7100/webhooks/status' }}","sendBody":true,"specifyBody":"json","jsonBody":"={{ JSON.stringify($json) }}","options":{}},"id":"webhookStatusComplete","name":"Send Status: Complete","type":"n8n-nodes-base.httpRequest","typeVersion":4.2,"position":[1712,500]},{"parameters":{"mode":"manual","assignments":{"assignments":[{"name":"status","type":"string","value":"completed"},{"name":"taskId","type":"string","value":"={{ $('Final Output').item.json.taskId }}"},{"name":"conversationId","type":"string","value":"={{ $('Final Output').item.json.conversationId }}"},{"name":"userId","type":"string","value":"={{ $('Final Output').item.json.userId }}"},{"name":"executionId","type":"string","value":"={{ $('Final Output').item.json.executionId }}"},{"name":"timestamp","type":"string","value":"={{ $('Final Output').item.json.timestamp }}"},{"name":"webPost","type":"string","value":"={{ $('Final Output').item.json.webPost }}"},{"name":"seoContent","type":"string","value":"={{ $('Final Output').item.json.seoContent }}"},{"name":"socialMedia","type":"string","value":"={{ $('Final Output').item.json.socialMedia }}"}]}},"id":"finalResponse","name":"Final Response","type":"n8n-nodes-base.set","typeVersion":3.4,"position":[1912,500]},{"parameters":{"respondWith":"json","responseBody":"={{ $json }}"},"id":"respondWebhook","name":"Respond to Webhook","type":"n8n-nodes-base.respondToWebhook","typeVersion":1.1,"position":[2112,500]}]	{"Webhook Trigger":{"main":[[{"node":"Status: Started","type":"main","index":0},{"node":"Generate Web Post","type":"main","index":0}]]},"Status: Started":{"main":[[{"node":"Send Status: Started","type":"main","index":0}]]},"Generate Web Post":{"main":[[{"node":"Status: Web Post Done","type":"main","index":0}]]},"Status: Web Post Done":{"main":[[{"node":"Send Status: Web Post","type":"main","index":0},{"node":"Generate SEO Content","type":"main","index":0}]]},"Generate SEO Content":{"main":[[{"node":"Status: SEO Done","type":"main","index":0}]]},"Status: SEO Done":{"main":[[{"node":"Send Status: SEO","type":"main","index":0},{"node":"Generate Social Media","type":"main","index":0}]]},"Generate Social Media":{"main":[[{"node":"Status: Social Done","type":"main","index":0}]]},"Status: Social Done":{"main":[[{"node":"Send Status: Social","type":"main","index":0},{"node":"Final Output","type":"main","index":0}]]},"Final Output":{"main":[[{"node":"Send Status: Complete","type":"main","index":0}]]},"Send Status: Complete":{"main":[[{"node":"Final Response","type":"main","index":0}]]},"Final Response":{"main":[[{"node":"Respond to Webhook","type":"main","index":0}]]}}	2025-10-09 23:04:05.011+00	2025-10-09 23:04:05.011+00	{}	\N	\N	2685c6ed-6ea7-4323-aba5-aace4131d87a	0	Q08T7oMX2dZslqV4	\N	\N	f
\.


--
-- TOC entry 4263 (class 0 OID 19725)
-- Dependencies: 344
-- Data for Name: workflow_history; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.workflow_history ("versionId", "workflowId", authors, "createdAt", "updatedAt", nodes, connections) FROM stdin;
\.


--
-- TOC entry 4256 (class 0 OID 19542)
-- Dependencies: 337
-- Data for Name: workflow_statistics; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.workflow_statistics (count, "latestEvent", name, "workflowId", "rootCount") FROM stdin;
\.


--
-- TOC entry 4251 (class 0 OID 19364)
-- Dependencies: 332
-- Data for Name: workflows_tags; Type: TABLE DATA; Schema: n8n; Owner: -
--

COPY n8n.workflows_tags ("workflowId", "tagId") FROM stdin;
\.


--
-- TOC entry 4320 (class 0 OID 0)
-- Dependencies: 340
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: -
--

SELECT pg_catalog.setval('n8n.auth_provider_sync_history_id_seq', 1, false);


--
-- TOC entry 4321 (class 0 OID 0)
-- Dependencies: 352
-- Name: execution_annotations_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: -
--

SELECT pg_catalog.setval('n8n.execution_annotations_id_seq', 1, false);


--
-- TOC entry 4322 (class 0 OID 0)
-- Dependencies: 327
-- Name: execution_entity_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: -
--

SELECT pg_catalog.setval('n8n.execution_entity_id_seq', 1, false);


--
-- TOC entry 4323 (class 0 OID 0)
-- Dependencies: 349
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: -
--

SELECT pg_catalog.setval('n8n.execution_metadata_temp_id_seq', 1, false);


--
-- TOC entry 4324 (class 0 OID 0)
-- Dependencies: 364
-- Name: insights_by_period_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: -
--

SELECT pg_catalog.setval('n8n.insights_by_period_id_seq', 1, false);


--
-- TOC entry 4325 (class 0 OID 0)
-- Dependencies: 360
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE SET; Schema: n8n; Owner: -
--

SELECT pg_catalog.setval('n8n."insights_metadata_metaId_seq"', 1, false);


--
-- TOC entry 4326 (class 0 OID 0)
-- Dependencies: 362
-- Name: insights_raw_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: -
--

SELECT pg_catalog.setval('n8n.insights_raw_id_seq', 1, false);


--
-- TOC entry 4327 (class 0 OID 0)
-- Dependencies: 324
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: n8n; Owner: -
--

SELECT pg_catalog.setval('n8n.migrations_id_seq', 99, true);


--
-- TOC entry 4034 (class 2606 OID 20362)
-- Name: test_run PK_011c050f566e9db509a0fadb9b9; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.test_run
    ADD CONSTRAINT "PK_011c050f566e9db509a0fadb9b9" PRIMARY KEY (id);


--
-- TOC entry 3965 (class 2606 OID 19520)
-- Name: installed_packages PK_08cc9197c39b028c1e9beca225940576fd1a5804; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.installed_packages
    ADD CONSTRAINT "PK_08cc9197c39b028c1e9beca225940576fd1a5804" PRIMARY KEY ("packageName");


--
-- TOC entry 4000 (class 2606 OID 20042)
-- Name: execution_metadata PK_17a0b6284f8d626aae88e1c16e4; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_metadata
    ADD CONSTRAINT "PK_17a0b6284f8d626aae88e1c16e4" PRIMARY KEY (id);


--
-- TOC entry 3991 (class 2606 OID 19969)
-- Name: project_relation PK_1caaa312a5d7184a003be0f0cb6; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "PK_1caaa312a5d7184a003be0f0cb6" PRIMARY KEY ("projectId", "userId");


--
-- TOC entry 4023 (class 2606 OID 20250)
-- Name: folder_tag PK_27e4e00852f6b06a925a4d83a3e; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "PK_27e4e00852f6b06a925a4d83a3e" PRIMARY KEY ("folderId", "tagId");


--
-- TOC entry 4041 (class 2606 OID 20405)
-- Name: role PK_35c9b140caaf6da09cfabb0d675; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.role
    ADD CONSTRAINT "PK_35c9b140caaf6da09cfabb0d675" PRIMARY KEY (slug);


--
-- TOC entry 3987 (class 2606 OID 19960)
-- Name: project PK_4d68b1358bb5b766d3e78f32f57; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.project
    ADD CONSTRAINT "PK_4d68b1358bb5b766d3e78f32f57" PRIMARY KEY (id);


--
-- TOC entry 4002 (class 2606 OID 20055)
-- Name: invalid_auth_token PK_5779069b7235b256d91f7af1a15; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.invalid_auth_token
    ADD CONSTRAINT "PK_5779069b7235b256d91f7af1a15" PRIMARY KEY (token);


--
-- TOC entry 3997 (class 2606 OID 20023)
-- Name: shared_workflow PK_5ba87620386b847201c9531c58f; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "PK_5ba87620386b847201c9531c58f" PRIMARY KEY ("workflowId", "projectId");


--
-- TOC entry 4021 (class 2606 OID 20234)
-- Name: folder PK_6278a41a706740c94c02e288df8; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "PK_6278a41a706740c94c02e288df8" PRIMARY KEY (id);


--
-- TOC entry 4050 (class 2606 OID 20482)
-- Name: data_table_column PK_673cb121ee4a8a5e27850c72c51; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "PK_673cb121ee4a8a5e27850c72c51" PRIMARY KEY (id);


--
-- TOC entry 4008 (class 2606 OID 20082)
-- Name: annotation_tag_entity PK_69dfa041592c30bbc0d4b84aa00; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.annotation_tag_entity
    ADD CONSTRAINT "PK_69dfa041592c30bbc0d4b84aa00" PRIMARY KEY (id);


--
-- TOC entry 4005 (class 2606 OID 20069)
-- Name: execution_annotations PK_7afcf93ffa20c4252869a7c6a23; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_annotations
    ADD CONSTRAINT "PK_7afcf93ffa20c4252869a7c6a23" PRIMARY KEY (id);


--
-- TOC entry 3932 (class 2606 OID 19317)
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- TOC entry 3967 (class 2606 OID 19528)
-- Name: installed_nodes PK_8ebd28194e4f792f96b5933423fc439df97d9689; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.installed_nodes
    ADD CONSTRAINT "PK_8ebd28194e4f792f96b5933423fc439df97d9689" PRIMARY KEY (name);


--
-- TOC entry 3995 (class 2606 OID 19997)
-- Name: shared_credentials PK_8ef3a59796a228913f251779cff; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "PK_8ef3a59796a228913f251779cff" PRIMARY KEY ("credentialsId", "projectId");


--
-- TOC entry 4037 (class 2606 OID 20377)
-- Name: test_case_execution PK_90c121f77a78a6580e94b794bce; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "PK_90c121f77a78a6580e94b794bce" PRIMARY KEY (id);


--
-- TOC entry 4016 (class 2606 OID 20109)
-- Name: user_api_keys PK_978fa5caa3468f463dac9d92e69; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.user_api_keys
    ADD CONSTRAINT "PK_978fa5caa3468f463dac9d92e69" PRIMARY KEY (id);


--
-- TOC entry 4012 (class 2606 OID 20088)
-- Name: execution_annotation_tags PK_979ec03d31294cca484be65d11f; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "PK_979ec03d31294cca484be65d11f" PRIMARY KEY ("annotationId", "tagId");


--
-- TOC entry 3948 (class 2606 OID 19353)
-- Name: webhook_entity PK_b21ace2e13596ccd87dc9bf4ea6; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.webhook_entity
    ADD CONSTRAINT "PK_b21ace2e13596ccd87dc9bf4ea6" PRIMARY KEY ("webhookPath", method);


--
-- TOC entry 4031 (class 2606 OID 20347)
-- Name: insights_by_period PK_b606942249b90cc39b0265f0575; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.insights_by_period
    ADD CONSTRAINT "PK_b606942249b90cc39b0265f0575" PRIMARY KEY (id);


--
-- TOC entry 3985 (class 2606 OID 19733)
-- Name: workflow_history PK_b6572dd6173e4cd06fe79937b58; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.workflow_history
    ADD CONSTRAINT "PK_b6572dd6173e4cd06fe79937b58" PRIMARY KEY ("versionId");


--
-- TOC entry 4039 (class 2606 OID 20397)
-- Name: scope PK_bfc45df0481abd7f355d6187da1; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.scope
    ADD CONSTRAINT "PK_bfc45df0481abd7f355d6187da1" PRIMARY KEY (slug);


--
-- TOC entry 4018 (class 2606 OID 20125)
-- Name: processed_data PK_ca04b9d8dc72de268fe07a65773; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.processed_data
    ADD CONSTRAINT "PK_ca04b9d8dc72de268fe07a65773" PRIMARY KEY ("workflowId", context);


--
-- TOC entry 3963 (class 2606 OID 19513)
-- Name: settings PK_dc0fe14e6d9943f268e7b119f69ab8bd; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.settings
    ADD CONSTRAINT "PK_dc0fe14e6d9943f268e7b119f69ab8bd" PRIMARY KEY (key);


--
-- TOC entry 4046 (class 2606 OID 20468)
-- Name: data_table PK_e226d0001b9e6097cbfe70617cb; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "PK_e226d0001b9e6097cbfe70617cb" PRIMARY KEY (id);


--
-- TOC entry 3958 (class 2606 OID 19452)
-- Name: user PK_ea8f538c94b6e352418254ed6474a81f; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "PK_ea8f538c94b6e352418254ed6474a81f" PRIMARY KEY (id);


--
-- TOC entry 4028 (class 2606 OID 20335)
-- Name: insights_raw PK_ec15125755151e3a7e00e00014f; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.insights_raw
    ADD CONSTRAINT "PK_ec15125755151e3a7e00e00014f" PRIMARY KEY (id);


--
-- TOC entry 4026 (class 2606 OID 20317)
-- Name: insights_metadata PK_f448a94c35218b6208ce20cf5a1; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "PK_f448a94c35218b6208ce20cf5a1" PRIMARY KEY ("metaId");


--
-- TOC entry 4044 (class 2606 OID 20410)
-- Name: role_scope PK_role_scope; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "PK_role_scope" PRIMARY KEY ("roleSlug", "scopeSlug");


--
-- TOC entry 4052 (class 2606 OID 20484)
-- Name: data_table_column UQ_8082ec4890f892f0bc77473a123; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "UQ_8082ec4890f892f0bc77473a123" UNIQUE ("dataTableId", name);


--
-- TOC entry 4048 (class 2606 OID 20470)
-- Name: data_table UQ_b23096ef747281ac944d28e8b0d; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "UQ_b23096ef747281ac944d28e8b0d" UNIQUE ("projectId", name);


--
-- TOC entry 3960 (class 2606 OID 19454)
-- Name: user UQ_e12875dfb3b1d92d7d7c5377e2; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e2" UNIQUE (email);


--
-- TOC entry 3973 (class 2606 OID 19609)
-- Name: auth_identity auth_identity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.auth_identity
    ADD CONSTRAINT auth_identity_pkey PRIMARY KEY ("providerId", "providerType");


--
-- TOC entry 3975 (class 2606 OID 19625)
-- Name: auth_provider_sync_history auth_provider_sync_history_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.auth_provider_sync_history
    ADD CONSTRAINT auth_provider_sync_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3934 (class 2606 OID 19707)
-- Name: credentials_entity credentials_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.credentials_entity
    ADD CONSTRAINT credentials_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 3971 (class 2606 OID 19580)
-- Name: event_destinations event_destinations_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.event_destinations
    ADD CONSTRAINT event_destinations_pkey PRIMARY KEY (id);


--
-- TOC entry 3982 (class 2606 OID 19723)
-- Name: execution_data execution_data_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_data
    ADD CONSTRAINT execution_data_pkey PRIMARY KEY ("executionId");


--
-- TOC entry 3930 (class 2606 OID 19018)
-- Name: migration_metadata migration_metadata_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.migration_metadata
    ADD CONSTRAINT migration_metadata_pkey PRIMARY KEY (migration_file);


--
-- TOC entry 3923 (class 2606 OID 19008)
-- Name: n8n_workflows n8n_workflows_name_key; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.n8n_workflows
    ADD CONSTRAINT n8n_workflows_name_key UNIQUE (name);


--
-- TOC entry 3925 (class 2606 OID 19006)
-- Name: n8n_workflows n8n_workflows_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.n8n_workflows
    ADD CONSTRAINT n8n_workflows_pkey PRIMARY KEY (id);


--
-- TOC entry 3942 (class 2606 OID 19336)
-- Name: execution_entity pk_e3e63bbf986767844bbe1166d4e; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_entity
    ADD CONSTRAINT pk_e3e63bbf986767844bbe1166d4e PRIMARY KEY (id);


--
-- TOC entry 3969 (class 2606 OID 19676)
-- Name: workflow_statistics pk_workflow_statistics; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.workflow_statistics
    ADD CONSTRAINT pk_workflow_statistics PRIMARY KEY ("workflowId", name);


--
-- TOC entry 3956 (class 2606 OID 19655)
-- Name: workflows_tags pk_workflows_tags; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT pk_workflows_tags PRIMARY KEY ("workflowId", "tagId");


--
-- TOC entry 3953 (class 2606 OID 19696)
-- Name: tag_entity tag_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.tag_entity
    ADD CONSTRAINT tag_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 3978 (class 2606 OID 19635)
-- Name: variables variables_key_key; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.variables
    ADD CONSTRAINT variables_key_key UNIQUE (key);


--
-- TOC entry 3980 (class 2606 OID 19710)
-- Name: variables variables_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.variables
    ADD CONSTRAINT variables_pkey PRIMARY KEY (id);


--
-- TOC entry 3946 (class 2606 OID 19694)
-- Name: workflow_entity workflow_entity_pkey; Type: CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.workflow_entity
    ADD CONSTRAINT workflow_entity_pkey PRIMARY KEY (id);


--
-- TOC entry 4019 (class 1259 OID 20245)
-- Name: IDX_14f68deffaf858465715995508; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX "IDX_14f68deffaf858465715995508" ON n8n.folder USING btree ("projectId", id);


--
-- TOC entry 4024 (class 1259 OID 20328)
-- Name: IDX_1d8ab99d5861c9388d2dc1cf73; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX "IDX_1d8ab99d5861c9388d2dc1cf73" ON n8n.insights_metadata USING btree ("workflowId");


--
-- TOC entry 3983 (class 1259 OID 19739)
-- Name: IDX_1e31657f5fe46816c34be7c1b4; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_1e31657f5fe46816c34be7c1b4" ON n8n.workflow_history USING btree ("workflowId");


--
-- TOC entry 4013 (class 1259 OID 20116)
-- Name: IDX_1ef35bac35d20bdae979d917a3; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX "IDX_1ef35bac35d20bdae979d917a3" ON n8n.user_api_keys USING btree ("apiKey");


--
-- TOC entry 3988 (class 1259 OID 19981)
-- Name: IDX_5f0643f6717905a05164090dde; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_5f0643f6717905a05164090dde" ON n8n.project_relation USING btree ("userId");


--
-- TOC entry 4029 (class 1259 OID 20353)
-- Name: IDX_60b6a84299eeb3f671dfec7693; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX "IDX_60b6a84299eeb3f671dfec7693" ON n8n.insights_by_period USING btree ("periodStart", type, "periodUnit", "metaId");


--
-- TOC entry 3989 (class 1259 OID 19980)
-- Name: IDX_61448d56d61802b5dfde5cdb00; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_61448d56d61802b5dfde5cdb00" ON n8n.project_relation USING btree ("projectId");


--
-- TOC entry 4014 (class 1259 OID 20115)
-- Name: IDX_63d7bbae72c767cf162d459fcc; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX "IDX_63d7bbae72c767cf162d459fcc" ON n8n.user_api_keys USING btree ("userId", label);


--
-- TOC entry 4035 (class 1259 OID 20388)
-- Name: IDX_8e4b4774db42f1e6dda3452b2a; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_8e4b4774db42f1e6dda3452b2a" ON n8n.test_case_execution USING btree ("testRunId");


--
-- TOC entry 4003 (class 1259 OID 20075)
-- Name: IDX_97f863fa83c4786f1956508496; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX "IDX_97f863fa83c4786f1956508496" ON n8n.execution_annotations USING btree ("executionId");


--
-- TOC entry 4009 (class 1259 OID 20099)
-- Name: IDX_a3697779b366e131b2bbdae297; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_a3697779b366e131b2bbdae297" ON n8n.execution_annotation_tags USING btree ("tagId");


--
-- TOC entry 4006 (class 1259 OID 20083)
-- Name: IDX_ae51b54c4bb430cf92f48b623f; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX "IDX_ae51b54c4bb430cf92f48b623f" ON n8n.annotation_tag_entity USING btree (name);


--
-- TOC entry 4010 (class 1259 OID 20100)
-- Name: IDX_c1519757391996eb06064f0e7c; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_c1519757391996eb06064f0e7c" ON n8n.execution_annotation_tags USING btree ("annotationId");


--
-- TOC entry 3998 (class 1259 OID 20048)
-- Name: IDX_cec8eea3bf49551482ccb4933e; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX "IDX_cec8eea3bf49551482ccb4933e" ON n8n.execution_metadata USING btree ("executionId", key);


--
-- TOC entry 4032 (class 1259 OID 20368)
-- Name: IDX_d6870d3b6e4c185d33926f423c; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_d6870d3b6e4c185d33926f423c" ON n8n.test_run USING btree ("workflowId");


--
-- TOC entry 3937 (class 1259 OID 19740)
-- Name: IDX_execution_entity_deletedAt; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_execution_entity_deletedAt" ON n8n.execution_entity USING btree ("deletedAt");


--
-- TOC entry 4042 (class 1259 OID 20421)
-- Name: IDX_role_scope_scopeSlug; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_role_scope_scopeSlug" ON n8n.role_scope USING btree ("scopeSlug");


--
-- TOC entry 3943 (class 1259 OID 19724)
-- Name: IDX_workflow_entity_name; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX "IDX_workflow_entity_name" ON n8n.workflow_entity USING btree (name);


--
-- TOC entry 3935 (class 1259 OID 19431)
-- Name: idx_07fde106c0b471d8cc80a64fc8; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_07fde106c0b471d8cc80a64fc8 ON n8n.credentials_entity USING btree (type);


--
-- TOC entry 3949 (class 1259 OID 19355)
-- Name: idx_16f4436789e804e3e1c9eeb240; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_16f4436789e804e3e1c9eeb240 ON n8n.webhook_entity USING btree ("webhookId", method, "pathLength");


--
-- TOC entry 3950 (class 1259 OID 19363)
-- Name: idx_812eb05f7451ca757fb98444ce; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX idx_812eb05f7451ca757fb98444ce ON n8n.tag_entity USING btree (name);


--
-- TOC entry 3938 (class 1259 OID 20058)
-- Name: idx_execution_entity_stopped_at_status_deleted_at; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_execution_entity_stopped_at_status_deleted_at ON n8n.execution_entity USING btree ("stoppedAt", status, "deletedAt") WHERE (("stoppedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 3939 (class 1259 OID 20057)
-- Name: idx_execution_entity_wait_till_status_deleted_at; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_execution_entity_wait_till_status_deleted_at ON n8n.execution_entity USING btree ("waitTill", status, "deletedAt") WHERE (("waitTill" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 3940 (class 1259 OID 20056)
-- Name: idx_execution_entity_workflow_id_started_at; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_execution_entity_workflow_id_started_at ON n8n.execution_entity USING btree ("workflowId", "startedAt") WHERE (("startedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- TOC entry 3926 (class 1259 OID 19027)
-- Name: idx_migration_metadata_source; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_migration_metadata_source ON n8n.migration_metadata USING btree (source);


--
-- TOC entry 3927 (class 1259 OID 19029)
-- Name: idx_migration_metadata_synced; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_migration_metadata_synced ON n8n.migration_metadata USING btree (synced_at);


--
-- TOC entry 3928 (class 1259 OID 19028)
-- Name: idx_migration_metadata_workflow; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_migration_metadata_workflow ON n8n.migration_metadata USING btree (workflow_id);


--
-- TOC entry 3919 (class 1259 OID 19025)
-- Name: idx_n8n_workflows_active; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_n8n_workflows_active ON n8n.n8n_workflows USING btree (active);


--
-- TOC entry 3920 (class 1259 OID 19024)
-- Name: idx_n8n_workflows_name; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_n8n_workflows_name ON n8n.n8n_workflows USING btree (name);


--
-- TOC entry 3921 (class 1259 OID 19026)
-- Name: idx_n8n_workflows_updated; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_n8n_workflows_updated ON n8n.n8n_workflows USING btree (updated_at);


--
-- TOC entry 3954 (class 1259 OID 19656)
-- Name: idx_workflows_tags_workflow_id; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX idx_workflows_tags_workflow_id ON n8n.workflows_tags USING btree ("workflowId");


--
-- TOC entry 3936 (class 1259 OID 19697)
-- Name: pk_credentials_entity_id; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX pk_credentials_entity_id ON n8n.credentials_entity USING btree (id);


--
-- TOC entry 3951 (class 1259 OID 19653)
-- Name: pk_tag_entity_id; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX pk_tag_entity_id ON n8n.tag_entity USING btree (id);


--
-- TOC entry 3976 (class 1259 OID 19708)
-- Name: pk_variables_id; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX pk_variables_id ON n8n.variables USING btree (id);


--
-- TOC entry 3944 (class 1259 OID 19652)
-- Name: pk_workflow_entity_id; Type: INDEX; Schema: n8n; Owner: -
--

CREATE UNIQUE INDEX pk_workflow_entity_id ON n8n.workflow_entity USING btree (id);


--
-- TOC entry 3992 (class 1259 OID 20492)
-- Name: project_relation_role_idx; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX project_relation_role_idx ON n8n.project_relation USING btree (role);


--
-- TOC entry 3993 (class 1259 OID 20493)
-- Name: project_relation_role_project_idx; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX project_relation_role_project_idx ON n8n.project_relation USING btree ("projectId", role);


--
-- TOC entry 3961 (class 1259 OID 20494)
-- Name: user_role_idx; Type: INDEX; Schema: n8n; Owner: -
--

CREATE INDEX user_role_idx ON n8n."user" USING btree ("roleSlug");


--
-- TOC entry 4077 (class 2606 OID 20126)
-- Name: processed_data FK_06a69a7032c97a763c2c7599464; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.processed_data
    ADD CONSTRAINT "FK_06a69a7032c97a763c2c7599464" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4082 (class 2606 OID 20318)
-- Name: insights_metadata FK_1d8ab99d5861c9388d2dc1cf733; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "FK_1d8ab99d5861c9388d2dc1cf733" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE SET NULL;


--
-- TOC entry 4064 (class 2606 OID 19734)
-- Name: workflow_history FK_1e31657f5fe46816c34be7c1b4b; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.workflow_history
    ADD CONSTRAINT "FK_1e31657f5fe46816c34be7c1b4b" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4083 (class 2606 OID 20323)
-- Name: insights_metadata FK_2375a1eda085adb16b24615b69c; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.insights_metadata
    ADD CONSTRAINT "FK_2375a1eda085adb16b24615b69c" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE SET NULL;


--
-- TOC entry 4072 (class 2606 OID 20043)
-- Name: execution_metadata FK_31d0b4c93fb85ced26f6005cda3; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_metadata
    ADD CONSTRAINT "FK_31d0b4c93fb85ced26f6005cda3" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4068 (class 2606 OID 19998)
-- Name: shared_credentials FK_416f66fc846c7c442970c094ccf; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "FK_416f66fc846c7c442970c094ccf" FOREIGN KEY ("credentialsId") REFERENCES n8n.credentials_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4065 (class 2606 OID 19975)
-- Name: project_relation FK_5f0643f6717905a05164090dde7; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_5f0643f6717905a05164090dde7" FOREIGN KEY ("userId") REFERENCES n8n."user"(id) ON DELETE CASCADE;


--
-- TOC entry 4066 (class 2606 OID 19970)
-- Name: project_relation FK_61448d56d61802b5dfde5cdb002; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_61448d56d61802b5dfde5cdb002" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4085 (class 2606 OID 20348)
-- Name: insights_by_period FK_6414cfed98daabbfdd61a1cfbc0; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.insights_by_period
    ADD CONSTRAINT "FK_6414cfed98daabbfdd61a1cfbc0" FOREIGN KEY ("metaId") REFERENCES n8n.insights_metadata("metaId") ON DELETE CASCADE;


--
-- TOC entry 4084 (class 2606 OID 20336)
-- Name: insights_raw FK_6e2e33741adef2a7c5d66befa4e; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.insights_raw
    ADD CONSTRAINT "FK_6e2e33741adef2a7c5d66befa4e" FOREIGN KEY ("metaId") REFERENCES n8n.insights_metadata("metaId") ON DELETE CASCADE;


--
-- TOC entry 4060 (class 2606 OID 19529)
-- Name: installed_nodes FK_73f857fc5dce682cef8a99c11dbddbc969618951; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.installed_nodes
    ADD CONSTRAINT "FK_73f857fc5dce682cef8a99c11dbddbc969618951" FOREIGN KEY (package) REFERENCES n8n.installed_packages("packageName") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4078 (class 2606 OID 20240)
-- Name: folder FK_804ea52f6729e3940498bd54d78; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "FK_804ea52f6729e3940498bd54d78" FOREIGN KEY ("parentFolderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4069 (class 2606 OID 20003)
-- Name: shared_credentials FK_812c2852270da1247756e77f5a4; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.shared_credentials
    ADD CONSTRAINT "FK_812c2852270da1247756e77f5a4" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4087 (class 2606 OID 20378)
-- Name: test_case_execution FK_8e4b4774db42f1e6dda3452b2af; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "FK_8e4b4774db42f1e6dda3452b2af" FOREIGN KEY ("testRunId") REFERENCES n8n.test_run(id) ON DELETE CASCADE;


--
-- TOC entry 4092 (class 2606 OID 20485)
-- Name: data_table_column FK_930b6e8faaf88294cef23484160; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.data_table_column
    ADD CONSTRAINT "FK_930b6e8faaf88294cef23484160" FOREIGN KEY ("dataTableId") REFERENCES n8n.data_table(id) ON DELETE CASCADE;


--
-- TOC entry 4080 (class 2606 OID 20251)
-- Name: folder_tag FK_94a60854e06f2897b2e0d39edba; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "FK_94a60854e06f2897b2e0d39edba" FOREIGN KEY ("folderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4073 (class 2606 OID 20070)
-- Name: execution_annotations FK_97f863fa83c4786f19565084960; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_annotations
    ADD CONSTRAINT "FK_97f863fa83c4786f19565084960" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4074 (class 2606 OID 20094)
-- Name: execution_annotation_tags FK_a3697779b366e131b2bbdae2976; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "FK_a3697779b366e131b2bbdae2976" FOREIGN KEY ("tagId") REFERENCES n8n.annotation_tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4070 (class 2606 OID 20029)
-- Name: shared_workflow FK_a45ea5f27bcfdc21af9b4188560; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "FK_a45ea5f27bcfdc21af9b4188560" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4079 (class 2606 OID 20235)
-- Name: folder FK_a8260b0b36939c6247f385b8221; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.folder
    ADD CONSTRAINT "FK_a8260b0b36939c6247f385b8221" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4075 (class 2606 OID 20089)
-- Name: execution_annotation_tags FK_c1519757391996eb06064f0e7c8; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_annotation_tags
    ADD CONSTRAINT "FK_c1519757391996eb06064f0e7c8" FOREIGN KEY ("annotationId") REFERENCES n8n.execution_annotations(id) ON DELETE CASCADE;


--
-- TOC entry 4091 (class 2606 OID 20471)
-- Name: data_table FK_c2a794257dee48af7c9abf681de; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.data_table
    ADD CONSTRAINT "FK_c2a794257dee48af7c9abf681de" FOREIGN KEY ("projectId") REFERENCES n8n.project(id) ON DELETE CASCADE;


--
-- TOC entry 4067 (class 2606 OID 20428)
-- Name: project_relation FK_c6b99592dc96b0d836d7a21db91; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.project_relation
    ADD CONSTRAINT "FK_c6b99592dc96b0d836d7a21db91" FOREIGN KEY (role) REFERENCES n8n.role(slug);


--
-- TOC entry 4086 (class 2606 OID 20363)
-- Name: test_run FK_d6870d3b6e4c185d33926f423c8; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.test_run
    ADD CONSTRAINT "FK_d6870d3b6e4c185d33926f423c8" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4071 (class 2606 OID 20024)
-- Name: shared_workflow FK_daa206a04983d47d0a9c34649ce; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.shared_workflow
    ADD CONSTRAINT "FK_daa206a04983d47d0a9c34649ce" FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4081 (class 2606 OID 20256)
-- Name: folder_tag FK_dc88164176283de80af47621746; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.folder_tag
    ADD CONSTRAINT "FK_dc88164176283de80af47621746" FOREIGN KEY ("tagId") REFERENCES n8n.tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4076 (class 2606 OID 20110)
-- Name: user_api_keys FK_e131705cbbc8fb589889b02d457; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.user_api_keys
    ADD CONSTRAINT "FK_e131705cbbc8fb589889b02d457" FOREIGN KEY ("userId") REFERENCES n8n."user"(id) ON DELETE CASCADE;


--
-- TOC entry 4088 (class 2606 OID 20383)
-- Name: test_case_execution FK_e48965fac35d0f5b9e7f51d8c44; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.test_case_execution
    ADD CONSTRAINT "FK_e48965fac35d0f5b9e7f51d8c44" FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE SET NULL;


--
-- TOC entry 4059 (class 2606 OID 20423)
-- Name: user FK_eaea92ee7bfb9c1b6cd01505d56; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n."user"
    ADD CONSTRAINT "FK_eaea92ee7bfb9c1b6cd01505d56" FOREIGN KEY ("roleSlug") REFERENCES n8n.role(slug);


--
-- TOC entry 4089 (class 2606 OID 20411)
-- Name: role_scope FK_role; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "FK_role" FOREIGN KEY ("roleSlug") REFERENCES n8n.role(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4090 (class 2606 OID 20416)
-- Name: role_scope FK_scope; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.role_scope
    ADD CONSTRAINT "FK_scope" FOREIGN KEY ("scopeSlug") REFERENCES n8n.scope(slug) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4062 (class 2606 OID 19610)
-- Name: auth_identity auth_identity_userId_fkey; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.auth_identity
    ADD CONSTRAINT "auth_identity_userId_fkey" FOREIGN KEY ("userId") REFERENCES n8n."user"(id);


--
-- TOC entry 4063 (class 2606 OID 19716)
-- Name: execution_data execution_data_fk; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_data
    ADD CONSTRAINT execution_data_fk FOREIGN KEY ("executionId") REFERENCES n8n.execution_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4054 (class 2606 OID 19688)
-- Name: execution_entity fk_execution_entity_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.execution_entity
    ADD CONSTRAINT fk_execution_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4056 (class 2606 OID 19682)
-- Name: webhook_entity fk_webhook_entity_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.webhook_entity
    ADD CONSTRAINT fk_webhook_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4055 (class 2606 OID 20307)
-- Name: workflow_entity fk_workflow_parent_folder; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.workflow_entity
    ADD CONSTRAINT fk_workflow_parent_folder FOREIGN KEY ("parentFolderId") REFERENCES n8n.folder(id) ON DELETE CASCADE;


--
-- TOC entry 4061 (class 2606 OID 19677)
-- Name: workflow_statistics fk_workflow_statistics_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.workflow_statistics
    ADD CONSTRAINT fk_workflow_statistics_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4057 (class 2606 OID 19662)
-- Name: workflows_tags fk_workflows_tags_tag_id; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_tag_id FOREIGN KEY ("tagId") REFERENCES n8n.tag_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4058 (class 2606 OID 19657)
-- Name: workflows_tags fk_workflows_tags_workflow_id; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_workflow_id FOREIGN KEY ("workflowId") REFERENCES n8n.workflow_entity(id) ON DELETE CASCADE;


--
-- TOC entry 4053 (class 2606 OID 19019)
-- Name: migration_metadata migration_metadata_workflow_id_fkey; Type: FK CONSTRAINT; Schema: n8n; Owner: -
--

ALTER TABLE ONLY n8n.migration_metadata
    ADD CONSTRAINT migration_metadata_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES n8n.n8n_workflows(id);


-- Completed on 2025-10-09 23:06:19 UTC

--
-- PostgreSQL database dump complete
--

