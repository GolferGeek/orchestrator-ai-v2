--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS pgrst_drop_watch;
DROP EVENT TRIGGER IF EXISTS pgrst_ddl_watch;
DROP EVENT TRIGGER IF EXISTS issue_pg_net_access;
DROP EVENT TRIGGER IF EXISTS issue_pg_graphql_access;
DROP EVENT TRIGGER IF EXISTS issue_pg_cron_access;
DROP EVENT TRIGGER IF EXISTS issue_graphql_placeholder;
DROP PUBLICATION IF EXISTS supabase_realtime;
DROP POLICY IF EXISTS vault_access_admin_only ON public.sensitive_data_vault;
DROP POLICY IF EXISTS audit_log_read_own_or_admin ON public.redaction_audit_log;
DROP POLICY IF EXISTS "Users can view own project steps" ON public.project_steps;
DROP POLICY IF EXISTS "Users can view own deliverable versions" ON public.deliverable_versions;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads_parts DROP CONSTRAINT IF EXISTS s3_multipart_uploads_parts_upload_id_fkey;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads_parts DROP CONSTRAINT IF EXISTS s3_multipart_uploads_parts_bucket_id_fkey;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads DROP CONSTRAINT IF EXISTS s3_multipart_uploads_bucket_id_fkey;
ALTER TABLE IF EXISTS ONLY storage.prefixes DROP CONSTRAINT IF EXISTS "prefixes_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY storage.objects DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY storage.iceberg_tables DROP CONSTRAINT IF EXISTS iceberg_tables_namespace_id_fkey;
ALTER TABLE IF EXISTS ONLY storage.iceberg_tables DROP CONSTRAINT IF EXISTS iceberg_tables_bucket_id_fkey;
ALTER TABLE IF EXISTS ONLY storage.iceberg_namespaces DROP CONSTRAINT IF EXISTS iceberg_namespaces_bucket_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_cidafm_commands DROP CONSTRAINT IF EXISTS user_cidafm_commands_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_cidafm_commands DROP CONSTRAINT IF EXISTS user_cidafm_commands_command_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_agent_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sensitive_data_vault DROP CONSTRAINT IF EXISTS sensitive_data_vault_pseudonym_mapping_id_fkey;
ALTER TABLE IF EXISTS ONLY public.redaction_patterns DROP CONSTRAINT IF EXISTS redaction_patterns_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.redaction_audit_log DROP CONSTRAINT IF EXISTS redaction_audit_log_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_parent_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.project_steps DROP CONSTRAINT IF EXISTS project_steps_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.llm_models DROP CONSTRAINT IF EXISTS llm_models_provider_name_fkey;
ALTER TABLE IF EXISTS ONLY public.langgraph_states DROP CONSTRAINT IF EXISTS langgraph_states_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.kpi_goals DROP CONSTRAINT IF EXISTS kpi_goals_metric_id_fkey;
ALTER TABLE IF EXISTS ONLY public.kpi_goals DROP CONSTRAINT IF EXISTS kpi_goals_department_id_fkey;
ALTER TABLE IF EXISTS ONLY public.kpi_data DROP CONSTRAINT IF EXISTS kpi_data_metric_id_fkey;
ALTER TABLE IF EXISTS ONLY public.kpi_data DROP CONSTRAINT IF EXISTS kpi_data_department_id_fkey;
ALTER TABLE IF EXISTS ONLY public.human_inputs DROP CONSTRAINT IF EXISTS human_inputs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.human_inputs DROP CONSTRAINT IF EXISTS human_inputs_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deliverables DROP CONSTRAINT IF EXISTS fk_deliverables_conversation_id;
ALTER TABLE IF EXISTS ONLY public.deliverable_versions DROP CONSTRAINT IF EXISTS fk_deliverable_versions_deliverable_id;
ALTER TABLE IF EXISTS ONLY public.departments DROP CONSTRAINT IF EXISTS departments_company_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deliverables DROP CONSTRAINT IF EXISTS deliverables_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deliverables DROP CONSTRAINT IF EXISTS deliverables_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deliverables DROP CONSTRAINT IF EXISTS deliverables_project_step_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deliverable_versions DROP CONSTRAINT IF EXISTS deliverable_versions_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deliverable_versions DROP CONSTRAINT IF EXISTS deliverable_versions_deliverable_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agent_conversations DROP CONSTRAINT IF EXISTS agent_conversations_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.sso_domains DROP CONSTRAINT IF EXISTS sso_domains_sso_provider_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.sessions DROP CONSTRAINT IF EXISTS sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.sessions DROP CONSTRAINT IF EXISTS sessions_oauth_client_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.saml_relay_states DROP CONSTRAINT IF EXISTS saml_relay_states_sso_provider_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.saml_relay_states DROP CONSTRAINT IF EXISTS saml_relay_states_flow_state_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.saml_providers DROP CONSTRAINT IF EXISTS saml_providers_sso_provider_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_session_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.one_time_tokens DROP CONSTRAINT IF EXISTS one_time_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_consents DROP CONSTRAINT IF EXISTS oauth_consents_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_consents DROP CONSTRAINT IF EXISTS oauth_consents_client_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_client_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_factors DROP CONSTRAINT IF EXISTS mfa_factors_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_challenges DROP CONSTRAINT IF EXISTS mfa_challenges_auth_factor_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_amr_claims DROP CONSTRAINT IF EXISTS mfa_amr_claims_session_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.identities DROP CONSTRAINT IF EXISTS identities_user_id_fkey;
ALTER TABLE IF EXISTS ONLY _realtime.extensions DROP CONSTRAINT IF EXISTS extensions_tenant_external_id_fkey;
DROP TRIGGER IF EXISTS update_objects_updated_at ON storage.objects;
DROP TRIGGER IF EXISTS prefixes_delete_hierarchy ON storage.prefixes;
DROP TRIGGER IF EXISTS prefixes_create_hierarchy ON storage.prefixes;
DROP TRIGGER IF EXISTS objects_update_create_prefix ON storage.objects;
DROP TRIGGER IF EXISTS objects_insert_create_prefix ON storage.objects;
DROP TRIGGER IF EXISTS objects_delete_delete_prefix ON storage.objects;
DROP TRIGGER IF EXISTS enforce_bucket_name_length_trigger ON storage.buckets;
DROP TRIGGER IF EXISTS tr_check_filters ON realtime.subscription;
DROP TRIGGER IF EXISTS update_redaction_patterns_updated_at ON public.redaction_patterns;
DROP TRIGGER IF EXISTS update_project_steps_updated_at ON public.project_steps;
DROP TRIGGER IF EXISTS update_orchestrator_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_orchestrator_tasks_updated_at ON public.tasks;
DROP TRIGGER IF EXISTS update_orchestrator_projects_updated_at ON public.projects;
DROP TRIGGER IF EXISTS update_orchestrator_project_steps_updated_at ON public.project_steps;
DROP TRIGGER IF EXISTS update_orchestrator_langgraph_states_updated_at ON public.langgraph_states;
DROP TRIGGER IF EXISTS update_orchestrator_human_inputs_updated_at ON public.human_inputs;
DROP TRIGGER IF EXISTS update_orchestrator_deliverables_updated_at ON public.deliverables;
DROP TRIGGER IF EXISTS update_orchestrator_cidafm_commands_updated_at ON public.cidafm_commands;
DROP TRIGGER IF EXISTS update_orchestrator_agent_conversations_updated_at ON public.agent_conversations;
DROP TRIGGER IF EXISTS update_deliverable_versions_updated_at ON public.deliverable_versions;
DROP TRIGGER IF EXISTS update_company_kpi_metrics_updated_at ON public.kpi_metrics;
DROP TRIGGER IF EXISTS update_company_kpi_goals_updated_at ON public.kpi_goals;
DROP TRIGGER IF EXISTS update_company_kpi_data_updated_at ON public.kpi_data;
DROP TRIGGER IF EXISTS update_company_departments_updated_at ON public.departments;
DROP TRIGGER IF EXISTS update_company_companies_updated_at ON public.companies;
DROP INDEX IF EXISTS supabase_functions.supabase_functions_hooks_request_id_idx;
DROP INDEX IF EXISTS supabase_functions.supabase_functions_hooks_h_table_id_h_name_idx;
DROP INDEX IF EXISTS storage.objects_bucket_id_level_idx;
DROP INDEX IF EXISTS storage.name_prefix_search;
DROP INDEX IF EXISTS storage.idx_prefixes_lower_name;
DROP INDEX IF EXISTS storage.idx_objects_lower_name;
DROP INDEX IF EXISTS storage.idx_objects_bucket_id_name;
DROP INDEX IF EXISTS storage.idx_name_bucket_level_unique;
DROP INDEX IF EXISTS storage.idx_multipart_uploads_list;
DROP INDEX IF EXISTS storage.idx_iceberg_tables_namespace_id;
DROP INDEX IF EXISTS storage.idx_iceberg_namespaces_bucket_id;
DROP INDEX IF EXISTS storage.bucketid_objname;
DROP INDEX IF EXISTS storage.bname;
DROP INDEX IF EXISTS realtime.subscription_subscription_id_entity_filters_key;
DROP INDEX IF EXISTS realtime.messages_2025_11_08_inserted_at_topic_idx;
DROP INDEX IF EXISTS realtime.messages_2025_11_07_inserted_at_topic_idx;
DROP INDEX IF EXISTS realtime.messages_2025_11_06_inserted_at_topic_idx;
DROP INDEX IF EXISTS realtime.messages_2025_11_05_inserted_at_topic_idx;
DROP INDEX IF EXISTS realtime.messages_2025_11_04_inserted_at_topic_idx;
DROP INDEX IF EXISTS realtime.messages_inserted_at_topic_index;
DROP INDEX IF EXISTS realtime.ix_realtime_subscription_entity;
DROP INDEX IF EXISTS public.idx_sensitive_vault_retention;
DROP INDEX IF EXISTS public.idx_sensitive_vault_mapping;
DROP INDEX IF EXISTS public.idx_redaction_patterns_category;
DROP INDEX IF EXISTS public.idx_redaction_patterns_active;
DROP INDEX IF EXISTS public.idx_redaction_audit_user;
DROP INDEX IF EXISTS public.idx_redaction_audit_session;
DROP INDEX IF EXISTS public.idx_redaction_audit_run;
DROP INDEX IF EXISTS public.idx_redaction_audit_operation;
DROP INDEX IF EXISTS public.idx_redaction_audit_created;
DROP INDEX IF EXISTS public.idx_pseudonym_mappings_type;
DROP INDEX IF EXISTS public.idx_pseudonym_mappings_hash;
DROP INDEX IF EXISTS public.idx_pseudonym_mappings_expires;
DROP INDEX IF EXISTS public.idx_pseudonym_mappings_context;
DROP INDEX IF EXISTS public.idx_pseudonym_dict_type;
DROP INDEX IF EXISTS public.idx_pseudonym_dict_locale;
DROP INDEX IF EXISTS public.idx_pseudonym_dict_category;
DROP INDEX IF EXISTS public.idx_project_steps_step_index;
DROP INDEX IF EXISTS public.idx_project_steps_status;
DROP INDEX IF EXISTS public.idx_project_steps_project_id;
DROP INDEX IF EXISTS public.idx_orchestrator_users_status;
DROP INDEX IF EXISTS public.idx_orchestrator_users_email;
DROP INDEX IF EXISTS public.idx_orchestrator_user_cidafm_user;
DROP INDEX IF EXISTS public.idx_orchestrator_user_cidafm_active;
DROP INDEX IF EXISTS public.idx_orchestrator_tasks_user;
DROP INDEX IF EXISTS public.idx_orchestrator_tasks_status;
DROP INDEX IF EXISTS public.idx_orchestrator_tasks_created;
DROP INDEX IF EXISTS public.idx_orchestrator_tasks_conversation;
DROP INDEX IF EXISTS public.idx_orchestrator_projects_user;
DROP INDEX IF EXISTS public.idx_orchestrator_projects_status;
DROP INDEX IF EXISTS public.idx_orchestrator_projects_parent;
DROP INDEX IF EXISTS public.idx_orchestrator_projects_conversation;
DROP INDEX IF EXISTS public.idx_orchestrator_project_steps_status;
DROP INDEX IF EXISTS public.idx_orchestrator_project_steps_project;
DROP INDEX IF EXISTS public.idx_orchestrator_project_steps_index;
DROP INDEX IF EXISTS public.idx_orchestrator_langgraph_states_version;
DROP INDEX IF EXISTS public.idx_orchestrator_langgraph_states_project;
DROP INDEX IF EXISTS public.idx_orchestrator_human_inputs_user;
DROP INDEX IF EXISTS public.idx_orchestrator_human_inputs_timeout;
DROP INDEX IF EXISTS public.idx_orchestrator_human_inputs_task;
DROP INDEX IF EXISTS public.idx_orchestrator_human_inputs_status;
DROP INDEX IF EXISTS public.idx_orchestrator_human_inputs_created;
DROP INDEX IF EXISTS public.idx_orchestrator_deliverables_user;
DROP INDEX IF EXISTS public.idx_orchestrator_deliverables_type;
DROP INDEX IF EXISTS public.idx_orchestrator_deliverables_conversation;
DROP INDEX IF EXISTS public.idx_orchestrator_cidafm_commands_type;
DROP INDEX IF EXISTS public.idx_orchestrator_cidafm_commands_name;
DROP INDEX IF EXISTS public.idx_orchestrator_agent_conversations_user;
DROP INDEX IF EXISTS public.idx_orchestrator_agent_conversations_agent;
DROP INDEX IF EXISTS public.idx_orchestrator_agent_conversations_active;
DROP INDEX IF EXISTS public.idx_llm_usage_user_id;
DROP INDEX IF EXISTS public.idx_llm_usage_timestamp;
DROP INDEX IF EXISTS public.idx_llm_usage_session;
DROP INDEX IF EXISTS public.idx_llm_usage_provider_model;
DROP INDEX IF EXISTS public.idx_llm_models_provider;
DROP INDEX IF EXISTS public.idx_llm_models_local;
DROP INDEX IF EXISTS public.idx_llm_models_active;
DROP INDEX IF EXISTS public.idx_deliverables_user_id;
DROP INDEX IF EXISTS public.idx_deliverables_type;
DROP INDEX IF EXISTS public.idx_deliverables_task_id;
DROP INDEX IF EXISTS public.idx_deliverables_standalone;
DROP INDEX IF EXISTS public.idx_deliverables_project_step_id;
DROP INDEX IF EXISTS public.idx_deliverables_conversation_id;
DROP INDEX IF EXISTS public.idx_deliverables_agent_name;
DROP INDEX IF EXISTS public.idx_deliverable_versions_version_number;
DROP INDEX IF EXISTS public.idx_deliverable_versions_task_id;
DROP INDEX IF EXISTS public.idx_deliverable_versions_number;
DROP INDEX IF EXISTS public.idx_deliverable_versions_deliverable_id;
DROP INDEX IF EXISTS public.idx_deliverable_versions_current;
DROP INDEX IF EXISTS public.idx_deliverable_versions_created_by_type;
DROP INDEX IF EXISTS public.idx_company_kpi_metrics_type;
DROP INDEX IF EXISTS public.idx_company_kpi_metrics_name;
DROP INDEX IF EXISTS public.idx_company_kpi_goals_period;
DROP INDEX IF EXISTS public.idx_company_kpi_goals_metric;
DROP INDEX IF EXISTS public.idx_company_kpi_goals_department;
DROP INDEX IF EXISTS public.idx_company_kpi_data_metric;
DROP INDEX IF EXISTS public.idx_company_kpi_data_dept_metric_date;
DROP INDEX IF EXISTS public.idx_company_kpi_data_department;
DROP INDEX IF EXISTS public.idx_company_kpi_data_date;
DROP INDEX IF EXISTS public.idx_company_departments_name;
DROP INDEX IF EXISTS public.idx_company_departments_company;
DROP INDEX IF EXISTS public.idx_company_companies_name;
DROP INDEX IF EXISTS public.idx_company_companies_industry;
DROP INDEX IF EXISTS auth.users_is_anonymous_idx;
DROP INDEX IF EXISTS auth.users_instance_id_idx;
DROP INDEX IF EXISTS auth.users_instance_id_email_idx;
DROP INDEX IF EXISTS auth.users_email_partial_key;
DROP INDEX IF EXISTS auth.user_id_created_at_idx;
DROP INDEX IF EXISTS auth.unique_phone_factor_per_user;
DROP INDEX IF EXISTS auth.sso_providers_resource_id_pattern_idx;
DROP INDEX IF EXISTS auth.sso_providers_resource_id_idx;
DROP INDEX IF EXISTS auth.sso_domains_sso_provider_id_idx;
DROP INDEX IF EXISTS auth.sso_domains_domain_idx;
DROP INDEX IF EXISTS auth.sessions_user_id_idx;
DROP INDEX IF EXISTS auth.sessions_oauth_client_id_idx;
DROP INDEX IF EXISTS auth.sessions_not_after_idx;
DROP INDEX IF EXISTS auth.saml_relay_states_sso_provider_id_idx;
DROP INDEX IF EXISTS auth.saml_relay_states_for_email_idx;
DROP INDEX IF EXISTS auth.saml_relay_states_created_at_idx;
DROP INDEX IF EXISTS auth.saml_providers_sso_provider_id_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_updated_at_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_session_id_revoked_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_parent_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_instance_id_user_id_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_instance_id_idx;
DROP INDEX IF EXISTS auth.recovery_token_idx;
DROP INDEX IF EXISTS auth.reauthentication_token_idx;
DROP INDEX IF EXISTS auth.one_time_tokens_user_id_token_type_key;
DROP INDEX IF EXISTS auth.one_time_tokens_token_hash_hash_idx;
DROP INDEX IF EXISTS auth.one_time_tokens_relates_to_hash_idx;
DROP INDEX IF EXISTS auth.oauth_consents_user_order_idx;
DROP INDEX IF EXISTS auth.oauth_consents_active_user_client_idx;
DROP INDEX IF EXISTS auth.oauth_consents_active_client_idx;
DROP INDEX IF EXISTS auth.oauth_clients_deleted_at_idx;
DROP INDEX IF EXISTS auth.oauth_auth_pending_exp_idx;
DROP INDEX IF EXISTS auth.mfa_factors_user_id_idx;
DROP INDEX IF EXISTS auth.mfa_factors_user_friendly_name_unique;
DROP INDEX IF EXISTS auth.mfa_challenge_created_at_idx;
DROP INDEX IF EXISTS auth.idx_user_id_auth_method;
DROP INDEX IF EXISTS auth.idx_auth_code;
DROP INDEX IF EXISTS auth.identities_user_id_idx;
DROP INDEX IF EXISTS auth.identities_email_idx;
DROP INDEX IF EXISTS auth.flow_state_created_at_idx;
DROP INDEX IF EXISTS auth.factor_id_created_at_idx;
DROP INDEX IF EXISTS auth.email_change_token_new_idx;
DROP INDEX IF EXISTS auth.email_change_token_current_idx;
DROP INDEX IF EXISTS auth.confirmation_token_idx;
DROP INDEX IF EXISTS auth.audit_logs_instance_id_idx;
DROP INDEX IF EXISTS _realtime.tenants_external_id_index;
DROP INDEX IF EXISTS _realtime.extensions_tenant_external_id_type_index;
DROP INDEX IF EXISTS _realtime.extensions_tenant_external_id_index;
ALTER TABLE IF EXISTS ONLY supabase_migrations.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY supabase_functions.migrations DROP CONSTRAINT IF EXISTS migrations_pkey;
ALTER TABLE IF EXISTS ONLY supabase_functions.hooks DROP CONSTRAINT IF EXISTS hooks_pkey;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads DROP CONSTRAINT IF EXISTS s3_multipart_uploads_pkey;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads_parts DROP CONSTRAINT IF EXISTS s3_multipart_uploads_parts_pkey;
ALTER TABLE IF EXISTS ONLY storage.prefixes DROP CONSTRAINT IF EXISTS prefixes_pkey;
ALTER TABLE IF EXISTS ONLY storage.objects DROP CONSTRAINT IF EXISTS objects_pkey;
ALTER TABLE IF EXISTS ONLY storage.migrations DROP CONSTRAINT IF EXISTS migrations_pkey;
ALTER TABLE IF EXISTS ONLY storage.migrations DROP CONSTRAINT IF EXISTS migrations_name_key;
ALTER TABLE IF EXISTS ONLY storage.iceberg_tables DROP CONSTRAINT IF EXISTS iceberg_tables_pkey;
ALTER TABLE IF EXISTS ONLY storage.iceberg_namespaces DROP CONSTRAINT IF EXISTS iceberg_namespaces_pkey;
ALTER TABLE IF EXISTS ONLY storage.buckets DROP CONSTRAINT IF EXISTS buckets_pkey;
ALTER TABLE IF EXISTS ONLY storage.buckets_analytics DROP CONSTRAINT IF EXISTS buckets_analytics_pkey;
ALTER TABLE IF EXISTS ONLY realtime.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY realtime.subscription DROP CONSTRAINT IF EXISTS pk_subscription;
ALTER TABLE IF EXISTS ONLY realtime.messages_2025_11_08 DROP CONSTRAINT IF EXISTS messages_2025_11_08_pkey;
ALTER TABLE IF EXISTS ONLY realtime.messages_2025_11_07 DROP CONSTRAINT IF EXISTS messages_2025_11_07_pkey;
ALTER TABLE IF EXISTS ONLY realtime.messages_2025_11_06 DROP CONSTRAINT IF EXISTS messages_2025_11_06_pkey;
ALTER TABLE IF EXISTS ONLY realtime.messages_2025_11_05 DROP CONSTRAINT IF EXISTS messages_2025_11_05_pkey;
ALTER TABLE IF EXISTS ONLY realtime.messages_2025_11_04 DROP CONSTRAINT IF EXISTS messages_2025_11_04_pkey;
ALTER TABLE IF EXISTS ONLY realtime.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_cidafm_commands DROP CONSTRAINT IF EXISTS user_cidafm_commands_user_id_command_id_key;
ALTER TABLE IF EXISTS ONLY public.user_cidafm_commands DROP CONSTRAINT IF EXISTS user_cidafm_commands_pkey;
ALTER TABLE IF EXISTS ONLY public.deliverable_versions DROP CONSTRAINT IF EXISTS unique_version_number_per_deliverable;
ALTER TABLE IF EXISTS ONLY public.deliverables DROP CONSTRAINT IF EXISTS unique_deliverable_per_conversation;
ALTER TABLE IF EXISTS ONLY public.deliverable_versions DROP CONSTRAINT IF EXISTS unique_current_version_per_deliverable;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.sensitive_data_vault DROP CONSTRAINT IF EXISTS sensitive_data_vault_pkey;
ALTER TABLE IF EXISTS ONLY public.role_audit_log DROP CONSTRAINT IF EXISTS role_audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.redaction_patterns DROP CONSTRAINT IF EXISTS redaction_patterns_pkey;
ALTER TABLE IF EXISTS ONLY public.redaction_patterns DROP CONSTRAINT IF EXISTS redaction_patterns_name_key;
ALTER TABLE IF EXISTS ONLY public.redaction_audit_log DROP CONSTRAINT IF EXISTS redaction_audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.pseudonym_mappings DROP CONSTRAINT IF EXISTS pseudonym_mappings_pkey;
ALTER TABLE IF EXISTS ONLY public.pseudonym_mappings DROP CONSTRAINT IF EXISTS pseudonym_mappings_original_hash_key;
ALTER TABLE IF EXISTS ONLY public.pseudonym_dictionaries DROP CONSTRAINT IF EXISTS pseudonym_dictionaries_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.project_steps DROP CONSTRAINT IF EXISTS project_steps_project_id_step_id_key;
ALTER TABLE IF EXISTS ONLY public.project_steps DROP CONSTRAINT IF EXISTS project_steps_pkey;
ALTER TABLE IF EXISTS ONLY public.llm_usage DROP CONSTRAINT IF EXISTS llm_usage_pkey;
ALTER TABLE IF EXISTS ONLY public.llm_providers DROP CONSTRAINT IF EXISTS llm_providers_pkey;
ALTER TABLE IF EXISTS ONLY public.llm_models DROP CONSTRAINT IF EXISTS llm_models_pkey;
ALTER TABLE IF EXISTS ONLY public.langgraph_states DROP CONSTRAINT IF EXISTS langgraph_states_pkey;
ALTER TABLE IF EXISTS ONLY public.kpi_metrics DROP CONSTRAINT IF EXISTS kpi_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.kpi_goals DROP CONSTRAINT IF EXISTS kpi_goals_pkey;
ALTER TABLE IF EXISTS ONLY public.kpi_data DROP CONSTRAINT IF EXISTS kpi_data_pkey;
ALTER TABLE IF EXISTS ONLY public.human_inputs DROP CONSTRAINT IF EXISTS human_inputs_pkey;
ALTER TABLE IF EXISTS ONLY public.departments DROP CONSTRAINT IF EXISTS departments_pkey;
ALTER TABLE IF EXISTS ONLY public.deliverables DROP CONSTRAINT IF EXISTS deliverables_pkey;
ALTER TABLE IF EXISTS ONLY public.deliverable_versions DROP CONSTRAINT IF EXISTS deliverable_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.companies DROP CONSTRAINT IF EXISTS companies_pkey;
ALTER TABLE IF EXISTS ONLY public.cidafm_commands DROP CONSTRAINT IF EXISTS cidafm_commands_pkey;
ALTER TABLE IF EXISTS ONLY public.cidafm_commands DROP CONSTRAINT IF EXISTS cidafm_commands_name_key;
ALTER TABLE IF EXISTS ONLY public.agent_conversations DROP CONSTRAINT IF EXISTS agent_conversations_pkey;
ALTER TABLE IF EXISTS ONLY auth.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY auth.users DROP CONSTRAINT IF EXISTS users_phone_key;
ALTER TABLE IF EXISTS ONLY auth.sso_providers DROP CONSTRAINT IF EXISTS sso_providers_pkey;
ALTER TABLE IF EXISTS ONLY auth.sso_domains DROP CONSTRAINT IF EXISTS sso_domains_pkey;
ALTER TABLE IF EXISTS ONLY auth.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY auth.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY auth.saml_relay_states DROP CONSTRAINT IF EXISTS saml_relay_states_pkey;
ALTER TABLE IF EXISTS ONLY auth.saml_providers DROP CONSTRAINT IF EXISTS saml_providers_pkey;
ALTER TABLE IF EXISTS ONLY auth.saml_providers DROP CONSTRAINT IF EXISTS saml_providers_entity_id_key;
ALTER TABLE IF EXISTS ONLY auth.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_token_unique;
ALTER TABLE IF EXISTS ONLY auth.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_pkey;
ALTER TABLE IF EXISTS ONLY auth.one_time_tokens DROP CONSTRAINT IF EXISTS one_time_tokens_pkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_consents DROP CONSTRAINT IF EXISTS oauth_consents_user_client_unique;
ALTER TABLE IF EXISTS ONLY auth.oauth_consents DROP CONSTRAINT IF EXISTS oauth_consents_pkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_clients DROP CONSTRAINT IF EXISTS oauth_clients_pkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_pkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_authorization_id_key;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_authorization_code_key;
ALTER TABLE IF EXISTS ONLY auth.mfa_factors DROP CONSTRAINT IF EXISTS mfa_factors_pkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_factors DROP CONSTRAINT IF EXISTS mfa_factors_last_challenged_at_key;
ALTER TABLE IF EXISTS ONLY auth.mfa_challenges DROP CONSTRAINT IF EXISTS mfa_challenges_pkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_amr_claims DROP CONSTRAINT IF EXISTS mfa_amr_claims_session_id_authentication_method_pkey;
ALTER TABLE IF EXISTS ONLY auth.instances DROP CONSTRAINT IF EXISTS instances_pkey;
ALTER TABLE IF EXISTS ONLY auth.identities DROP CONSTRAINT IF EXISTS identities_provider_id_provider_unique;
ALTER TABLE IF EXISTS ONLY auth.identities DROP CONSTRAINT IF EXISTS identities_pkey;
ALTER TABLE IF EXISTS ONLY auth.flow_state DROP CONSTRAINT IF EXISTS flow_state_pkey;
ALTER TABLE IF EXISTS ONLY auth.audit_log_entries DROP CONSTRAINT IF EXISTS audit_log_entries_pkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_amr_claims DROP CONSTRAINT IF EXISTS amr_id_pk;
ALTER TABLE IF EXISTS ONLY _realtime.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY _realtime.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY _realtime.extensions DROP CONSTRAINT IF EXISTS extensions_pkey;
ALTER TABLE IF EXISTS supabase_functions.hooks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS auth.refresh_tokens ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS supabase_migrations.schema_migrations;
DROP TABLE IF EXISTS supabase_functions.migrations;
DROP SEQUENCE IF EXISTS supabase_functions.hooks_id_seq;
DROP TABLE IF EXISTS supabase_functions.hooks;
DROP TABLE IF EXISTS storage.s3_multipart_uploads_parts;
DROP TABLE IF EXISTS storage.s3_multipart_uploads;
DROP TABLE IF EXISTS storage.prefixes;
DROP TABLE IF EXISTS storage.objects;
DROP TABLE IF EXISTS storage.migrations;
DROP TABLE IF EXISTS storage.iceberg_tables;
DROP TABLE IF EXISTS storage.iceberg_namespaces;
DROP TABLE IF EXISTS storage.buckets_analytics;
DROP TABLE IF EXISTS storage.buckets;
DROP TABLE IF EXISTS realtime.subscription;
DROP TABLE IF EXISTS realtime.schema_migrations;
DROP TABLE IF EXISTS realtime.messages_2025_11_08;
DROP TABLE IF EXISTS realtime.messages_2025_11_07;
DROP TABLE IF EXISTS realtime.messages_2025_11_06;
DROP TABLE IF EXISTS realtime.messages_2025_11_05;
DROP TABLE IF EXISTS realtime.messages_2025_11_04;
DROP TABLE IF EXISTS realtime.messages;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_cidafm_commands;
DROP TABLE IF EXISTS public.tasks;
DROP TABLE IF EXISTS public.sensitive_data_vault;
DROP TABLE IF EXISTS public.role_audit_log;
DROP TABLE IF EXISTS public.redaction_patterns;
DROP TABLE IF EXISTS public.redaction_audit_log;
DROP TABLE IF EXISTS public.pseudonym_mappings;
DROP TABLE IF EXISTS public.pseudonym_dictionaries;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.project_steps;
DROP TABLE IF EXISTS public.llm_usage_backup;
DROP TABLE IF EXISTS public.llm_usage;
DROP TABLE IF EXISTS public.llm_providers_backup;
DROP TABLE IF EXISTS public.llm_providers;
DROP TABLE IF EXISTS public.llm_models_backup;
DROP TABLE IF EXISTS public.llm_models;
DROP TABLE IF EXISTS public.langgraph_states;
DROP TABLE IF EXISTS public.kpi_metrics;
DROP TABLE IF EXISTS public.kpi_goals;
DROP TABLE IF EXISTS public.kpi_data;
DROP TABLE IF EXISTS public.human_inputs;
DROP TABLE IF EXISTS public.departments;
DROP TABLE IF EXISTS public.deliverables;
DROP TABLE IF EXISTS public.deliverable_versions;
DROP TABLE IF EXISTS public.companies;
DROP TABLE IF EXISTS public.cidafm_commands;
DROP TABLE IF EXISTS public.agent_conversations;
DROP TABLE IF EXISTS auth.users;
DROP TABLE IF EXISTS auth.sso_providers;
DROP TABLE IF EXISTS auth.sso_domains;
DROP TABLE IF EXISTS auth.sessions;
DROP TABLE IF EXISTS auth.schema_migrations;
DROP TABLE IF EXISTS auth.saml_relay_states;
DROP TABLE IF EXISTS auth.saml_providers;
DROP SEQUENCE IF EXISTS auth.refresh_tokens_id_seq;
DROP TABLE IF EXISTS auth.refresh_tokens;
DROP TABLE IF EXISTS auth.one_time_tokens;
DROP TABLE IF EXISTS auth.oauth_consents;
DROP TABLE IF EXISTS auth.oauth_clients;
DROP TABLE IF EXISTS auth.oauth_authorizations;
DROP TABLE IF EXISTS auth.mfa_factors;
DROP TABLE IF EXISTS auth.mfa_challenges;
DROP TABLE IF EXISTS auth.mfa_amr_claims;
DROP TABLE IF EXISTS auth.instances;
DROP TABLE IF EXISTS auth.identities;
DROP TABLE IF EXISTS auth.flow_state;
DROP TABLE IF EXISTS auth.audit_log_entries;
DROP TABLE IF EXISTS _realtime.tenants;
DROP TABLE IF EXISTS _realtime.schema_migrations;
DROP TABLE IF EXISTS _realtime.extensions;
DROP FUNCTION IF EXISTS supabase_functions.http_request();
DROP FUNCTION IF EXISTS storage.update_updated_at_column();
DROP FUNCTION IF EXISTS storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text);
DROP FUNCTION IF EXISTS storage.search_v1_optimised(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text);
DROP FUNCTION IF EXISTS storage.search_legacy_v1(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text);
DROP FUNCTION IF EXISTS storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text);
DROP FUNCTION IF EXISTS storage.prefixes_insert_trigger();
DROP FUNCTION IF EXISTS storage.prefixes_delete_cleanup();
DROP FUNCTION IF EXISTS storage.operation();
DROP FUNCTION IF EXISTS storage.objects_update_prefix_trigger();
DROP FUNCTION IF EXISTS storage.objects_update_level_trigger();
DROP FUNCTION IF EXISTS storage.objects_update_cleanup();
DROP FUNCTION IF EXISTS storage.objects_insert_prefix_trigger();
DROP FUNCTION IF EXISTS storage.objects_delete_cleanup();
DROP FUNCTION IF EXISTS storage.lock_top_prefixes(bucket_ids text[], names text[]);
DROP FUNCTION IF EXISTS storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text);
DROP FUNCTION IF EXISTS storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text);
DROP FUNCTION IF EXISTS storage.get_size_by_bucket();
DROP FUNCTION IF EXISTS storage.get_prefixes(name text);
DROP FUNCTION IF EXISTS storage.get_prefix(name text);
DROP FUNCTION IF EXISTS storage.get_level(name text);
DROP FUNCTION IF EXISTS storage.foldername(name text);
DROP FUNCTION IF EXISTS storage.filename(name text);
DROP FUNCTION IF EXISTS storage.extension(name text);
DROP FUNCTION IF EXISTS storage.enforce_bucket_name_length();
DROP FUNCTION IF EXISTS storage.delete_prefix_hierarchy_trigger();
DROP FUNCTION IF EXISTS storage.delete_prefix(_bucket_id text, _name text);
DROP FUNCTION IF EXISTS storage.delete_leaf_prefixes(bucket_ids text[], names text[]);
DROP FUNCTION IF EXISTS storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb);
DROP FUNCTION IF EXISTS storage.add_prefixes(_bucket_id text, _name text);
DROP FUNCTION IF EXISTS realtime.topic();
DROP FUNCTION IF EXISTS realtime.to_regrole(role_name text);
DROP FUNCTION IF EXISTS realtime.subscription_check_filters();
DROP FUNCTION IF EXISTS realtime.send(payload jsonb, event text, topic text, private boolean);
DROP FUNCTION IF EXISTS realtime.quote_wal2json(entity regclass);
DROP FUNCTION IF EXISTS realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer);
DROP FUNCTION IF EXISTS realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]);
DROP FUNCTION IF EXISTS realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text);
DROP FUNCTION IF EXISTS realtime."cast"(val text, type_ regtype);
DROP FUNCTION IF EXISTS realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]);
DROP FUNCTION IF EXISTS realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text);
DROP FUNCTION IF EXISTS realtime.apply_rls(wal jsonb, max_record_bytes integer);
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.update_llm_usage_updated_at();
DROP FUNCTION IF EXISTS public.increment_usage_counter();
DROP FUNCTION IF EXISTS public.get_current_deliverable_version(deliverable_uuid uuid);
DROP FUNCTION IF EXISTS public.get_compliance_status(p_llm_usage_id uuid);
DROP FUNCTION IF EXISTS public.exec_sql(query text);
DROP FUNCTION IF EXISTS public.create_deliverable_version(deliverable_uuid uuid, version_content text, version_format character varying, creation_type character varying, version_task_id uuid, version_metadata jsonb);
DROP FUNCTION IF EXISTS public.calculate_sanitization_score(p_pii_detected boolean, p_sanitization_level character varying, p_redactions_applied integer, p_pseudonyms_used integer);
DROP FUNCTION IF EXISTS pgbouncer.get_auth(p_usename text);
DROP FUNCTION IF EXISTS extensions.set_graphql_placeholder();
DROP FUNCTION IF EXISTS extensions.pgrst_drop_watch();
DROP FUNCTION IF EXISTS extensions.pgrst_ddl_watch();
DROP FUNCTION IF EXISTS extensions.grant_pg_net_access();
DROP FUNCTION IF EXISTS extensions.grant_pg_graphql_access();
DROP FUNCTION IF EXISTS extensions.grant_pg_cron_access();
DROP FUNCTION IF EXISTS auth.uid();
DROP FUNCTION IF EXISTS auth.role();
DROP FUNCTION IF EXISTS auth.jwt();
DROP FUNCTION IF EXISTS auth.email();
DROP TYPE IF EXISTS storage.buckettype;
DROP TYPE IF EXISTS realtime.wal_rls;
DROP TYPE IF EXISTS realtime.wal_column;
DROP TYPE IF EXISTS realtime.user_defined_filter;
DROP TYPE IF EXISTS realtime.equality_op;
DROP TYPE IF EXISTS realtime.action;
DROP TYPE IF EXISTS public.pii_data_type;
DROP TYPE IF EXISTS auth.one_time_token_type;
DROP TYPE IF EXISTS auth.oauth_response_type;
DROP TYPE IF EXISTS auth.oauth_registration_type;
DROP TYPE IF EXISTS auth.oauth_client_type;
DROP TYPE IF EXISTS auth.oauth_authorization_status;
DROP TYPE IF EXISTS auth.factor_type;
DROP TYPE IF EXISTS auth.factor_status;
DROP TYPE IF EXISTS auth.code_challenge_method;
DROP TYPE IF EXISTS auth.aal_level;
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS supabase_vault;
DROP EXTENSION IF EXISTS pgcrypto;
DROP EXTENSION IF EXISTS pg_stat_statements;
DROP EXTENSION IF EXISTS pg_graphql;
DROP SCHEMA IF EXISTS vault;
DROP SCHEMA IF EXISTS supabase_migrations;
DROP SCHEMA IF EXISTS supabase_functions;
DROP SCHEMA IF EXISTS storage;
DROP SCHEMA IF EXISTS realtime;
DROP SCHEMA IF EXISTS pgbouncer;
DROP EXTENSION IF EXISTS pg_net;
DROP SCHEMA IF EXISTS graphql_public;
DROP SCHEMA IF EXISTS graphql;
DROP SCHEMA IF EXISTS extensions;
DROP SCHEMA IF EXISTS auth;
DROP SCHEMA IF EXISTS _realtime;
--
-- Name: _realtime; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA _realtime;


ALTER SCHEMA _realtime OWNER TO postgres;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pg_net; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_net; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_net IS 'Async HTTP';


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'Schema updated with comprehensive sample data for frontend component testing - Migration 20250904205911';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: supabase_functions; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA supabase_functions;


ALTER SCHEMA supabase_functions OWNER TO supabase_admin;

--
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA supabase_migrations;


ALTER SCHEMA supabase_migrations OWNER TO postgres;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE auth.oauth_authorization_status OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE auth.oauth_client_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


ALTER TYPE auth.oauth_response_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: pii_data_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.pii_data_type AS ENUM (
    'email',
    'phone',
    'name',
    'address',
    'ip_address',
    'username',
    'credit_card',
    'ssn',
    'custom'
);


ALTER TYPE public.pii_data_type OWNER TO postgres;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

    REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
    REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

    GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
begin
    raise debug 'PgBouncer auth request: %', p_usename;

    return query
    select 
        rolname::text, 
        case when rolvaliduntil < now() 
            then null 
            else rolpassword::text 
        end 
    from pg_authid 
    where rolname=$1 and rolcanlogin;
end;
$_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- Name: calculate_sanitization_score(boolean, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculate_sanitization_score(p_pii_detected boolean, p_sanitization_level character varying, p_redactions_applied integer, p_pseudonyms_used integer) RETURNS integer
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    score INTEGER := 0;
BEGIN
    -- Points for sanitization level
    score := CASE p_sanitization_level
        WHEN 'strict' THEN score + 40
        WHEN 'standard' THEN score + 30
        WHEN 'basic' THEN score + 20
        WHEN 'none' THEN score + 0
        ELSE score
    END;
    
    -- Points for PII handling
    IF p_pii_detected THEN
        IF p_pseudonyms_used > 0 THEN
            score := score + 25;
        END IF;
        IF p_redactions_applied > 0 THEN
            score := score + 25;
        END IF;
    ELSE
        -- No PII detected gets full score
        score := score + 50;
    END IF;
    
    -- Bonus for comprehensive sanitization
    IF p_redactions_applied > 0 AND p_pseudonyms_used > 0 THEN
        score := score + 10;
    END IF;
    
    RETURN LEAST(score, 100); -- Cap at 100
END;
$$;


ALTER FUNCTION public.calculate_sanitization_score(p_pii_detected boolean, p_sanitization_level character varying, p_redactions_applied integer, p_pseudonyms_used integer) OWNER TO postgres;

--
-- Name: create_deliverable_version(uuid, text, character varying, character varying, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_deliverable_version(deliverable_uuid uuid, version_content text, version_format character varying DEFAULT NULL::character varying, creation_type character varying DEFAULT 'ai_response'::character varying, version_task_id uuid DEFAULT NULL::uuid, version_metadata jsonb DEFAULT '{}'::jsonb) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    next_version_number INTEGER;
    new_version_id UUID;
BEGIN
    -- Get next version number
    SELECT COALESCE(MAX(version_number), 0) + 1
    INTO next_version_number
    FROM public.deliverable_versions
    WHERE deliverable_id = deliverable_uuid;
    
    -- Unset current version flag on existing versions
    UPDATE public.deliverable_versions 
    SET is_current_version = false
    WHERE deliverable_id = deliverable_uuid 
      AND is_current_version = true;
    
    -- Create new version
    INSERT INTO public.deliverable_versions (
        deliverable_id,
        version_number,
        content,
        format,
        created_by_type,
        task_id,
        metadata,
        is_current_version
    ) VALUES (
        deliverable_uuid,
        next_version_number,
        version_content,
        version_format,
        creation_type,
        version_task_id,
        version_metadata,
        true
    ) RETURNING id INTO new_version_id;
    
    RETURN new_version_id;
END;
$$;


ALTER FUNCTION public.create_deliverable_version(deliverable_uuid uuid, version_content text, version_format character varying, creation_type character varying, version_task_id uuid, version_metadata jsonb) OWNER TO postgres;

--
-- Name: FUNCTION create_deliverable_version(deliverable_uuid uuid, version_content text, version_format character varying, creation_type character varying, version_task_id uuid, version_metadata jsonb); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.create_deliverable_version(deliverable_uuid uuid, version_content text, version_format character varying, creation_type character varying, version_task_id uuid, version_metadata jsonb) IS 'Helper function to create new deliverable version with proper version numbering and current flag management. Allowed creation_type values: ai_response, manual_edit, ai_enhancement, user_request, conversation_task, conversation_merge';


--
-- Name: exec_sql(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.exec_sql(query text) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    result json;
BEGIN
    -- Execute the dynamic SQL and return results as JSON
    EXECUTE 'SELECT json_agg(row_to_json(t)) FROM (' || query || ') t' INTO result;
    
    -- If no rows returned, return empty array instead of null
    IF result IS NULL THEN
        result := '[]'::json;
    END IF;
    
    RETURN result;
EXCEPTION
    WHEN OTHERS THEN
        -- Return error information as JSON
        RETURN json_build_object(
            'error', true,
            'message', SQLERRM,
            'code', SQLSTATE,
            'query', query
        );
END;
$$;


ALTER FUNCTION public.exec_sql(query text) OWNER TO postgres;

--
-- Name: FUNCTION exec_sql(query text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.exec_sql(query text) IS 'Execute arbitrary SQL queries and return results as JSON array. Used by MCP server for dynamic query execution.';


--
-- Name: get_compliance_status(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_compliance_status(p_llm_usage_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    usage_record RECORD;
    compliance_status JSONB := '{}'::jsonb;
BEGIN
    SELECT * FROM public.llm_usage WHERE id = p_llm_usage_id INTO usage_record;
    
    IF NOT FOUND THEN
        RETURN '{"error": "Usage record not found"}'::jsonb;
    END IF;
    
    -- GDPR compliance (requires data sanitization for PII)
    compliance_status := compliance_status || jsonb_build_object(
        'gdpr_compliant',
        CASE 
            WHEN usage_record.pii_detected = false THEN true
            WHEN usage_record.pii_detected = true AND usage_record.data_sanitization_applied = true THEN true
            ELSE false
        END
    );
    
    -- HIPAA compliance (requires strict sanitization)
    compliance_status := compliance_status || jsonb_build_object(
        'hipaa_compliant',
        CASE 
            WHEN usage_record.sanitization_level = 'strict' THEN true
            ELSE false
        END
    );
    
    -- PCI compliance (requires redaction of payment data)
    compliance_status := compliance_status || jsonb_build_object(
        'pci_compliant',
        CASE 
            WHEN usage_record.redaction_types ? 'credit_card' OR usage_record.redaction_types ? 'payment_info' THEN true
            WHEN NOT (usage_record.pii_types ? 'credit_card') THEN true
            ELSE false
        END
    );
    
    -- Overall sanitization score
    compliance_status := compliance_status || jsonb_build_object(
        'sanitization_score',
        public.calculate_sanitization_score(
            usage_record.pii_detected,
            usage_record.sanitization_level,
            usage_record.redactions_applied,
            usage_record.pseudonyms_used
        )
    );
    
    RETURN compliance_status;
END;
$$;


ALTER FUNCTION public.get_compliance_status(p_llm_usage_id uuid) OWNER TO postgres;

--
-- Name: get_current_deliverable_version(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_current_deliverable_version(deliverable_uuid uuid) RETURNS TABLE(id uuid, version_number integer, content text, format character varying, created_by_type character varying, metadata jsonb, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        dv.id,
        dv.version_number,
        dv.content,
        dv.format,
        dv.created_by_type,
        dv.metadata,
        dv.created_at
    FROM public.deliverable_versions dv
    WHERE dv.deliverable_id = deliverable_uuid
      AND dv.is_current_version = true;
END;
$$;


ALTER FUNCTION public.get_current_deliverable_version(deliverable_uuid uuid) OWNER TO postgres;

--
-- Name: increment_usage_counter(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.increment_usage_counter() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Update usage count and last used timestamp
    NEW.usage_count = COALESCE(OLD.usage_count, 0) + 1;
    NEW.last_used_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.increment_usage_counter() OWNER TO postgres;

--
-- Name: update_llm_usage_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_llm_usage_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_llm_usage_updated_at() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


ALTER FUNCTION storage.add_prefixes(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: delete_leaf_prefixes(text[], text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_leaf_prefixes(bucket_ids text[], names text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_rows_deleted integer;
BEGIN
    LOOP
        WITH candidates AS (
            SELECT DISTINCT
                t.bucket_id,
                unnest(storage.get_prefixes(t.name)) AS name
            FROM unnest(bucket_ids, names) AS t(bucket_id, name)
        ),
        uniq AS (
             SELECT
                 bucket_id,
                 name,
                 storage.get_level(name) AS level
             FROM candidates
             WHERE name <> ''
             GROUP BY bucket_id, name
        ),
        leaf AS (
             SELECT
                 p.bucket_id,
                 p.name,
                 p.level
             FROM storage.prefixes AS p
                  JOIN uniq AS u
                       ON u.bucket_id = p.bucket_id
                           AND u.name = p.name
                           AND u.level = p.level
             WHERE NOT EXISTS (
                 SELECT 1
                 FROM storage.objects AS o
                 WHERE o.bucket_id = p.bucket_id
                   AND o.level = p.level + 1
                   AND o.name COLLATE "C" LIKE p.name || '/%'
             )
             AND NOT EXISTS (
                 SELECT 1
                 FROM storage.prefixes AS c
                 WHERE c.bucket_id = p.bucket_id
                   AND c.level = p.level + 1
                   AND c.name COLLATE "C" LIKE p.name || '/%'
             )
        )
        DELETE
        FROM storage.prefixes AS p
            USING leaf AS l
        WHERE p.bucket_id = l.bucket_id
          AND p.name = l.name
          AND p.level = l.level;

        GET DIAGNOSTICS v_rows_deleted = ROW_COUNT;
        EXIT WHEN v_rows_deleted = 0;
    END LOOP;
END;
$$;


ALTER FUNCTION storage.delete_leaf_prefixes(bucket_ids text[], names text[]) OWNER TO supabase_storage_admin;

--
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


ALTER FUNCTION storage.delete_prefix(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


ALTER FUNCTION storage.delete_prefix_hierarchy_trigger() OWNER TO supabase_storage_admin;

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


ALTER FUNCTION storage.get_level(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


ALTER FUNCTION storage.get_prefix(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


ALTER FUNCTION storage.get_prefixes(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) OWNER TO supabase_storage_admin;

--
-- Name: lock_top_prefixes(text[], text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.lock_top_prefixes(bucket_ids text[], names text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket text;
    v_top text;
BEGIN
    FOR v_bucket, v_top IN
        SELECT DISTINCT t.bucket_id,
            split_part(t.name, '/', 1) AS top
        FROM unnest(bucket_ids, names) AS t(bucket_id, name)
        WHERE t.name <> ''
        ORDER BY 1, 2
        LOOP
            PERFORM pg_advisory_xact_lock(hashtextextended(v_bucket || '/' || v_top, 0));
        END LOOP;
END;
$$;


ALTER FUNCTION storage.lock_top_prefixes(bucket_ids text[], names text[]) OWNER TO supabase_storage_admin;

--
-- Name: objects_delete_cleanup(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_delete_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket_ids text[];
    v_names      text[];
BEGIN
    IF current_setting('storage.gc.prefixes', true) = '1' THEN
        RETURN NULL;
    END IF;

    PERFORM set_config('storage.gc.prefixes', '1', true);

    SELECT COALESCE(array_agg(d.bucket_id), '{}'),
           COALESCE(array_agg(d.name), '{}')
    INTO v_bucket_ids, v_names
    FROM deleted AS d
    WHERE d.name <> '';

    PERFORM storage.lock_top_prefixes(v_bucket_ids, v_names);
    PERFORM storage.delete_leaf_prefixes(v_bucket_ids, v_names);

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.objects_delete_cleanup() OWNER TO supabase_storage_admin;

--
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_insert_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- Name: objects_update_cleanup(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    -- NEW - OLD (destinations to create prefixes for)
    v_add_bucket_ids text[];
    v_add_names      text[];

    -- OLD - NEW (sources to prune)
    v_src_bucket_ids text[];
    v_src_names      text[];
BEGIN
    IF TG_OP <> 'UPDATE' THEN
        RETURN NULL;
    END IF;

    -- 1) Compute NEW−OLD (added paths) and OLD−NEW (moved-away paths)
    WITH added AS (
        SELECT n.bucket_id, n.name
        FROM new_rows n
        WHERE n.name <> '' AND position('/' in n.name) > 0
        EXCEPT
        SELECT o.bucket_id, o.name FROM old_rows o WHERE o.name <> ''
    ),
    moved AS (
         SELECT o.bucket_id, o.name
         FROM old_rows o
         WHERE o.name <> ''
         EXCEPT
         SELECT n.bucket_id, n.name FROM new_rows n WHERE n.name <> ''
    )
    SELECT
        -- arrays for ADDED (dest) in stable order
        COALESCE( (SELECT array_agg(a.bucket_id ORDER BY a.bucket_id, a.name) FROM added a), '{}' ),
        COALESCE( (SELECT array_agg(a.name      ORDER BY a.bucket_id, a.name) FROM added a), '{}' ),
        -- arrays for MOVED (src) in stable order
        COALESCE( (SELECT array_agg(m.bucket_id ORDER BY m.bucket_id, m.name) FROM moved m), '{}' ),
        COALESCE( (SELECT array_agg(m.name      ORDER BY m.bucket_id, m.name) FROM moved m), '{}' )
    INTO v_add_bucket_ids, v_add_names, v_src_bucket_ids, v_src_names;

    -- Nothing to do?
    IF (array_length(v_add_bucket_ids, 1) IS NULL) AND (array_length(v_src_bucket_ids, 1) IS NULL) THEN
        RETURN NULL;
    END IF;

    -- 2) Take per-(bucket, top) locks: ALL prefixes in consistent global order to prevent deadlocks
    DECLARE
        v_all_bucket_ids text[];
        v_all_names text[];
    BEGIN
        -- Combine source and destination arrays for consistent lock ordering
        v_all_bucket_ids := COALESCE(v_src_bucket_ids, '{}') || COALESCE(v_add_bucket_ids, '{}');
        v_all_names := COALESCE(v_src_names, '{}') || COALESCE(v_add_names, '{}');

        -- Single lock call ensures consistent global ordering across all transactions
        IF array_length(v_all_bucket_ids, 1) IS NOT NULL THEN
            PERFORM storage.lock_top_prefixes(v_all_bucket_ids, v_all_names);
        END IF;
    END;

    -- 3) Create destination prefixes (NEW−OLD) BEFORE pruning sources
    IF array_length(v_add_bucket_ids, 1) IS NOT NULL THEN
        WITH candidates AS (
            SELECT DISTINCT t.bucket_id, unnest(storage.get_prefixes(t.name)) AS name
            FROM unnest(v_add_bucket_ids, v_add_names) AS t(bucket_id, name)
            WHERE name <> ''
        )
        INSERT INTO storage.prefixes (bucket_id, name)
        SELECT c.bucket_id, c.name
        FROM candidates c
        ON CONFLICT DO NOTHING;
    END IF;

    -- 4) Prune source prefixes bottom-up for OLD−NEW
    IF array_length(v_src_bucket_ids, 1) IS NOT NULL THEN
        -- re-entrancy guard so DELETE on prefixes won't recurse
        IF current_setting('storage.gc.prefixes', true) <> '1' THEN
            PERFORM set_config('storage.gc.prefixes', '1', true);
        END IF;

        PERFORM storage.delete_leaf_prefixes(v_src_bucket_ids, v_src_names);
    END IF;

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.objects_update_cleanup() OWNER TO supabase_storage_admin;

--
-- Name: objects_update_level_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_level_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Set the new level
        NEW."level" := "storage"."get_level"(NEW."name");
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_level_trigger() OWNER TO supabase_storage_admin;

--
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: prefixes_delete_cleanup(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.prefixes_delete_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket_ids text[];
    v_names      text[];
BEGIN
    IF current_setting('storage.gc.prefixes', true) = '1' THEN
        RETURN NULL;
    END IF;

    PERFORM set_config('storage.gc.prefixes', '1', true);

    SELECT COALESCE(array_agg(d.bucket_id), '{}'),
           COALESCE(array_agg(d.name), '{}')
    INTO v_bucket_ids, v_names
    FROM deleted AS d
    WHERE d.name <> '';

    PERFORM storage.lock_top_prefixes(v_bucket_ids, v_names);
    PERFORM storage.delete_leaf_prefixes(v_bucket_ids, v_names);

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.prefixes_delete_cleanup() OWNER TO supabase_storage_admin;

--
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.prefixes_insert_trigger() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    sort_col text;
    sort_ord text;
    cursor_op text;
    cursor_expr text;
    sort_expr text;
BEGIN
    -- Validate sort_order
    sort_ord := lower(sort_order);
    IF sort_ord NOT IN ('asc', 'desc') THEN
        sort_ord := 'asc';
    END IF;

    -- Determine cursor comparison operator
    IF sort_ord = 'asc' THEN
        cursor_op := '>';
    ELSE
        cursor_op := '<';
    END IF;
    
    sort_col := lower(sort_column);
    -- Validate sort column  
    IF sort_col IN ('updated_at', 'created_at') THEN
        cursor_expr := format(
            '($5 = '''' OR ROW(date_trunc(''milliseconds'', %I), name COLLATE "C") %s ROW(COALESCE(NULLIF($6, '''')::timestamptz, ''epoch''::timestamptz), $5))',
            sort_col, cursor_op
        );
        sort_expr := format(
            'COALESCE(date_trunc(''milliseconds'', %I), ''epoch''::timestamptz) %s, name COLLATE "C" %s',
            sort_col, sort_ord, sort_ord
        );
    ELSE
        cursor_expr := format('($5 = '''' OR name COLLATE "C" %s $5)', cursor_op);
        sort_expr := format('name COLLATE "C" %s', sort_ord);
    END IF;

    RETURN QUERY EXECUTE format(
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name,
                    NULL::uuid AS id,
                    updated_at,
                    created_at,
                    NULL::timestamptz AS last_accessed_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%%'
                    AND bucket_id = $2
                    AND level = $4
                    AND %s
                ORDER BY %s
                LIMIT $3
            )
            UNION ALL
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name,
                    id,
                    updated_at,
                    created_at,
                    last_accessed_at,
                    metadata
                FROM storage.objects
                WHERE name COLLATE "C" LIKE $1 || '%%'
                    AND bucket_id = $2
                    AND level = $4
                    AND %s
                ORDER BY %s
                LIMIT $3
            )
        ) obj
        ORDER BY %s
        LIMIT $3
        $sql$,
        cursor_expr,    -- prefixes WHERE
        sort_expr,      -- prefixes ORDER BY
        cursor_expr,    -- objects WHERE
        sort_expr,      -- objects ORDER BY
        sort_expr       -- final ORDER BY
    )
    USING prefix, bucket_name, limits, levels, start_after, sort_column_after;
END;
$_$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

--
-- Name: http_request(); Type: FUNCTION; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE FUNCTION supabase_functions.http_request() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'supabase_functions'
    AS $$
  DECLARE
    request_id bigint;
    payload jsonb;
    url text := TG_ARGV[0]::text;
    method text := TG_ARGV[1]::text;
    headers jsonb DEFAULT '{}'::jsonb;
    params jsonb DEFAULT '{}'::jsonb;
    timeout_ms integer DEFAULT 1000;
  BEGIN
    IF url IS NULL OR url = 'null' THEN
      RAISE EXCEPTION 'url argument is missing';
    END IF;

    IF method IS NULL OR method = 'null' THEN
      RAISE EXCEPTION 'method argument is missing';
    END IF;

    IF TG_ARGV[2] IS NULL OR TG_ARGV[2] = 'null' THEN
      headers = '{"Content-Type": "application/json"}'::jsonb;
    ELSE
      headers = TG_ARGV[2]::jsonb;
    END IF;

    IF TG_ARGV[3] IS NULL OR TG_ARGV[3] = 'null' THEN
      params = '{}'::jsonb;
    ELSE
      params = TG_ARGV[3]::jsonb;
    END IF;

    IF TG_ARGV[4] IS NULL OR TG_ARGV[4] = 'null' THEN
      timeout_ms = 1000;
    ELSE
      timeout_ms = TG_ARGV[4]::integer;
    END IF;

    CASE
      WHEN method = 'GET' THEN
        SELECT http_get INTO request_id FROM net.http_get(
          url,
          params,
          headers,
          timeout_ms
        );
      WHEN method = 'POST' THEN
        payload = jsonb_build_object(
          'old_record', OLD,
          'record', NEW,
          'type', TG_OP,
          'table', TG_TABLE_NAME,
          'schema', TG_TABLE_SCHEMA
        );

        SELECT http_post INTO request_id FROM net.http_post(
          url,
          payload,
          params,
          headers,
          timeout_ms
        );
      ELSE
        RAISE EXCEPTION 'method argument % is invalid', method;
    END CASE;

    INSERT INTO supabase_functions.hooks
      (hook_table_id, hook_name, request_id)
    VALUES
      (TG_RELID, TG_NAME, request_id);

    RETURN NEW;
  END
$$;


ALTER FUNCTION supabase_functions.http_request() OWNER TO supabase_functions_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: extensions; Type: TABLE; Schema: _realtime; Owner: supabase_admin
--

CREATE TABLE _realtime.extensions (
    id uuid NOT NULL,
    type text,
    settings jsonb,
    tenant_external_id text,
    inserted_at timestamp(0) without time zone NOT NULL,
    updated_at timestamp(0) without time zone NOT NULL
);


ALTER TABLE _realtime.extensions OWNER TO supabase_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: _realtime; Owner: supabase_admin
--

CREATE TABLE _realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE _realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: tenants; Type: TABLE; Schema: _realtime; Owner: supabase_admin
--

CREATE TABLE _realtime.tenants (
    id uuid NOT NULL,
    name text,
    external_id text,
    jwt_secret text,
    max_concurrent_users integer DEFAULT 200 NOT NULL,
    inserted_at timestamp(0) without time zone NOT NULL,
    updated_at timestamp(0) without time zone NOT NULL,
    max_events_per_second integer DEFAULT 100 NOT NULL,
    postgres_cdc_default text DEFAULT 'postgres_cdc_rls'::text,
    max_bytes_per_second integer DEFAULT 100000 NOT NULL,
    max_channels_per_client integer DEFAULT 100 NOT NULL,
    max_joins_per_second integer DEFAULT 500 NOT NULL,
    suspend boolean DEFAULT false,
    jwt_jwks jsonb,
    notify_private_alpha boolean DEFAULT false,
    private_only boolean DEFAULT false NOT NULL,
    migrations_ran integer DEFAULT 0,
    broadcast_adapter character varying(255) DEFAULT 'gen_rpc'::character varying,
    max_presence_events_per_second integer DEFAULT 10000,
    max_payload_size_in_kb integer DEFAULT 3000
);


ALTER TABLE _realtime.tenants OWNER TO supabase_admin;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


ALTER TABLE auth.oauth_authorizations OWNER TO supabase_auth_admin;

--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


ALTER TABLE auth.oauth_consents OWNER TO supabase_auth_admin;

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: agent_conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_conversations (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    agent_name character varying(255),
    agent_type character varying(100),
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    last_active_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    primary_work_product_id uuid,
    primary_work_product_type character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agent_conversations OWNER TO postgres;

--
-- Name: TABLE agent_conversations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.agent_conversations IS 'Agent conversations table - cleaned for new deliverables versioning system';


--
-- Name: cidafm_commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cidafm_commands (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(10) NOT NULL,
    description text,
    default_active boolean DEFAULT false,
    is_builtin boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cidafm_commands OWNER TO postgres;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    industry character varying(100),
    founded_year integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: TABLE companies; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.companies IS 'Moved from company schema - contains company information for KPI tracking';


--
-- Name: deliverable_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliverable_versions (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    deliverable_id uuid NOT NULL,
    version_number integer NOT NULL,
    content text,
    format character varying(100),
    is_current_version boolean DEFAULT false,
    created_by_type character varying(50) DEFAULT 'ai_response'::character varying,
    task_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    file_attachments jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT deliverable_versions_created_by_type_check CHECK (((created_by_type)::text = ANY (ARRAY[('ai_response'::character varying)::text, ('manual_edit'::character varying)::text, ('ai_enhancement'::character varying)::text, ('user_request'::character varying)::text, ('conversation_task'::character varying)::text, ('conversation_merge'::character varying)::text])))
);


ALTER TABLE public.deliverable_versions OWNER TO postgres;

--
-- Name: TABLE deliverable_versions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.deliverable_versions IS 'Version data for deliverables - each deliverable can have multiple versions';


--
-- Name: COLUMN deliverable_versions.is_current_version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.deliverable_versions.is_current_version IS 'Only one version per deliverable can be current (enforced by unique constraint)';


--
-- Name: COLUMN deliverable_versions.created_by_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.deliverable_versions.created_by_type IS 'How this version was created: ai_response, manual_edit, ai_enhancement, user_request';


--
-- Name: deliverables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliverables (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    conversation_id uuid,
    title character varying(255) NOT NULL,
    deliverable_type character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    project_step_id uuid,
    agent_name character varying(255),
    task_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.deliverables OWNER TO postgres;

--
-- Name: TABLE deliverables; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.deliverables IS 'Deliverables table - prepared for new versioning system where each conversation has one deliverable with multiple versions';


--
-- Name: COLUMN deliverables.agent_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.deliverables.agent_name IS 'Agent that should handle editing this deliverable (inherited from creating conversation)';


--
-- Name: COLUMN deliverables.task_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.deliverables.task_id IS 'References the task that created this deliverable, used for task-based evaluation';


--
-- Name: departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departments (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    company_id uuid,
    name character varying(255) NOT NULL,
    head_of_department character varying(255),
    budget numeric(15,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.departments OWNER TO postgres;

--
-- Name: TABLE departments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.departments IS 'Moved from company schema - contains department information';


--
-- Name: human_inputs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.human_inputs (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    task_id uuid NOT NULL,
    user_id uuid NOT NULL,
    request_type text NOT NULL,
    prompt text NOT NULL,
    options jsonb,
    user_response text,
    response_metadata jsonb DEFAULT '{}'::jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT human_inputs_request_type_check CHECK ((request_type = ANY (ARRAY['confirmation'::text, 'choice'::text, 'input'::text, 'approval'::text]))),
    CONSTRAINT human_inputs_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'completed'::text, 'timeout'::text, 'cancelled'::text])))
);


ALTER TABLE public.human_inputs OWNER TO postgres;

--
-- Name: kpi_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kpi_data (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    department_id uuid,
    metric_id uuid,
    value numeric(15,4) NOT NULL,
    date_recorded date NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.kpi_data OWNER TO postgres;

--
-- Name: TABLE kpi_data; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.kpi_data IS 'Moved from company schema - contains actual KPI data points';


--
-- Name: kpi_goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kpi_goals (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    department_id uuid,
    metric_id uuid,
    target_value numeric(15,4),
    period_start date,
    period_end date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.kpi_goals OWNER TO postgres;

--
-- Name: TABLE kpi_goals; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.kpi_goals IS 'Moved from company schema - contains KPI targets and goals';


--
-- Name: kpi_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kpi_metrics (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    metric_type character varying(100),
    unit character varying(50),
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.kpi_metrics OWNER TO postgres;

--
-- Name: TABLE kpi_metrics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.kpi_metrics IS 'Moved from company schema - contains KPI metric definitions';


--
-- Name: langgraph_states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.langgraph_states (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    project_id uuid,
    plan_state jsonb,
    step_results jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    state_version integer DEFAULT 1,
    last_synchronized timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.langgraph_states OWNER TO postgres;

--
-- Name: llm_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_models (
    model_name text NOT NULL,
    provider_name text NOT NULL,
    display_name text,
    model_type text DEFAULT 'text-generation'::text,
    model_version text,
    context_window integer DEFAULT 4096,
    max_output_tokens integer DEFAULT 2048,
    model_parameters_json jsonb DEFAULT '{}'::jsonb,
    pricing_info_json jsonb DEFAULT '{}'::jsonb,
    capabilities jsonb DEFAULT '[]'::jsonb,
    is_local boolean DEFAULT false,
    is_currently_loaded boolean DEFAULT false,
    model_tier text,
    speed_tier text DEFAULT 'medium'::text,
    loading_priority integer DEFAULT 5,
    is_active boolean DEFAULT true,
    training_data_cutoff date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_models OWNER TO postgres;

--
-- Name: TABLE llm_models; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.llm_models IS 'LLM models - removed o1-preview and gemini-2.0-pro for demo stability (2025-01-09)';


--
-- Name: COLUMN llm_models.speed_tier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.llm_models.speed_tier IS 'Performance tier: ultra-fast (< 1s), fast (1-3s), medium (3-10s), slow (10s+)';


--
-- Name: llm_models_backup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_models_backup (
    id uuid,
    provider_id uuid,
    model_name character varying(255),
    display_name character varying(255),
    model_type character varying(100),
    context_window integer,
    max_output_tokens integer,
    model_parameters_json jsonb,
    pricing_info_json jsonb,
    capabilities jsonb,
    is_active boolean,
    model_version character varying(100),
    training_data_cutoff date,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_local boolean,
    is_currently_loaded boolean,
    model_tier character varying(50),
    loading_priority integer,
    capabilities_json jsonb,
    complexity_level text,
    thinking_mode boolean,
    speed_tier text,
    resource_requirements jsonb
);


ALTER TABLE public.llm_models_backup OWNER TO postgres;

--
-- Name: llm_providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_providers (
    name text NOT NULL,
    display_name text NOT NULL,
    api_base_url text,
    configuration_json jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_providers OWNER TO postgres;

--
-- Name: TABLE llm_providers; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.llm_providers IS 'LLM providers using name-based system (no UUIDs) - 2025 refresh';


--
-- Name: llm_providers_backup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_providers_backup (
    id uuid,
    name character varying(255),
    display_name character varying(255),
    api_base_url character varying(500),
    api_key_encrypted text,
    configuration_json jsonb,
    is_active boolean,
    rate_limit_rpm integer,
    rate_limit_tpm integer,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.llm_providers_backup OWNER TO postgres;

--
-- Name: llm_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    model text NOT NULL,
    user_id uuid,
    session_id text,
    request_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    response_timestamp timestamp with time zone,
    input_tokens integer DEFAULT 0,
    output_tokens integer DEFAULT 0,
    total_tokens integer GENERATED ALWAYS AS ((input_tokens + output_tokens)) STORED,
    estimated_cost numeric(10,6) DEFAULT 0,
    request_metadata jsonb DEFAULT '{}'::jsonb,
    response_metadata jsonb DEFAULT '{}'::jsonb,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_usage OWNER TO postgres;

--
-- Name: TABLE llm_usage; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.llm_usage IS 'LLM usage tracking using name-based provider/model references - 2025 refresh';


--
-- Name: llm_usage_backup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_usage_backup (
    id uuid,
    run_id character varying(255),
    user_id uuid,
    caller_type character varying(100),
    caller_name character varying(255),
    conversation_id uuid,
    provider_id uuid,
    model_id uuid,
    provider_name character varying(255),
    model_name character varying(255),
    is_local boolean,
    model_tier character varying(50),
    fallback_used boolean,
    routing_reason text,
    input_tokens integer,
    output_tokens integer,
    total_tokens integer,
    input_cost numeric(10,6),
    output_cost numeric(10,6),
    total_cost numeric(10,6),
    duration_ms integer,
    response_time_ms integer,
    status character varying(50),
    error_message text,
    complexity_level character varying(20),
    complexity_score integer,
    data_classification character varying(50),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    data_sanitization_applied boolean,
    sanitization_level character varying(20),
    pii_detected boolean,
    pii_types jsonb,
    pseudonyms_used integer,
    pseudonym_types jsonb,
    redactions_applied integer,
    redaction_types jsonb,
    source_blinding_applied boolean,
    headers_stripped integer,
    custom_user_agent_used boolean,
    proxy_used boolean,
    no_train_header_sent boolean,
    no_retain_header_sent boolean,
    sanitization_time_ms integer,
    reversal_context_size integer,
    policy_profile character varying(100),
    sovereign_mode boolean,
    compliance_flags jsonb,
    langsmith_run_id uuid,
    metadata jsonb
);


ALTER TABLE public.llm_usage_backup OWNER TO postgres;

--
-- Name: project_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_steps (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    project_id uuid NOT NULL,
    step_id text NOT NULL,
    step_index integer NOT NULL,
    step_type text NOT NULL,
    step_name text NOT NULL,
    agent_name text,
    prompt text,
    dependencies text[] DEFAULT '{}'::text[],
    status text DEFAULT 'pending'::text NOT NULL,
    result jsonb,
    error_details jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT project_steps_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'completed'::text, 'failed'::text, 'skipped'::text]))),
    CONSTRAINT project_steps_step_type_check CHECK ((step_type = ANY (ARRAY['agent_step'::text, 'human_approval'::text])))
);


ALTER TABLE public.project_steps OWNER TO postgres;

--
-- Name: TABLE project_steps; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.project_steps IS 'Individual steps within multi-step projects, enabling complex orchestration workflows with agent execution and human approval points';


--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    conversation_id uuid,
    name character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'planning'::character varying,
    plan_json jsonb,
    current_step_id text,
    parent_project_id uuid,
    hierarchy_level integer DEFAULT 0,
    subproject_count integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: pseudonym_dictionaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pseudonym_dictionaries (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    data_type public.pii_data_type NOT NULL,
    category character varying(100),
    value character varying(500) NOT NULL,
    locale character varying(10) DEFAULT 'en-US'::character varying,
    frequency_weight integer DEFAULT 1,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pseudonym_dictionaries OWNER TO postgres;

--
-- Name: TABLE pseudonym_dictionaries; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.pseudonym_dictionaries IS 'Dictionary data for generating realistic pseudonyms';


--
-- Name: pseudonym_mappings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pseudonym_mappings (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    original_hash character varying(64) NOT NULL,
    pseudonym character varying(500) NOT NULL,
    data_type public.pii_data_type NOT NULL,
    context character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_used_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    usage_count integer DEFAULT 1,
    expires_at timestamp with time zone,
    is_reversible boolean DEFAULT false,
    created_by_system character varying(100) DEFAULT 'secret_redaction_service'::character varying
);


ALTER TABLE public.pseudonym_mappings OWNER TO postgres;

--
-- Name: TABLE pseudonym_mappings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.pseudonym_mappings IS 'Mapping table from original PII hashes to consistent pseudonyms';


--
-- Name: COLUMN pseudonym_mappings.original_hash; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pseudonym_mappings.original_hash IS 'SHA-256 hash of original PII value for consistent lookup';


--
-- Name: COLUMN pseudonym_mappings.is_reversible; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pseudonym_mappings.is_reversible IS 'Whether original value is stored in vault for authorized reversal';


--
-- Name: redaction_audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.redaction_audit_log (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    session_id character varying(255),
    run_id uuid,
    operation_type character varying(50) NOT NULL,
    data_type public.pii_data_type,
    pattern_name character varying(255),
    original_length integer,
    redacted_length integer,
    pseudonym_count integer DEFAULT 0,
    redaction_count integer DEFAULT 0,
    processing_time_ms integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_id uuid,
    service_name character varying(100) DEFAULT 'secret_redaction_service'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.redaction_audit_log OWNER TO postgres;

--
-- Name: TABLE redaction_audit_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.redaction_audit_log IS 'Audit trail for all redaction and pseudonymization operations';


--
-- Name: redaction_patterns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.redaction_patterns (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    pattern_regex text NOT NULL,
    replacement character varying(500) NOT NULL,
    description text,
    category character varying(100) DEFAULT 'custom'::character varying,
    is_active boolean DEFAULT true,
    priority integer DEFAULT 100,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    usage_count integer DEFAULT 0,
    last_used_at timestamp with time zone
);


ALTER TABLE public.redaction_patterns OWNER TO postgres;

--
-- Name: TABLE redaction_patterns; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.redaction_patterns IS 'Custom redaction patterns extending built-in SecretRedactionService patterns';


--
-- Name: role_audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_audit_log (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    admin_user_id uuid,
    action character varying(50),
    old_roles text,
    new_roles text,
    reason text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.role_audit_log OWNER TO postgres;

--
-- Name: sensitive_data_vault; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sensitive_data_vault (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    pseudonym_mapping_id uuid,
    encrypted_original text,
    encryption_key_id character varying(100),
    access_level character varying(50) DEFAULT 'admin_only'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    accessed_at timestamp with time zone,
    access_count integer DEFAULT 0,
    retention_until timestamp with time zone
);


ALTER TABLE public.sensitive_data_vault OWNER TO postgres;

--
-- Name: TABLE sensitive_data_vault; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.sensitive_data_vault IS 'Encrypted storage for reversible pseudonyms (admin access only)';


--
-- Name: COLUMN sensitive_data_vault.encrypted_original; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sensitive_data_vault.encrypted_original IS 'AES encrypted original PII value';


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    agent_conversation_id uuid,
    method character varying(255),
    params jsonb,
    prompt text,
    response text,
    status character varying(50) DEFAULT 'pending'::character varying,
    progress integer DEFAULT 0,
    progress_message text,
    error_code character varying(100),
    error_message text,
    error_data jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    timeout_seconds integer,
    deliverable_type character varying(100),
    deliverable_metadata jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    llm_metadata jsonb,
    response_metadata jsonb,
    evaluation jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: user_cidafm_commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_cidafm_commands (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid,
    command_id uuid,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_cidafm_commands OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    display_name character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    phone character varying(50),
    phone_verified boolean DEFAULT false,
    company character varying(255),
    role character varying(50),
    department character varying(255),
    location character varying(255),
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    locale character varying(10) DEFAULT 'en-US'::character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    roles jsonb DEFAULT '["user"]'::jsonb
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: messages_2025_11_04; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_11_04 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_11_04 OWNER TO supabase_admin;

--
-- Name: messages_2025_11_05; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_11_05 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_11_05 OWNER TO supabase_admin;

--
-- Name: messages_2025_11_06; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_11_06 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_11_06 OWNER TO supabase_admin;

--
-- Name: messages_2025_11_07; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_11_07 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_11_07 OWNER TO supabase_admin;

--
-- Name: messages_2025_11_08; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2025_11_08 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2025_11_08 OWNER TO supabase_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- Name: iceberg_namespaces; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.iceberg_namespaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.iceberg_namespaces OWNER TO supabase_storage_admin;

--
-- Name: iceberg_tables; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.iceberg_tables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    namespace_id uuid NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    location text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.iceberg_tables OWNER TO supabase_storage_admin;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE storage.prefixes OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: hooks; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.hooks (
    id bigint NOT NULL,
    hook_table_id integer NOT NULL,
    hook_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id bigint
);


ALTER TABLE supabase_functions.hooks OWNER TO supabase_functions_admin;

--
-- Name: TABLE hooks; Type: COMMENT; Schema: supabase_functions; Owner: supabase_functions_admin
--

COMMENT ON TABLE supabase_functions.hooks IS 'Supabase Functions Hooks: Audit trail for triggered hooks.';


--
-- Name: hooks_id_seq; Type: SEQUENCE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE SEQUENCE supabase_functions.hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE supabase_functions.hooks_id_seq OWNER TO supabase_functions_admin;

--
-- Name: hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER SEQUENCE supabase_functions.hooks_id_seq OWNED BY supabase_functions.hooks.id;


--
-- Name: migrations; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.migrations (
    version text NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE supabase_functions.migrations OWNER TO supabase_functions_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text
);


ALTER TABLE supabase_migrations.schema_migrations OWNER TO postgres;

--
-- Name: messages_2025_11_04; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_11_04 FOR VALUES FROM ('2025-11-04 00:00:00') TO ('2025-11-05 00:00:00');


--
-- Name: messages_2025_11_05; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_11_05 FOR VALUES FROM ('2025-11-05 00:00:00') TO ('2025-11-06 00:00:00');


--
-- Name: messages_2025_11_06; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_11_06 FOR VALUES FROM ('2025-11-06 00:00:00') TO ('2025-11-07 00:00:00');


--
-- Name: messages_2025_11_07; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_11_07 FOR VALUES FROM ('2025-11-07 00:00:00') TO ('2025-11-08 00:00:00');


--
-- Name: messages_2025_11_08; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_11_08 FOR VALUES FROM ('2025-11-08 00:00:00') TO ('2025-11-09 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Name: hooks id; Type: DEFAULT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks ALTER COLUMN id SET DEFAULT nextval('supabase_functions.hooks_id_seq'::regclass);


--
-- Data for Name: extensions; Type: TABLE DATA; Schema: _realtime; Owner: supabase_admin
--

COPY _realtime.extensions (id, type, settings, tenant_external_id, inserted_at, updated_at) FROM stdin;
30a5defd-7d43-4355-b4c4-890de03a9150	postgres_cdc_rls	{"region": "us-east-1", "db_host": "g5vGA6WI5nO6YSCPG5m20+iaI0frq7j/Fuye84/o6DI=", "db_name": "sWBpZNdjggEPTQVlI52Zfw==", "db_port": "+enMDFi1J/3IrrquHHwUmA==", "db_user": "uxbEq/zz8DXVD53TOI1zmw==", "slot_name": "supabase_realtime_replication_slot", "db_password": "sWBpZNdjggEPTQVlI52Zfw==", "publication": "supabase_realtime", "ssl_enforced": false, "poll_interval_ms": 100, "poll_max_changes": 100, "poll_max_record_bytes": 1048576}	realtime-dev	2025-11-05 12:57:37	2025-11-05 12:57:37
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: _realtime; Owner: supabase_admin
--

COPY _realtime.schema_migrations (version, inserted_at) FROM stdin;
20210706140551	2025-09-09 22:42:57
20220329161857	2025-09-09 22:42:57
20220410212326	2025-09-09 22:42:57
20220506102948	2025-09-09 22:42:57
20220527210857	2025-09-09 22:42:57
20220815211129	2025-09-09 22:42:57
20220815215024	2025-09-09 22:42:57
20220818141501	2025-09-09 22:42:57
20221018173709	2025-09-09 22:42:57
20221102172703	2025-09-09 22:42:57
20221223010058	2025-09-09 22:42:57
20230110180046	2025-09-09 22:42:57
20230810220907	2025-09-09 22:42:57
20230810220924	2025-09-09 22:42:57
20231024094642	2025-09-09 22:42:57
20240306114423	2025-09-09 22:42:57
20240418082835	2025-09-09 22:42:57
20240625211759	2025-09-09 22:42:57
20240704172020	2025-09-09 22:42:57
20240902173232	2025-09-09 22:42:57
20241106103258	2025-09-09 22:42:57
20250424203323	2025-09-09 22:42:57
20250613072131	2025-09-09 22:42:57
20250711044927	2025-09-09 22:42:57
20250811121559	2025-09-09 22:42:57
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: _realtime; Owner: supabase_admin
--

COPY _realtime.tenants (id, name, external_id, jwt_secret, max_concurrent_users, inserted_at, updated_at, max_events_per_second, postgres_cdc_default, max_bytes_per_second, max_channels_per_client, max_joins_per_second, suspend, jwt_jwks, notify_private_alpha, private_only, migrations_ran, broadcast_adapter, max_presence_events_per_second, max_payload_size_in_kb) FROM stdin;
47fcd1d6-3f31-4899-9d3d-cad86764f5d6	realtime-dev	realtime-dev	iNjicxc4+llvc9wovDvqymwfnj9teWMlyOIbJ8Fh6j2WNU8CIJ2ZgjR6MUIKqSmeDmvpsKLsZ9jgXJmQPpwL8w==	200	2025-11-05 12:57:37	2025-11-05 12:57:37	100	postgres_cdc_rls	100000	100	100	f	{"keys": [{"k": "c3VwZXItc2VjcmV0LWp3dC10b2tlbi13aXRoLWF0LWxlYXN0LTMyLWNoYXJhY3RlcnMtbG9uZw", "kty": "oct"}]}	f	f	63	gen_rpc	10000	3000
\.


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
00000000-0000-0000-0000-000000000000	69b371b5-7546-41cb-8650-1c1f6ccae55a	{"action":"user_signedup","actor_id":"61cd3a0b-57cc-472f-8722-70ed6320786b","actor_username":"demo.user@orchestratorai.io","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-11 21:23:51.030327+00	
00000000-0000-0000-0000-000000000000	de1ff0ba-b74c-468b-998c-a106363705eb	{"action":"login","actor_id":"61cd3a0b-57cc-472f-8722-70ed6320786b","actor_username":"demo.user@orchestratorai.io","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-11 21:23:51.033231+00	
00000000-0000-0000-0000-000000000000	0a9cb9db-97fc-4384-96e4-e27ddf6f9261	{"action":"login","actor_id":"61cd3a0b-57cc-472f-8722-70ed6320786b","actor_username":"demo.user@orchestratorai.io","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-11 21:25:19.966758+00	
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
61cd3a0b-57cc-472f-8722-70ed6320786b	61cd3a0b-57cc-472f-8722-70ed6320786b	{"sub": "61cd3a0b-57cc-472f-8722-70ed6320786b", "email": "demo.user@orchestratorai.io", "email_verified": false, "phone_verified": false}	email	2025-10-11 21:23:51.029181+00	2025-10-11 21:23:51.029205+00	2025-10-11 21:23:51.029205+00	15394ab9-19e1-4479-8d63-493f58f2846d
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
f7f16efa-6317-469a-b8a8-f01761f628f5	2025-10-11 21:23:51.037667+00	2025-10-11 21:23:51.037667+00	password	47ac80e7-d479-4b99-b4ae-b584f9ec8194
e2ea3c93-7b47-4116-ba9f-48db2d509d96	2025-10-11 21:25:19.968408+00	2025-10-11 21:25:19.968408+00	password	1ab27c6c-aa92-4dcd-ac61-f38dcc11d17e
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	1	246dlgls2brq	61cd3a0b-57cc-472f-8722-70ed6320786b	f	2025-10-11 21:23:51.035163+00	2025-10-11 21:23:51.035163+00	\N	f7f16efa-6317-469a-b8a8-f01761f628f5
00000000-0000-0000-0000-000000000000	2	5ujxgoplsilt	61cd3a0b-57cc-472f-8722-70ed6320786b	f	2025-10-11 21:25:19.967787+00	2025-10-11 21:25:19.967787+00	\N	e2ea3c93-7b47-4116-ba9f-48db2d509d96
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id) FROM stdin;
f7f16efa-6317-469a-b8a8-f01761f628f5	61cd3a0b-57cc-472f-8722-70ed6320786b	2025-10-11 21:23:51.033611+00	2025-10-11 21:23:51.033611+00	\N	aal1	\N	\N	curl/8.7.1	192.168.65.1	\N	\N
e2ea3c93-7b47-4116-ba9f-48db2d509d96	61cd3a0b-57cc-472f-8722-70ed6320786b	2025-10-11 21:25:19.967284+00	2025-10-11 21:25:19.967284+00	\N	aal1	\N	\N	curl/8.7.1	192.168.65.1	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	61cd3a0b-57cc-472f-8722-70ed6320786b	authenticated	authenticated	demo.user@orchestratorai.io	$2a$10$PtWOxY3A8y2figp6tzMCvuhkxH6xIG2xYpyp//D25RX/O2dCCCrbO	2025-10-11 21:23:51.031046+00	\N		\N		\N			\N	2025-10-11 21:25:19.967233+00	{"provider": "email", "providers": ["email"]}	{"sub": "61cd3a0b-57cc-472f-8722-70ed6320786b", "email": "demo.user@orchestratorai.io", "email_verified": true, "phone_verified": false}	\N	2025-10-11 21:23:51.023108+00	2025-10-11 21:25:19.968261+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c4d5e6f7-8901-2345-6789-abcdef012345	authenticated	authenticated	golfergeek@orchestratorai.io	$2a$06$NB.M8iX6siiAjTcCGdqevOqO6Xj1eicVIZ/I1cgwlGWDMUqTMxMNm	2025-10-09 19:28:38.352108+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	2025-10-09 19:28:38.352108+00	2025-10-09 19:28:38.352108+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a1b2c3d4-e5f6-7890-abcd-ef1234567890	authenticated	authenticated	admin@orchestratorai.io	$2a$06$M40tadYZqPNpdspfzoJef.VXKwZn2919vkslDzYGS3k8RqZSNmLoC	2025-10-09 19:28:38.352108+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	2025-10-09 19:28:38.352108+00	2025-10-13 19:59:33.483214+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: agent_conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_conversations (id, user_id, agent_name, agent_type, started_at, ended_at, last_active_at, metadata, primary_work_product_id, primary_work_product_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cidafm_commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cidafm_commands (id, name, type, description, default_active, is_builtin, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, name, industry, founded_year, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deliverable_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliverable_versions (id, deliverable_id, version_number, content, format, is_current_version, created_by_type, task_id, metadata, file_attachments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deliverables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliverables (id, user_id, conversation_id, title, deliverable_type, created_at, updated_at, project_step_id, agent_name, task_id, metadata) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departments (id, company_id, name, head_of_department, budget, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: human_inputs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.human_inputs (id, task_id, user_id, request_type, prompt, options, user_response, response_metadata, status, timeout_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: kpi_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kpi_data (id, department_id, metric_id, value, date_recorded, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: kpi_goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kpi_goals (id, department_id, metric_id, target_value, period_start, period_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: kpi_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kpi_metrics (id, name, metric_type, unit, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: langgraph_states; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.langgraph_states (id, project_id, plan_state, step_results, metadata, state_version, last_synchronized, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llm_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_models (model_name, provider_name, display_name, model_type, model_version, context_window, max_output_tokens, model_parameters_json, pricing_info_json, capabilities, is_local, is_currently_loaded, model_tier, speed_tier, loading_priority, is_active, training_data_cutoff, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llm_models_backup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_models_backup (id, provider_id, model_name, display_name, model_type, context_window, max_output_tokens, model_parameters_json, pricing_info_json, capabilities, is_active, model_version, training_data_cutoff, created_at, updated_at, is_local, is_currently_loaded, model_tier, loading_priority, capabilities_json, complexity_level, thinking_mode, speed_tier, resource_requirements) FROM stdin;
\.


--
-- Data for Name: llm_providers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_providers (name, display_name, api_base_url, configuration_json, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llm_providers_backup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_providers_backup (id, name, display_name, api_base_url, api_key_encrypted, configuration_json, is_active, rate_limit_rpm, rate_limit_tpm, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llm_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_usage (id, provider, model, user_id, session_id, request_timestamp, response_timestamp, input_tokens, output_tokens, estimated_cost, request_metadata, response_metadata, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llm_usage_backup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_usage_backup (id, run_id, user_id, caller_type, caller_name, conversation_id, provider_id, model_id, provider_name, model_name, is_local, model_tier, fallback_used, routing_reason, input_tokens, output_tokens, total_tokens, input_cost, output_cost, total_cost, duration_ms, response_time_ms, status, error_message, complexity_level, complexity_score, data_classification, started_at, completed_at, created_at, updated_at, data_sanitization_applied, sanitization_level, pii_detected, pii_types, pseudonyms_used, pseudonym_types, redactions_applied, redaction_types, source_blinding_applied, headers_stripped, custom_user_agent_used, proxy_used, no_train_header_sent, no_retain_header_sent, sanitization_time_ms, reversal_context_size, policy_profile, sovereign_mode, compliance_flags, langsmith_run_id, metadata) FROM stdin;
\.


--
-- Data for Name: project_steps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_steps (id, project_id, step_id, step_index, step_type, step_name, agent_name, prompt, dependencies, status, result, error_details, started_at, completed_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, user_id, conversation_id, name, description, status, plan_json, current_step_id, parent_project_id, hierarchy_level, subproject_count, metadata, error_details, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pseudonym_dictionaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pseudonym_dictionaries (id, data_type, category, value, locale, frequency_weight, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: pseudonym_mappings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pseudonym_mappings (id, original_hash, pseudonym, data_type, context, created_at, last_used_at, usage_count, expires_at, is_reversible, created_by_system) FROM stdin;
\.


--
-- Data for Name: redaction_audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.redaction_audit_log (id, session_id, run_id, operation_type, data_type, pattern_name, original_length, redacted_length, pseudonym_count, redaction_count, processing_time_ms, created_at, user_id, service_name, metadata) FROM stdin;
\.


--
-- Data for Name: redaction_patterns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.redaction_patterns (id, name, pattern_regex, replacement, description, category, is_active, priority, created_by, created_at, updated_at, usage_count, last_used_at) FROM stdin;
\.


--
-- Data for Name: role_audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_audit_log (id, user_id, admin_user_id, action, old_roles, new_roles, reason, created_at) FROM stdin;
\.


--
-- Data for Name: sensitive_data_vault; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sensitive_data_vault (id, pseudonym_mapping_id, encrypted_original, encryption_key_id, access_level, created_at, accessed_at, access_count, retention_until) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, user_id, agent_conversation_id, method, params, prompt, response, status, progress, progress_message, error_code, error_message, error_data, started_at, completed_at, timeout_seconds, deliverable_type, deliverable_metadata, metadata, llm_metadata, response_metadata, evaluation, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_cidafm_commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_cidafm_commands (id, user_id, command_id, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, display_name, created_at, updated_at, phone, phone_verified, company, role, department, location, timezone, locale, status, roles) FROM stdin;
61cd3a0b-57cc-472f-8722-70ed6320786b	demo.user@orchestratorai.io	Demo User	2025-10-11 21:24:51.925408+00	2025-10-11 21:24:51.925408+00	\N	f	\N	\N	\N	\N	UTC	en-US	active	["user", "admin"]
\.


--
-- Data for Name: messages_2025_11_04; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_11_04 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2025_11_05; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_11_05 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2025_11_06; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_11_06 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2025_11_07; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_11_07 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2025_11_08; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2025_11_08 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-09-09 22:42:58
20211116045059	2025-09-09 22:42:58
20211116050929	2025-09-09 22:42:58
20211116051442	2025-09-09 22:42:58
20211116212300	2025-09-09 22:42:58
20211116213355	2025-09-09 22:42:58
20211116213934	2025-09-09 22:42:58
20211116214523	2025-09-09 22:42:58
20211122062447	2025-09-09 22:42:58
20211124070109	2025-09-09 22:42:58
20211202204204	2025-09-09 22:42:58
20211202204605	2025-09-09 22:42:58
20211210212804	2025-09-09 22:42:58
20211228014915	2025-09-09 22:42:58
20220107221237	2025-09-09 22:42:58
20220228202821	2025-09-09 22:42:58
20220312004840	2025-09-09 22:42:58
20220603231003	2025-09-09 22:42:58
20220603232444	2025-09-09 22:42:58
20220615214548	2025-09-09 22:42:58
20220712093339	2025-09-09 22:42:58
20220908172859	2025-09-09 22:42:58
20220916233421	2025-09-09 22:42:58
20230119133233	2025-09-09 22:42:58
20230128025114	2025-09-09 22:42:58
20230128025212	2025-09-09 22:42:58
20230227211149	2025-09-09 22:42:58
20230228184745	2025-09-09 22:42:58
20230308225145	2025-09-09 22:42:58
20230328144023	2025-09-09 22:42:58
20231018144023	2025-09-09 22:42:58
20231204144023	2025-09-09 22:42:58
20231204144024	2025-09-09 22:42:58
20231204144025	2025-09-09 22:42:58
20240108234812	2025-09-09 22:42:58
20240109165339	2025-09-09 22:42:58
20240227174441	2025-09-09 22:42:58
20240311171622	2025-09-09 22:42:58
20240321100241	2025-09-09 22:42:58
20240401105812	2025-09-09 22:42:58
20240418121054	2025-09-09 22:42:58
20240523004032	2025-09-09 22:42:58
20240618124746	2025-09-09 22:42:58
20240801235015	2025-09-09 22:42:58
20240805133720	2025-09-09 22:42:58
20240827160934	2025-09-09 22:42:58
20240919163303	2025-09-09 22:42:58
20240919163305	2025-09-09 22:42:58
20241019105805	2025-09-09 22:42:58
20241030150047	2025-09-09 22:42:58
20241108114728	2025-09-09 22:42:58
20241121104152	2025-09-09 22:42:58
20241130184212	2025-09-09 22:42:58
20241220035512	2025-09-09 22:42:58
20241220123912	2025-09-09 22:42:58
20241224161212	2025-09-09 22:42:58
20250107150512	2025-09-09 22:42:58
20250110162412	2025-09-09 22:42:58
20250123174212	2025-09-09 22:42:58
20250128220012	2025-09-09 22:42:58
20250506224012	2025-09-09 22:42:58
20250523164012	2025-09-09 22:42:58
20250714121412	2025-09-09 22:42:58
20250905041441	2025-10-11 21:11:16
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (id, type, format, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iceberg_namespaces; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.iceberg_namespaces (id, bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iceberg_tables; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.iceberg_tables (id, namespace_id, bucket_id, name, location, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-09-09 22:43:09.761506
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-09-09 22:43:09.763236
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-09-09 22:43:09.763976
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-09-09 22:43:09.767735
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-09-09 22:43:09.770876
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-09-09 22:43:09.771675
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-09-09 22:43:09.77283
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-09-09 22:43:09.773937
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-09-09 22:43:09.774565
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-09-09 22:43:09.775411
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-09-09 22:43:09.776368
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-09-09 22:43:09.777648
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-09-09 22:43:09.778967
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-09-09 22:43:09.779872
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-09-09 22:43:09.780604
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-09-09 22:43:09.785748
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-09-09 22:43:09.786701
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-09-09 22:43:09.787477
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-09-09 22:43:09.788366
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-09-09 22:43:09.789545
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-09-09 22:43:09.790272
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-09-09 22:43:09.791403
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-09-09 22:43:09.794189
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-09-09 22:43:09.796646
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-09-09 22:43:09.797811
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-09-09 22:43:09.798688
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-09-09 22:43:09.799427
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-09-09 22:43:09.803246
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-09-09 22:43:09.826462
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-09-09 22:43:09.828131
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-09-09 22:43:09.829045
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-09-09 22:43:09.830318
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-09-09 22:43:09.831313
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-09-09 22:43:09.832242
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-09-09 22:43:09.832424
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-09-09 22:43:09.834051
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-09-09 22:43:09.834677
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-09-09 22:43:09.836928
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-09-09 22:43:09.837991
39	add-search-v2-sort-support	39cf7d1e6bf515f4b02e41237aba845a7b492853	2025-10-11 21:11:39.170428
40	fix-prefix-race-conditions-optimized	fd02297e1c67df25a9fc110bf8c8a9af7fb06d1f	2025-10-11 21:11:39.194054
41	add-object-level-update-trigger	44c22478bf01744b2129efc480cd2edc9a7d60e9	2025-10-11 21:11:39.200796
42	rollback-prefix-triggers	f2ab4f526ab7f979541082992593938c05ee4b47	2025-10-11 21:11:39.202941
43	fix-object-level	ab837ad8f1c7d00cc0b7310e989a23388ff29fc6	2025-10-11 21:11:39.205153
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: hooks; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.hooks (id, hook_table_id, hook_name, created_at, request_id) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.migrations (version, inserted_at) FROM stdin;
initial	2025-09-09 22:42:56.432615+00
20210809183423_update_grants	2025-09-09 22:42:56.432615+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.schema_migrations (version, statements, name) FROM stdin;
20250101000001	{"SET statement_timeout = 0","SET lock_timeout = 0","SET idle_in_transaction_session_timeout = 0","SET client_encoding = 'UTF8'","SET standard_conforming_strings = on","SELECT pg_catalog.set_config('search_path', '', false)","SET check_function_bodies = false","SET xmloption = content","SET client_min_messages = warning","SET row_security = off","CREATE EXTENSION IF NOT EXISTS \\"pg_net\\" WITH SCHEMA \\"extensions\\"","COMMENT ON SCHEMA \\"public\\" IS 'Schema updated with comprehensive sample data for frontend component testing - Migration 20250904205911'","CREATE EXTENSION IF NOT EXISTS \\"pg_graphql\\" WITH SCHEMA \\"graphql\\"","CREATE EXTENSION IF NOT EXISTS \\"pg_stat_statements\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"pgcrypto\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"supabase_vault\\" WITH SCHEMA \\"vault\\"","CREATE EXTENSION IF NOT EXISTS \\"uuid-ossp\\" WITH SCHEMA \\"extensions\\"","CREATE TYPE \\"public\\".\\"pii_data_type\\" AS ENUM (\n    'email',\n    'phone',\n    'name',\n    'address',\n    'ip_address',\n    'username',\n    'credit_card',\n    'ssn',\n    'custom'\n)","ALTER TYPE \\"public\\".\\"pii_data_type\\" OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"calculate_sanitization_score\\"(\\"p_pii_detected\\" boolean, \\"p_sanitization_level\\" character varying, \\"p_redactions_applied\\" integer, \\"p_pseudonyms_used\\" integer) RETURNS integer\n    LANGUAGE \\"plpgsql\\" IMMUTABLE\n    AS $$\nDECLARE\n    score INTEGER := 0;\nBEGIN\n    -- Points for sanitization level\n    score := CASE p_sanitization_level\n        WHEN 'strict' THEN score + 40\n        WHEN 'standard' THEN score + 30\n        WHEN 'basic' THEN score + 20\n        WHEN 'none' THEN score + 0\n        ELSE score\n    END;\n    \n    -- Points for PII handling\n    IF p_pii_detected THEN\n        IF p_pseudonyms_used > 0 THEN\n            score := score + 25;\n        END IF;\n        IF p_redactions_applied > 0 THEN\n            score := score + 25;\n        END IF;\n    ELSE\n        -- No PII detected gets full score\n        score := score + 50;\n    END IF;\n    \n    -- Bonus for comprehensive sanitization\n    IF p_redactions_applied > 0 AND p_pseudonyms_used > 0 THEN\n        score := score + 10;\n    END IF;\n    \n    RETURN LEAST(score, 100); -- Cap at 100\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"calculate_sanitization_score\\"(\\"p_pii_detected\\" boolean, \\"p_sanitization_level\\" character varying, \\"p_redactions_applied\\" integer, \\"p_pseudonyms_used\\" integer) OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"create_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\", \\"version_content\\" \\"text\\", \\"version_format\\" character varying DEFAULT NULL::character varying, \\"creation_type\\" character varying DEFAULT 'ai_response'::character varying, \\"version_task_id\\" \\"uuid\\" DEFAULT NULL::\\"uuid\\", \\"version_metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\") RETURNS \\"uuid\\"\n    LANGUAGE \\"plpgsql\\" SECURITY DEFINER\n    AS $$\nDECLARE\n    next_version_number INTEGER;\n    new_version_id UUID;\nBEGIN\n    -- Get next version number\n    SELECT COALESCE(MAX(version_number), 0) + 1\n    INTO next_version_number\n    FROM public.deliverable_versions\n    WHERE deliverable_id = deliverable_uuid;\n    \n    -- Unset current version flag on existing versions\n    UPDATE public.deliverable_versions \n    SET is_current_version = false\n    WHERE deliverable_id = deliverable_uuid \n      AND is_current_version = true;\n    \n    -- Create new version\n    INSERT INTO public.deliverable_versions (\n        deliverable_id,\n        version_number,\n        content,\n        format,\n        created_by_type,\n        task_id,\n        metadata,\n        is_current_version\n    ) VALUES (\n        deliverable_uuid,\n        next_version_number,\n        version_content,\n        version_format,\n        creation_type,\n        version_task_id,\n        version_metadata,\n        true\n    ) RETURNING id INTO new_version_id;\n    \n    RETURN new_version_id;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"create_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\", \\"version_content\\" \\"text\\", \\"version_format\\" character varying, \\"creation_type\\" character varying, \\"version_task_id\\" \\"uuid\\", \\"version_metadata\\" \\"jsonb\\") OWNER TO \\"postgres\\"","COMMENT ON FUNCTION \\"public\\".\\"create_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\", \\"version_content\\" \\"text\\", \\"version_format\\" character varying, \\"creation_type\\" character varying, \\"version_task_id\\" \\"uuid\\", \\"version_metadata\\" \\"jsonb\\") IS 'Helper function to create new deliverable version with proper version numbering and current flag management. Allowed creation_type values: ai_response, manual_edit, ai_enhancement, user_request, conversation_task, conversation_merge'","CREATE OR REPLACE FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\") RETURNS json\n    LANGUAGE \\"plpgsql\\" SECURITY DEFINER\n    AS $$\nDECLARE\n    result json;\nBEGIN\n    -- Execute the dynamic SQL and return results as JSON\n    EXECUTE 'SELECT json_agg(row_to_json(t)) FROM (' || query || ') t' INTO result;\n    \n    -- If no rows returned, return empty array instead of null\n    IF result IS NULL THEN\n        result := '[]'::json;\n    END IF;\n    \n    RETURN result;\nEXCEPTION\n    WHEN OTHERS THEN\n        -- Return error information as JSON\n        RETURN json_build_object(\n            'error', true,\n            'message', SQLERRM,\n            'code', SQLSTATE,\n            'query', query\n        );\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\") OWNER TO \\"postgres\\"","COMMENT ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\") IS 'Execute arbitrary SQL queries and return results as JSON array. Used by MCP server for dynamic query execution.'","CREATE OR REPLACE FUNCTION \\"public\\".\\"get_compliance_status\\"(\\"p_llm_usage_id\\" \\"uuid\\") RETURNS \\"jsonb\\"\n    LANGUAGE \\"plpgsql\\" STABLE\n    AS $$\nDECLARE\n    usage_record RECORD;\n    compliance_status JSONB := '{}'::jsonb;\nBEGIN\n    SELECT * FROM public.llm_usage WHERE id = p_llm_usage_id INTO usage_record;\n    \n    IF NOT FOUND THEN\n        RETURN '{\\"error\\": \\"Usage record not found\\"}'::jsonb;\n    END IF;\n    \n    -- GDPR compliance (requires data sanitization for PII)\n    compliance_status := compliance_status || jsonb_build_object(\n        'gdpr_compliant',\n        CASE \n            WHEN usage_record.pii_detected = false THEN true\n            WHEN usage_record.pii_detected = true AND usage_record.data_sanitization_applied = true THEN true\n            ELSE false\n        END\n    );\n    \n    -- HIPAA compliance (requires strict sanitization)\n    compliance_status := compliance_status || jsonb_build_object(\n        'hipaa_compliant',\n        CASE \n            WHEN usage_record.sanitization_level = 'strict' THEN true\n            ELSE false\n        END\n    );\n    \n    -- PCI compliance (requires redaction of payment data)\n    compliance_status := compliance_status || jsonb_build_object(\n        'pci_compliant',\n        CASE \n            WHEN usage_record.redaction_types ? 'credit_card' OR usage_record.redaction_types ? 'payment_info' THEN true\n            WHEN NOT (usage_record.pii_types ? 'credit_card') THEN true\n            ELSE false\n        END\n    );\n    \n    -- Overall sanitization score\n    compliance_status := compliance_status || jsonb_build_object(\n        'sanitization_score',\n        public.calculate_sanitization_score(\n            usage_record.pii_detected,\n            usage_record.sanitization_level,\n            usage_record.redactions_applied,\n            usage_record.pseudonyms_used\n        )\n    );\n    \n    RETURN compliance_status;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"get_compliance_status\\"(\\"p_llm_usage_id\\" \\"uuid\\") OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"get_current_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\") RETURNS TABLE(\\"id\\" \\"uuid\\", \\"version_number\\" integer, \\"content\\" \\"text\\", \\"format\\" character varying, \\"created_by_type\\" character varying, \\"metadata\\" \\"jsonb\\", \\"created_at\\" timestamp with time zone)\n    LANGUAGE \\"plpgsql\\" SECURITY DEFINER\n    AS $$\nBEGIN\n    RETURN QUERY\n    SELECT \n        dv.id,\n        dv.version_number,\n        dv.content,\n        dv.format,\n        dv.created_by_type,\n        dv.metadata,\n        dv.created_at\n    FROM public.deliverable_versions dv\n    WHERE dv.deliverable_id = deliverable_uuid\n      AND dv.is_current_version = true;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"get_current_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\") OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"increment_usage_counter\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    -- Update usage count and last used timestamp\n    NEW.usage_count = COALESCE(OLD.usage_count, 0) + 1;\n    NEW.last_used_at = CURRENT_TIMESTAMP;\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"increment_usage_counter\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_llm_usage_updated_at\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.updated_at = CURRENT_TIMESTAMP;\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_llm_usage_updated_at\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_updated_at_column\\"() RETURNS \\"trigger\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    NEW.updated_at = CURRENT_TIMESTAMP;\n    RETURN NEW;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_updated_at_column\\"() OWNER TO \\"postgres\\"","SET default_tablespace = ''","SET default_table_access_method = \\"heap\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"agent_conversations\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"agent_name\\" character varying(255),\n    \\"agent_type\\" character varying(100),\n    \\"started_at\\" timestamp with time zone,\n    \\"ended_at\\" timestamp with time zone,\n    \\"last_active_at\\" timestamp with time zone,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"primary_work_product_id\\" \\"uuid\\",\n    \\"primary_work_product_type\\" character varying(100),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"agent_conversations\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"agent_conversations\\" IS 'Agent conversations table - cleaned for new deliverables versioning system'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"cidafm_commands\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"type\\" character varying(10) NOT NULL,\n    \\"description\\" \\"text\\",\n    \\"default_active\\" boolean DEFAULT false,\n    \\"is_builtin\\" boolean DEFAULT false,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"cidafm_commands\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"companies\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"industry\\" character varying(100),\n    \\"founded_year\\" integer,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"companies\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"companies\\" IS 'Moved from company schema - contains company information for KPI tracking'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"deliverable_versions\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"deliverable_id\\" \\"uuid\\" NOT NULL,\n    \\"version_number\\" integer NOT NULL,\n    \\"content\\" \\"text\\",\n    \\"format\\" character varying(100),\n    \\"is_current_version\\" boolean DEFAULT false,\n    \\"created_by_type\\" character varying(50) DEFAULT 'ai_response'::character varying,\n    \\"task_id\\" \\"uuid\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"file_attachments\\" \\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    CONSTRAINT \\"deliverable_versions_created_by_type_check\\" CHECK (((\\"created_by_type\\")::\\"text\\" = ANY ((ARRAY['ai_response'::character varying, 'manual_edit'::character varying, 'ai_enhancement'::character varying, 'user_request'::character varying, 'conversation_task'::character varying, 'conversation_merge'::character varying])::\\"text\\"[])))\n)","ALTER TABLE \\"public\\".\\"deliverable_versions\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"deliverable_versions\\" IS 'Version data for deliverables - each deliverable can have multiple versions'","COMMENT ON COLUMN \\"public\\".\\"deliverable_versions\\".\\"is_current_version\\" IS 'Only one version per deliverable can be current (enforced by unique constraint)'","COMMENT ON COLUMN \\"public\\".\\"deliverable_versions\\".\\"created_by_type\\" IS 'How this version was created: ai_response, manual_edit, ai_enhancement, user_request'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"deliverables\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"conversation_id\\" \\"uuid\\",\n    \\"title\\" character varying(255) NOT NULL,\n    \\"deliverable_type\\" character varying(100),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"project_step_id\\" \\"uuid\\",\n    \\"agent_name\\" character varying(255),\n    \\"task_id\\" \\"uuid\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\"\n)","ALTER TABLE \\"public\\".\\"deliverables\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"deliverables\\" IS 'Deliverables table - prepared for new versioning system where each conversation has one deliverable with multiple versions'","COMMENT ON COLUMN \\"public\\".\\"deliverables\\".\\"agent_name\\" IS 'Agent that should handle editing this deliverable (inherited from creating conversation)'","COMMENT ON COLUMN \\"public\\".\\"deliverables\\".\\"task_id\\" IS 'References the task that created this deliverable, used for task-based evaluation'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"departments\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"company_id\\" \\"uuid\\",\n    \\"name\\" character varying(255) NOT NULL,\n    \\"head_of_department\\" character varying(255),\n    \\"budget\\" numeric(15,2),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"departments\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"departments\\" IS 'Moved from company schema - contains department information'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"human_inputs\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"task_id\\" \\"uuid\\" NOT NULL,\n    \\"user_id\\" \\"uuid\\" NOT NULL,\n    \\"request_type\\" \\"text\\" NOT NULL,\n    \\"prompt\\" \\"text\\" NOT NULL,\n    \\"options\\" \\"jsonb\\",\n    \\"user_response\\" \\"text\\",\n    \\"response_metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"status\\" \\"text\\" DEFAULT 'pending'::\\"text\\" NOT NULL,\n    \\"timeout_at\\" timestamp with time zone,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    CONSTRAINT \\"human_inputs_request_type_check\\" CHECK ((\\"request_type\\" = ANY (ARRAY['confirmation'::\\"text\\", 'choice'::\\"text\\", 'input'::\\"text\\", 'approval'::\\"text\\"]))),\n    CONSTRAINT \\"human_inputs_status_check\\" CHECK ((\\"status\\" = ANY (ARRAY['pending'::\\"text\\", 'completed'::\\"text\\", 'timeout'::\\"text\\", 'cancelled'::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"human_inputs\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"kpi_data\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"department_id\\" \\"uuid\\",\n    \\"metric_id\\" \\"uuid\\",\n    \\"value\\" numeric(15,4) NOT NULL,\n    \\"date_recorded\\" \\"date\\" NOT NULL,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"kpi_data\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"kpi_data\\" IS 'Moved from company schema - contains actual KPI data points'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"kpi_goals\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"department_id\\" \\"uuid\\",\n    \\"metric_id\\" \\"uuid\\",\n    \\"target_value\\" numeric(15,4),\n    \\"period_start\\" \\"date\\",\n    \\"period_end\\" \\"date\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"kpi_goals\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"kpi_goals\\" IS 'Moved from company schema - contains KPI targets and goals'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"kpi_metrics\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"metric_type\\" character varying(100),\n    \\"unit\\" character varying(50),\n    \\"description\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"kpi_metrics\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"kpi_metrics\\" IS 'Moved from company schema - contains KPI metric definitions'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"langgraph_states\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"project_id\\" \\"uuid\\",\n    \\"plan_state\\" \\"jsonb\\",\n    \\"step_results\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"state_version\\" integer DEFAULT 1,\n    \\"last_synchronized\\" timestamp with time zone,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"langgraph_states\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_models\\" (\n    \\"model_name\\" \\"text\\" NOT NULL,\n    \\"provider_name\\" \\"text\\" NOT NULL,\n    \\"display_name\\" \\"text\\",\n    \\"model_type\\" \\"text\\" DEFAULT 'text-generation'::\\"text\\",\n    \\"model_version\\" \\"text\\",\n    \\"context_window\\" integer DEFAULT 4096,\n    \\"max_output_tokens\\" integer DEFAULT 2048,\n    \\"model_parameters_json\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"pricing_info_json\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"capabilities\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"is_local\\" boolean DEFAULT false,\n    \\"is_currently_loaded\\" boolean DEFAULT false,\n    \\"model_tier\\" \\"text\\",\n    \\"speed_tier\\" \\"text\\" DEFAULT 'medium'::\\"text\\",\n    \\"loading_priority\\" integer DEFAULT 5,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"training_data_cutoff\\" \\"date\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"llm_models\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"llm_models\\" IS 'LLM models with corrected Anthropic naming (hyphens not dots) - 2025-09-07 fix'","COMMENT ON COLUMN \\"public\\".\\"llm_models\\".\\"speed_tier\\" IS 'Performance tier: ultra-fast (< 1s), fast (1-3s), medium (3-10s), slow (10s+)'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_models_backup\\" (\n    \\"id\\" \\"uuid\\",\n    \\"provider_id\\" \\"uuid\\",\n    \\"model_name\\" character varying(255),\n    \\"display_name\\" character varying(255),\n    \\"model_type\\" character varying(100),\n    \\"context_window\\" integer,\n    \\"max_output_tokens\\" integer,\n    \\"model_parameters_json\\" \\"jsonb\\",\n    \\"pricing_info_json\\" \\"jsonb\\",\n    \\"capabilities\\" \\"jsonb\\",\n    \\"is_active\\" boolean,\n    \\"model_version\\" character varying(100),\n    \\"training_data_cutoff\\" \\"date\\",\n    \\"created_at\\" timestamp with time zone,\n    \\"updated_at\\" timestamp with time zone,\n    \\"is_local\\" boolean,\n    \\"is_currently_loaded\\" boolean,\n    \\"model_tier\\" character varying(50),\n    \\"loading_priority\\" integer,\n    \\"capabilities_json\\" \\"jsonb\\",\n    \\"complexity_level\\" \\"text\\",\n    \\"thinking_mode\\" boolean,\n    \\"speed_tier\\" \\"text\\",\n    \\"resource_requirements\\" \\"jsonb\\"\n)","ALTER TABLE \\"public\\".\\"llm_models_backup\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_providers\\" (\n    \\"name\\" \\"text\\" NOT NULL,\n    \\"display_name\\" \\"text\\" NOT NULL,\n    \\"api_base_url\\" \\"text\\",\n    \\"configuration_json\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"is_active\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"llm_providers\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"llm_providers\\" IS 'LLM providers using name-based system (no UUIDs) - 2025 refresh'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_providers_backup\\" (\n    \\"id\\" \\"uuid\\",\n    \\"name\\" character varying(255),\n    \\"display_name\\" character varying(255),\n    \\"api_base_url\\" character varying(500),\n    \\"api_key_encrypted\\" \\"text\\",\n    \\"configuration_json\\" \\"jsonb\\",\n    \\"is_active\\" boolean,\n    \\"rate_limit_rpm\\" integer,\n    \\"rate_limit_tpm\\" integer,\n    \\"created_at\\" timestamp with time zone,\n    \\"updated_at\\" timestamp with time zone\n)","ALTER TABLE \\"public\\".\\"llm_providers_backup\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_usage\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"gen_random_uuid\\"() NOT NULL,\n    \\"provider\\" \\"text\\" NOT NULL,\n    \\"model\\" \\"text\\" NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"session_id\\" \\"text\\",\n    \\"request_timestamp\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"response_timestamp\\" timestamp with time zone,\n    \\"input_tokens\\" integer DEFAULT 0,\n    \\"output_tokens\\" integer DEFAULT 0,\n    \\"total_tokens\\" integer GENERATED ALWAYS AS ((\\"input_tokens\\" + \\"output_tokens\\")) STORED,\n    \\"estimated_cost\\" numeric(10,6) DEFAULT 0,\n    \\"request_metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"response_metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"error_message\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"llm_usage\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"llm_usage\\" IS 'LLM usage tracking using name-based provider/model references - 2025 refresh'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"llm_usage_backup\\" (\n    \\"id\\" \\"uuid\\",\n    \\"run_id\\" character varying(255),\n    \\"user_id\\" \\"uuid\\",\n    \\"caller_type\\" character varying(100),\n    \\"caller_name\\" character varying(255),\n    \\"conversation_id\\" \\"uuid\\",\n    \\"provider_id\\" \\"uuid\\",\n    \\"model_id\\" \\"uuid\\",\n    \\"provider_name\\" character varying(255),\n    \\"model_name\\" character varying(255),\n    \\"is_local\\" boolean,\n    \\"model_tier\\" character varying(50),\n    \\"fallback_used\\" boolean,\n    \\"routing_reason\\" \\"text\\",\n    \\"input_tokens\\" integer,\n    \\"output_tokens\\" integer,\n    \\"total_tokens\\" integer,\n    \\"input_cost\\" numeric(10,6),\n    \\"output_cost\\" numeric(10,6),\n    \\"total_cost\\" numeric(10,6),\n    \\"duration_ms\\" integer,\n    \\"response_time_ms\\" integer,\n    \\"status\\" character varying(50),\n    \\"error_message\\" \\"text\\",\n    \\"complexity_level\\" character varying(20),\n    \\"complexity_score\\" integer,\n    \\"data_classification\\" character varying(50),\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"created_at\\" timestamp with time zone,\n    \\"updated_at\\" timestamp with time zone,\n    \\"data_sanitization_applied\\" boolean,\n    \\"sanitization_level\\" character varying(20),\n    \\"pii_detected\\" boolean,\n    \\"pii_types\\" \\"jsonb\\",\n    \\"pseudonyms_used\\" integer,\n    \\"pseudonym_types\\" \\"jsonb\\",\n    \\"redactions_applied\\" integer,\n    \\"redaction_types\\" \\"jsonb\\",\n    \\"source_blinding_applied\\" boolean,\n    \\"headers_stripped\\" integer,\n    \\"custom_user_agent_used\\" boolean,\n    \\"proxy_used\\" boolean,\n    \\"no_train_header_sent\\" boolean,\n    \\"no_retain_header_sent\\" boolean,\n    \\"sanitization_time_ms\\" integer,\n    \\"reversal_context_size\\" integer,\n    \\"policy_profile\\" character varying(100),\n    \\"sovereign_mode\\" boolean,\n    \\"compliance_flags\\" \\"jsonb\\",\n    \\"langsmith_run_id\\" \\"uuid\\",\n    \\"metadata\\" \\"jsonb\\"\n)","ALTER TABLE \\"public\\".\\"llm_usage_backup\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"project_steps\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"project_id\\" \\"uuid\\" NOT NULL,\n    \\"step_id\\" \\"text\\" NOT NULL,\n    \\"step_index\\" integer NOT NULL,\n    \\"step_type\\" \\"text\\" NOT NULL,\n    \\"step_name\\" \\"text\\" NOT NULL,\n    \\"agent_name\\" \\"text\\",\n    \\"prompt\\" \\"text\\",\n    \\"dependencies\\" \\"text\\"[] DEFAULT '{}'::\\"text\\"[],\n    \\"status\\" \\"text\\" DEFAULT 'pending'::\\"text\\" NOT NULL,\n    \\"result\\" \\"jsonb\\",\n    \\"error_details\\" \\"jsonb\\",\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    CONSTRAINT \\"project_steps_status_check\\" CHECK ((\\"status\\" = ANY (ARRAY['pending'::\\"text\\", 'running'::\\"text\\", 'completed'::\\"text\\", 'failed'::\\"text\\", 'skipped'::\\"text\\"]))),\n    CONSTRAINT \\"project_steps_step_type_check\\" CHECK ((\\"step_type\\" = ANY (ARRAY['agent_step'::\\"text\\", 'human_approval'::\\"text\\"])))\n)","ALTER TABLE \\"public\\".\\"project_steps\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"project_steps\\" IS 'Individual steps within multi-step projects, enabling complex orchestration workflows with agent execution and human approval points'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"projects\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"conversation_id\\" \\"uuid\\",\n    \\"name\\" character varying(255) NOT NULL,\n    \\"description\\" \\"text\\",\n    \\"status\\" character varying(50) DEFAULT 'planning'::character varying,\n    \\"plan_json\\" \\"jsonb\\",\n    \\"current_step_id\\" \\"text\\",\n    \\"parent_project_id\\" \\"uuid\\",\n    \\"hierarchy_level\\" integer DEFAULT 0,\n    \\"subproject_count\\" integer DEFAULT 0,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"error_details\\" \\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"projects\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"pseudonym_dictionaries\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"data_type\\" \\"public\\".\\"pii_data_type\\" NOT NULL,\n    \\"category\\" character varying(100),\n    \\"value\\" character varying(500) NOT NULL,\n    \\"locale\\" character varying(10) DEFAULT 'en-US'::character varying,\n    \\"frequency_weight\\" integer DEFAULT 1,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"pseudonym_dictionaries\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" IS 'Dictionary data for generating realistic pseudonyms'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"pseudonym_mappings\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"original_hash\\" character varying(64) NOT NULL,\n    \\"pseudonym\\" character varying(500) NOT NULL,\n    \\"data_type\\" \\"public\\".\\"pii_data_type\\" NOT NULL,\n    \\"context\\" character varying(255),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"last_used_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"usage_count\\" integer DEFAULT 1,\n    \\"expires_at\\" timestamp with time zone,\n    \\"is_reversible\\" boolean DEFAULT false,\n    \\"created_by_system\\" character varying(100) DEFAULT 'secret_redaction_service'::character varying\n)","ALTER TABLE \\"public\\".\\"pseudonym_mappings\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"pseudonym_mappings\\" IS 'Mapping table from original PII hashes to consistent pseudonyms'","COMMENT ON COLUMN \\"public\\".\\"pseudonym_mappings\\".\\"original_hash\\" IS 'SHA-256 hash of original PII value for consistent lookup'","COMMENT ON COLUMN \\"public\\".\\"pseudonym_mappings\\".\\"is_reversible\\" IS 'Whether original value is stored in vault for authorized reversal'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"redaction_audit_log\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"session_id\\" character varying(255),\n    \\"run_id\\" \\"uuid\\",\n    \\"operation_type\\" character varying(50) NOT NULL,\n    \\"data_type\\" \\"public\\".\\"pii_data_type\\",\n    \\"pattern_name\\" character varying(255),\n    \\"original_length\\" integer,\n    \\"redacted_length\\" integer,\n    \\"pseudonym_count\\" integer DEFAULT 0,\n    \\"redaction_count\\" integer DEFAULT 0,\n    \\"processing_time_ms\\" integer,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"user_id\\" \\"uuid\\",\n    \\"service_name\\" character varying(100) DEFAULT 'secret_redaction_service'::character varying,\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\"\n)","ALTER TABLE \\"public\\".\\"redaction_audit_log\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"redaction_audit_log\\" IS 'Audit trail for all redaction and pseudonymization operations'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"redaction_patterns\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"pattern_regex\\" \\"text\\" NOT NULL,\n    \\"replacement\\" character varying(500) NOT NULL,\n    \\"description\\" \\"text\\",\n    \\"category\\" character varying(100) DEFAULT 'custom'::character varying,\n    \\"is_active\\" boolean DEFAULT true,\n    \\"priority\\" integer DEFAULT 100,\n    \\"created_by\\" \\"uuid\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"usage_count\\" integer DEFAULT 0,\n    \\"last_used_at\\" timestamp with time zone\n)","ALTER TABLE \\"public\\".\\"redaction_patterns\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"redaction_patterns\\" IS 'Custom redaction patterns extending built-in SecretRedactionService patterns'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"role_audit_log\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"admin_user_id\\" \\"uuid\\",\n    \\"action\\" character varying(50),\n    \\"old_roles\\" \\"text\\",\n    \\"new_roles\\" \\"text\\",\n    \\"reason\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"role_audit_log\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"sensitive_data_vault\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"pseudonym_mapping_id\\" \\"uuid\\",\n    \\"encrypted_original\\" \\"text\\",\n    \\"encryption_key_id\\" character varying(100),\n    \\"access_level\\" character varying(50) DEFAULT 'admin_only'::character varying,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"accessed_at\\" timestamp with time zone,\n    \\"access_count\\" integer DEFAULT 0,\n    \\"retention_until\\" timestamp with time zone\n)","ALTER TABLE \\"public\\".\\"sensitive_data_vault\\" OWNER TO \\"postgres\\"","COMMENT ON TABLE \\"public\\".\\"sensitive_data_vault\\" IS 'Encrypted storage for reversible pseudonyms (admin access only)'","COMMENT ON COLUMN \\"public\\".\\"sensitive_data_vault\\".\\"encrypted_original\\" IS 'AES encrypted original PII value'","CREATE TABLE IF NOT EXISTS \\"public\\".\\"tasks\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"agent_conversation_id\\" \\"uuid\\",\n    \\"method\\" character varying(255),\n    \\"params\\" \\"jsonb\\",\n    \\"prompt\\" \\"text\\",\n    \\"response\\" \\"text\\",\n    \\"status\\" character varying(50) DEFAULT 'pending'::character varying,\n    \\"progress\\" integer DEFAULT 0,\n    \\"progress_message\\" \\"text\\",\n    \\"error_code\\" character varying(100),\n    \\"error_message\\" \\"text\\",\n    \\"error_data\\" \\"jsonb\\",\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"timeout_seconds\\" integer,\n    \\"deliverable_type\\" character varying(100),\n    \\"deliverable_metadata\\" \\"jsonb\\",\n    \\"metadata\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"llm_metadata\\" \\"jsonb\\",\n    \\"response_metadata\\" \\"jsonb\\",\n    \\"evaluation\\" \\"jsonb\\",\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"tasks\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"user_cidafm_commands\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"user_id\\" \\"uuid\\",\n    \\"command_id\\" \\"uuid\\",\n    \\"is_active\\" boolean DEFAULT true,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"user_cidafm_commands\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"users\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"email\\" character varying(255) NOT NULL,\n    \\"display_name\\" character varying(255),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"phone\\" character varying(50),\n    \\"phone_verified\\" boolean DEFAULT false,\n    \\"company\\" character varying(255),\n    \\"role\\" character varying(50),\n    \\"department\\" character varying(255),\n    \\"location\\" character varying(255),\n    \\"timezone\\" character varying(50) DEFAULT 'UTC'::character varying,\n    \\"locale\\" character varying(10) DEFAULT 'en-US'::character varying,\n    \\"status\\" character varying(50) DEFAULT 'active'::character varying,\n    \\"roles\\" \\"jsonb\\" DEFAULT '[\\"user\\"]'::\\"jsonb\\"\n)","ALTER TABLE \\"public\\".\\"users\\" OWNER TO \\"postgres\\"","ALTER TABLE ONLY \\"public\\".\\"agent_conversations\\"\n    ADD CONSTRAINT \\"agent_conversations_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"cidafm_commands\\"\n    ADD CONSTRAINT \\"cidafm_commands_name_key\\" UNIQUE (\\"name\\")","ALTER TABLE ONLY \\"public\\".\\"cidafm_commands\\"\n    ADD CONSTRAINT \\"cidafm_commands_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"companies\\"\n    ADD CONSTRAINT \\"companies_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"deliverable_versions_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"deliverables_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"departments\\"\n    ADD CONSTRAINT \\"departments_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"human_inputs\\"\n    ADD CONSTRAINT \\"human_inputs_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"kpi_data\\"\n    ADD CONSTRAINT \\"kpi_data_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"kpi_goals\\"\n    ADD CONSTRAINT \\"kpi_goals_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"kpi_metrics\\"\n    ADD CONSTRAINT \\"kpi_metrics_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"langgraph_states\\"\n    ADD CONSTRAINT \\"langgraph_states_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"llm_models\\"\n    ADD CONSTRAINT \\"llm_models_pkey\\" PRIMARY KEY (\\"provider_name\\", \\"model_name\\")","ALTER TABLE ONLY \\"public\\".\\"llm_providers\\"\n    ADD CONSTRAINT \\"llm_providers_pkey\\" PRIMARY KEY (\\"name\\")","ALTER TABLE ONLY \\"public\\".\\"llm_usage\\"\n    ADD CONSTRAINT \\"llm_usage_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"project_steps\\"\n    ADD CONSTRAINT \\"project_steps_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"project_steps\\"\n    ADD CONSTRAINT \\"project_steps_project_id_step_id_key\\" UNIQUE (\\"project_id\\", \\"step_id\\")","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"pseudonym_dictionaries\\"\n    ADD CONSTRAINT \\"pseudonym_dictionaries_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"pseudonym_mappings\\"\n    ADD CONSTRAINT \\"pseudonym_mappings_original_hash_key\\" UNIQUE (\\"original_hash\\")","ALTER TABLE ONLY \\"public\\".\\"pseudonym_mappings\\"\n    ADD CONSTRAINT \\"pseudonym_mappings_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"redaction_audit_log\\"\n    ADD CONSTRAINT \\"redaction_audit_log_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"redaction_patterns\\"\n    ADD CONSTRAINT \\"redaction_patterns_name_key\\" UNIQUE (\\"name\\")","ALTER TABLE ONLY \\"public\\".\\"redaction_patterns\\"\n    ADD CONSTRAINT \\"redaction_patterns_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"role_audit_log\\"\n    ADD CONSTRAINT \\"role_audit_log_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"sensitive_data_vault\\"\n    ADD CONSTRAINT \\"sensitive_data_vault_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"tasks\\"\n    ADD CONSTRAINT \\"tasks_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"unique_current_version_per_deliverable\\" EXCLUDE USING \\"btree\\" (\\"deliverable_id\\" WITH =) WHERE ((\\"is_current_version\\" = true))","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"unique_deliverable_per_conversation\\" UNIQUE (\\"conversation_id\\")","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"unique_version_number_per_deliverable\\" UNIQUE (\\"deliverable_id\\", \\"version_number\\")","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_user_id_command_id_key\\" UNIQUE (\\"user_id\\", \\"command_id\\")","ALTER TABLE ONLY \\"public\\".\\"users\\"\n    ADD CONSTRAINT \\"users_email_key\\" UNIQUE (\\"email\\")","ALTER TABLE ONLY \\"public\\".\\"users\\"\n    ADD CONSTRAINT \\"users_pkey\\" PRIMARY KEY (\\"id\\")","CREATE INDEX \\"idx_company_companies_industry\\" ON \\"public\\".\\"companies\\" USING \\"btree\\" (\\"industry\\")","CREATE INDEX \\"idx_company_companies_name\\" ON \\"public\\".\\"companies\\" USING \\"btree\\" (\\"name\\")","CREATE INDEX \\"idx_company_departments_company\\" ON \\"public\\".\\"departments\\" USING \\"btree\\" (\\"company_id\\")","CREATE INDEX \\"idx_company_departments_name\\" ON \\"public\\".\\"departments\\" USING \\"btree\\" (\\"name\\")","CREATE INDEX \\"idx_company_kpi_data_date\\" ON \\"public\\".\\"kpi_data\\" USING \\"btree\\" (\\"date_recorded\\")","CREATE INDEX \\"idx_company_kpi_data_department\\" ON \\"public\\".\\"kpi_data\\" USING \\"btree\\" (\\"department_id\\")","CREATE INDEX \\"idx_company_kpi_data_dept_metric_date\\" ON \\"public\\".\\"kpi_data\\" USING \\"btree\\" (\\"department_id\\", \\"metric_id\\", \\"date_recorded\\")","CREATE INDEX \\"idx_company_kpi_data_metric\\" ON \\"public\\".\\"kpi_data\\" USING \\"btree\\" (\\"metric_id\\")","CREATE INDEX \\"idx_company_kpi_goals_department\\" ON \\"public\\".\\"kpi_goals\\" USING \\"btree\\" (\\"department_id\\")","CREATE INDEX \\"idx_company_kpi_goals_metric\\" ON \\"public\\".\\"kpi_goals\\" USING \\"btree\\" (\\"metric_id\\")","CREATE INDEX \\"idx_company_kpi_goals_period\\" ON \\"public\\".\\"kpi_goals\\" USING \\"btree\\" (\\"period_start\\", \\"period_end\\")","CREATE INDEX \\"idx_company_kpi_metrics_name\\" ON \\"public\\".\\"kpi_metrics\\" USING \\"btree\\" (\\"name\\")","CREATE INDEX \\"idx_company_kpi_metrics_type\\" ON \\"public\\".\\"kpi_metrics\\" USING \\"btree\\" (\\"metric_type\\")","CREATE INDEX \\"idx_deliverable_versions_created_by_type\\" ON \\"public\\".\\"deliverable_versions\\" USING \\"btree\\" (\\"created_by_type\\")","CREATE INDEX \\"idx_deliverable_versions_current\\" ON \\"public\\".\\"deliverable_versions\\" USING \\"btree\\" (\\"deliverable_id\\", \\"is_current_version\\")","CREATE INDEX \\"idx_deliverable_versions_deliverable_id\\" ON \\"public\\".\\"deliverable_versions\\" USING \\"btree\\" (\\"deliverable_id\\")","CREATE INDEX \\"idx_deliverable_versions_number\\" ON \\"public\\".\\"deliverable_versions\\" USING \\"btree\\" (\\"deliverable_id\\", \\"version_number\\")","CREATE INDEX \\"idx_deliverable_versions_task_id\\" ON \\"public\\".\\"deliverable_versions\\" USING \\"btree\\" (\\"task_id\\")","CREATE INDEX \\"idx_deliverable_versions_version_number\\" ON \\"public\\".\\"deliverable_versions\\" USING \\"btree\\" (\\"deliverable_id\\", \\"version_number\\")","CREATE INDEX \\"idx_deliverables_agent_name\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"agent_name\\") WHERE (\\"agent_name\\" IS NOT NULL)","CREATE INDEX \\"idx_deliverables_conversation_id\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"conversation_id\\")","CREATE INDEX \\"idx_deliverables_project_step_id\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"project_step_id\\")","CREATE INDEX \\"idx_deliverables_standalone\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"user_id\\") WHERE (\\"conversation_id\\" IS NULL)","CREATE INDEX \\"idx_deliverables_task_id\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"task_id\\")","CREATE INDEX \\"idx_deliverables_type\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"deliverable_type\\")","CREATE INDEX \\"idx_deliverables_user_id\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_llm_models_active\\" ON \\"public\\".\\"llm_models\\" USING \\"btree\\" (\\"is_active\\") WHERE (\\"is_active\\" = true)","CREATE INDEX \\"idx_llm_models_local\\" ON \\"public\\".\\"llm_models\\" USING \\"btree\\" (\\"is_local\\") WHERE (\\"is_local\\" = true)","CREATE INDEX \\"idx_llm_models_provider\\" ON \\"public\\".\\"llm_models\\" USING \\"btree\\" (\\"provider_name\\")","CREATE INDEX \\"idx_llm_usage_provider_model\\" ON \\"public\\".\\"llm_usage\\" USING \\"btree\\" (\\"provider\\", \\"model\\")","CREATE INDEX \\"idx_llm_usage_session\\" ON \\"public\\".\\"llm_usage\\" USING \\"btree\\" (\\"session_id\\")","CREATE INDEX \\"idx_llm_usage_timestamp\\" ON \\"public\\".\\"llm_usage\\" USING \\"btree\\" (\\"request_timestamp\\")","CREATE INDEX \\"idx_llm_usage_user_id\\" ON \\"public\\".\\"llm_usage\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_orchestrator_agent_conversations_active\\" ON \\"public\\".\\"agent_conversations\\" USING \\"btree\\" (\\"last_active_at\\")","CREATE INDEX \\"idx_orchestrator_agent_conversations_agent\\" ON \\"public\\".\\"agent_conversations\\" USING \\"btree\\" (\\"agent_name\\")","CREATE INDEX \\"idx_orchestrator_agent_conversations_user\\" ON \\"public\\".\\"agent_conversations\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_orchestrator_cidafm_commands_name\\" ON \\"public\\".\\"cidafm_commands\\" USING \\"btree\\" (\\"name\\")","CREATE INDEX \\"idx_orchestrator_cidafm_commands_type\\" ON \\"public\\".\\"cidafm_commands\\" USING \\"btree\\" (\\"type\\")","CREATE INDEX \\"idx_orchestrator_deliverables_conversation\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"conversation_id\\")","CREATE INDEX \\"idx_orchestrator_deliverables_type\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"deliverable_type\\")","CREATE INDEX \\"idx_orchestrator_deliverables_user\\" ON \\"public\\".\\"deliverables\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_orchestrator_human_inputs_created\\" ON \\"public\\".\\"human_inputs\\" USING \\"btree\\" (\\"created_at\\" DESC)","CREATE INDEX \\"idx_orchestrator_human_inputs_status\\" ON \\"public\\".\\"human_inputs\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_orchestrator_human_inputs_task\\" ON \\"public\\".\\"human_inputs\\" USING \\"btree\\" (\\"task_id\\")","CREATE INDEX \\"idx_orchestrator_human_inputs_timeout\\" ON \\"public\\".\\"human_inputs\\" USING \\"btree\\" (\\"timeout_at\\") WHERE (\\"status\\" = 'pending'::\\"text\\")","CREATE INDEX \\"idx_orchestrator_human_inputs_user\\" ON \\"public\\".\\"human_inputs\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_orchestrator_langgraph_states_project\\" ON \\"public\\".\\"langgraph_states\\" USING \\"btree\\" (\\"project_id\\")","CREATE INDEX \\"idx_orchestrator_langgraph_states_version\\" ON \\"public\\".\\"langgraph_states\\" USING \\"btree\\" (\\"state_version\\")","CREATE INDEX \\"idx_orchestrator_project_steps_index\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"project_id\\", \\"step_index\\")","CREATE INDEX \\"idx_orchestrator_project_steps_project\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"project_id\\")","CREATE INDEX \\"idx_orchestrator_project_steps_status\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_orchestrator_projects_conversation\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"conversation_id\\")","CREATE INDEX \\"idx_orchestrator_projects_parent\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"parent_project_id\\")","CREATE INDEX \\"idx_orchestrator_projects_status\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_orchestrator_projects_user\\" ON \\"public\\".\\"projects\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_orchestrator_tasks_conversation\\" ON \\"public\\".\\"tasks\\" USING \\"btree\\" (\\"agent_conversation_id\\")","CREATE INDEX \\"idx_orchestrator_tasks_created\\" ON \\"public\\".\\"tasks\\" USING \\"btree\\" (\\"created_at\\" DESC)","CREATE INDEX \\"idx_orchestrator_tasks_status\\" ON \\"public\\".\\"tasks\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_orchestrator_tasks_user\\" ON \\"public\\".\\"tasks\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_orchestrator_user_cidafm_active\\" ON \\"public\\".\\"user_cidafm_commands\\" USING \\"btree\\" (\\"is_active\\")","CREATE INDEX \\"idx_orchestrator_user_cidafm_user\\" ON \\"public\\".\\"user_cidafm_commands\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_orchestrator_users_email\\" ON \\"public\\".\\"users\\" USING \\"btree\\" (\\"email\\")","CREATE INDEX \\"idx_orchestrator_users_status\\" ON \\"public\\".\\"users\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_project_steps_project_id\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"project_id\\")","CREATE INDEX \\"idx_project_steps_status\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"status\\")","CREATE INDEX \\"idx_project_steps_step_index\\" ON \\"public\\".\\"project_steps\\" USING \\"btree\\" (\\"project_id\\", \\"step_index\\")","CREATE INDEX \\"idx_pseudonym_dict_category\\" ON \\"public\\".\\"pseudonym_dictionaries\\" USING \\"btree\\" (\\"category\\", \\"is_active\\")","CREATE INDEX \\"idx_pseudonym_dict_locale\\" ON \\"public\\".\\"pseudonym_dictionaries\\" USING \\"btree\\" (\\"locale\\")","CREATE INDEX \\"idx_pseudonym_dict_type\\" ON \\"public\\".\\"pseudonym_dictionaries\\" USING \\"btree\\" (\\"data_type\\", \\"is_active\\")","CREATE INDEX \\"idx_pseudonym_mappings_context\\" ON \\"public\\".\\"pseudonym_mappings\\" USING \\"btree\\" (\\"context\\")","CREATE INDEX \\"idx_pseudonym_mappings_expires\\" ON \\"public\\".\\"pseudonym_mappings\\" USING \\"btree\\" (\\"expires_at\\") WHERE (\\"expires_at\\" IS NOT NULL)","CREATE INDEX \\"idx_pseudonym_mappings_hash\\" ON \\"public\\".\\"pseudonym_mappings\\" USING \\"btree\\" (\\"original_hash\\")","CREATE INDEX \\"idx_pseudonym_mappings_type\\" ON \\"public\\".\\"pseudonym_mappings\\" USING \\"btree\\" (\\"data_type\\")","CREATE INDEX \\"idx_redaction_audit_created\\" ON \\"public\\".\\"redaction_audit_log\\" USING \\"btree\\" (\\"created_at\\")","CREATE INDEX \\"idx_redaction_audit_operation\\" ON \\"public\\".\\"redaction_audit_log\\" USING \\"btree\\" (\\"operation_type\\")","CREATE INDEX \\"idx_redaction_audit_run\\" ON \\"public\\".\\"redaction_audit_log\\" USING \\"btree\\" (\\"run_id\\")","CREATE INDEX \\"idx_redaction_audit_session\\" ON \\"public\\".\\"redaction_audit_log\\" USING \\"btree\\" (\\"session_id\\")","CREATE INDEX \\"idx_redaction_audit_user\\" ON \\"public\\".\\"redaction_audit_log\\" USING \\"btree\\" (\\"user_id\\")","CREATE INDEX \\"idx_redaction_patterns_active\\" ON \\"public\\".\\"redaction_patterns\\" USING \\"btree\\" (\\"is_active\\", \\"priority\\")","CREATE INDEX \\"idx_redaction_patterns_category\\" ON \\"public\\".\\"redaction_patterns\\" USING \\"btree\\" (\\"category\\")","CREATE INDEX \\"idx_sensitive_vault_mapping\\" ON \\"public\\".\\"sensitive_data_vault\\" USING \\"btree\\" (\\"pseudonym_mapping_id\\")","CREATE INDEX \\"idx_sensitive_vault_retention\\" ON \\"public\\".\\"sensitive_data_vault\\" USING \\"btree\\" (\\"retention_until\\")","CREATE OR REPLACE TRIGGER \\"update_company_companies_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"companies\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_company_departments_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"departments\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_company_kpi_data_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"kpi_data\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_company_kpi_goals_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"kpi_goals\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_company_kpi_metrics_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"kpi_metrics\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_deliverable_versions_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"deliverable_versions\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_orchestrator_agent_conversations_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"agent_conversations\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_orchestrator_cidafm_commands_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"cidafm_commands\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_orchestrator_deliverables_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"deliverables\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_orchestrator_human_inputs_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"human_inputs\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_orchestrator_langgraph_states_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"langgraph_states\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_orchestrator_project_steps_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"project_steps\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_orchestrator_projects_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"projects\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_orchestrator_tasks_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"tasks\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_orchestrator_users_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"users\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_project_steps_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"project_steps\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","CREATE OR REPLACE TRIGGER \\"update_redaction_patterns_updated_at\\" BEFORE UPDATE ON \\"public\\".\\"redaction_patterns\\" FOR EACH ROW EXECUTE FUNCTION \\"public\\".\\"update_updated_at_column\\"()","ALTER TABLE ONLY \\"public\\".\\"agent_conversations\\"\n    ADD CONSTRAINT \\"agent_conversations_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"deliverable_versions_deliverable_id_fkey\\" FOREIGN KEY (\\"deliverable_id\\") REFERENCES \\"public\\".\\"deliverables\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"deliverable_versions_task_id_fkey\\" FOREIGN KEY (\\"task_id\\") REFERENCES \\"public\\".\\"tasks\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"deliverables_project_step_id_fkey\\" FOREIGN KEY (\\"project_step_id\\") REFERENCES \\"public\\".\\"project_steps\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"deliverables_task_id_fkey\\" FOREIGN KEY (\\"task_id\\") REFERENCES \\"public\\".\\"tasks\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"deliverables_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"departments\\"\n    ADD CONSTRAINT \\"departments_company_id_fkey\\" FOREIGN KEY (\\"company_id\\") REFERENCES \\"public\\".\\"companies\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"deliverable_versions\\"\n    ADD CONSTRAINT \\"fk_deliverable_versions_deliverable_id\\" FOREIGN KEY (\\"deliverable_id\\") REFERENCES \\"public\\".\\"deliverables\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"deliverables\\"\n    ADD CONSTRAINT \\"fk_deliverables_conversation_id\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"agent_conversations\\"(\\"id\\") ON DELETE SET NULL","COMMENT ON CONSTRAINT \\"fk_deliverables_conversation_id\\" ON \\"public\\".\\"deliverables\\" IS 'SET NULL allows deliverables to survive conversation deletion for flexible workflows'","ALTER TABLE ONLY \\"public\\".\\"human_inputs\\"\n    ADD CONSTRAINT \\"human_inputs_task_id_fkey\\" FOREIGN KEY (\\"task_id\\") REFERENCES \\"public\\".\\"tasks\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"human_inputs\\"\n    ADD CONSTRAINT \\"human_inputs_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_data\\"\n    ADD CONSTRAINT \\"kpi_data_department_id_fkey\\" FOREIGN KEY (\\"department_id\\") REFERENCES \\"public\\".\\"departments\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_data\\"\n    ADD CONSTRAINT \\"kpi_data_metric_id_fkey\\" FOREIGN KEY (\\"metric_id\\") REFERENCES \\"public\\".\\"kpi_metrics\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_goals\\"\n    ADD CONSTRAINT \\"kpi_goals_department_id_fkey\\" FOREIGN KEY (\\"department_id\\") REFERENCES \\"public\\".\\"departments\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"kpi_goals\\"\n    ADD CONSTRAINT \\"kpi_goals_metric_id_fkey\\" FOREIGN KEY (\\"metric_id\\") REFERENCES \\"public\\".\\"kpi_metrics\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"langgraph_states\\"\n    ADD CONSTRAINT \\"langgraph_states_project_id_fkey\\" FOREIGN KEY (\\"project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"llm_models\\"\n    ADD CONSTRAINT \\"llm_models_provider_name_fkey\\" FOREIGN KEY (\\"provider_name\\") REFERENCES \\"public\\".\\"llm_providers\\"(\\"name\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"project_steps\\"\n    ADD CONSTRAINT \\"project_steps_project_id_fkey\\" FOREIGN KEY (\\"project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_conversation_id_fkey\\" FOREIGN KEY (\\"conversation_id\\") REFERENCES \\"public\\".\\"agent_conversations\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_parent_project_id_fkey\\" FOREIGN KEY (\\"parent_project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"redaction_audit_log\\"\n    ADD CONSTRAINT \\"redaction_audit_log_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"redaction_patterns\\"\n    ADD CONSTRAINT \\"redaction_patterns_created_by_fkey\\" FOREIGN KEY (\\"created_by\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\") ON DELETE SET NULL","ALTER TABLE ONLY \\"public\\".\\"sensitive_data_vault\\"\n    ADD CONSTRAINT \\"sensitive_data_vault_pseudonym_mapping_id_fkey\\" FOREIGN KEY (\\"pseudonym_mapping_id\\") REFERENCES \\"public\\".\\"pseudonym_mappings\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"tasks\\"\n    ADD CONSTRAINT \\"tasks_agent_conversation_id_fkey\\" FOREIGN KEY (\\"agent_conversation_id\\") REFERENCES \\"public\\".\\"agent_conversations\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"tasks\\"\n    ADD CONSTRAINT \\"tasks_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_command_id_fkey\\" FOREIGN KEY (\\"command_id\\") REFERENCES \\"public\\".\\"cidafm_commands\\"(\\"id\\") ON DELETE CASCADE","ALTER TABLE ONLY \\"public\\".\\"user_cidafm_commands\\"\n    ADD CONSTRAINT \\"user_cidafm_commands_user_id_fkey\\" FOREIGN KEY (\\"user_id\\") REFERENCES \\"public\\".\\"users\\"(\\"id\\") ON DELETE CASCADE","CREATE POLICY \\"Users can view own deliverable versions\\" ON \\"public\\".\\"deliverable_versions\\" USING ((\\"auth\\".\\"uid\\"() = ( SELECT \\"d\\".\\"user_id\\"\n   FROM \\"public\\".\\"deliverables\\" \\"d\\"\n  WHERE (\\"d\\".\\"id\\" = \\"deliverable_versions\\".\\"deliverable_id\\"))))","CREATE POLICY \\"Users can view own project steps\\" ON \\"public\\".\\"project_steps\\" USING ((\\"auth\\".\\"uid\\"() = ( SELECT \\"projects\\".\\"user_id\\"\n   FROM \\"public\\".\\"projects\\"\n  WHERE (\\"projects\\".\\"id\\" = \\"project_steps\\".\\"project_id\\"))))","CREATE POLICY \\"audit_log_read_own_or_admin\\" ON \\"public\\".\\"redaction_audit_log\\" FOR SELECT USING (((\\"user_id\\" = \\"auth\\".\\"uid\\"()) OR (EXISTS ( SELECT 1\n   FROM \\"public\\".\\"users\\"\n  WHERE ((\\"users\\".\\"id\\" = \\"auth\\".\\"uid\\"()) AND ((\\"users\\".\\"roles\\" @> '[\\"admin\\"]'::\\"jsonb\\") OR ((\\"users\\".\\"roles\\")::\\"text\\" ~~ '%admin%'::\\"text\\")))))))","ALTER TABLE \\"public\\".\\"deliverable_versions\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"project_steps\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"redaction_audit_log\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"sensitive_data_vault\\" ENABLE ROW LEVEL SECURITY","CREATE POLICY \\"vault_access_admin_only\\" ON \\"public\\".\\"sensitive_data_vault\\" USING ((EXISTS ( SELECT 1\n   FROM \\"public\\".\\"users\\"\n  WHERE ((\\"users\\".\\"id\\" = \\"auth\\".\\"uid\\"()) AND ((\\"users\\".\\"roles\\" @> '[\\"admin\\"]'::\\"jsonb\\") OR ((\\"users\\".\\"roles\\")::\\"text\\" ~~ '%admin%'::\\"text\\"))))))","ALTER PUBLICATION \\"supabase_realtime\\" OWNER TO \\"postgres\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"postgres\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"anon\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"authenticated\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"calculate_sanitization_score\\"(\\"p_pii_detected\\" boolean, \\"p_sanitization_level\\" character varying, \\"p_redactions_applied\\" integer, \\"p_pseudonyms_used\\" integer) TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"calculate_sanitization_score\\"(\\"p_pii_detected\\" boolean, \\"p_sanitization_level\\" character varying, \\"p_redactions_applied\\" integer, \\"p_pseudonyms_used\\" integer) TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"calculate_sanitization_score\\"(\\"p_pii_detected\\" boolean, \\"p_sanitization_level\\" character varying, \\"p_redactions_applied\\" integer, \\"p_pseudonyms_used\\" integer) TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"create_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\", \\"version_content\\" \\"text\\", \\"version_format\\" character varying, \\"creation_type\\" character varying, \\"version_task_id\\" \\"uuid\\", \\"version_metadata\\" \\"jsonb\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"create_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\", \\"version_content\\" \\"text\\", \\"version_format\\" character varying, \\"creation_type\\" character varying, \\"version_task_id\\" \\"uuid\\", \\"version_metadata\\" \\"jsonb\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"create_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\", \\"version_content\\" \\"text\\", \\"version_format\\" character varying, \\"creation_type\\" character varying, \\"version_task_id\\" \\"uuid\\", \\"version_metadata\\" \\"jsonb\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"exec_sql\\"(\\"query\\" \\"text\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_compliance_status\\"(\\"p_llm_usage_id\\" \\"uuid\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_compliance_status\\"(\\"p_llm_usage_id\\" \\"uuid\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_compliance_status\\"(\\"p_llm_usage_id\\" \\"uuid\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_current_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\") TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_current_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\") TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"get_current_deliverable_version\\"(\\"deliverable_uuid\\" \\"uuid\\") TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"increment_usage_counter\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"increment_usage_counter\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"increment_usage_counter\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_llm_usage_updated_at\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_llm_usage_updated_at\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_llm_usage_updated_at\\"() TO \\"service_role\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_updated_at_column\\"() TO \\"anon\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_updated_at_column\\"() TO \\"authenticated\\"","GRANT ALL ON FUNCTION \\"public\\".\\"update_updated_at_column\\"() TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_conversations\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_conversations\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"agent_conversations\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"cidafm_commands\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"cidafm_commands\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"cidafm_commands\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverable_versions\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverable_versions\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverable_versions\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverables\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverables\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"deliverables\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"human_inputs\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"human_inputs\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"human_inputs\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"langgraph_states\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"langgraph_states\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"langgraph_states\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models_backup\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models_backup\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_models_backup\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers_backup\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers_backup\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_providers_backup\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage_backup\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage_backup\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"llm_usage_backup\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"project_steps\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"project_steps\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"project_steps\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_dictionaries\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_mappings\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_mappings\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"pseudonym_mappings\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_audit_log\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_audit_log\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_audit_log\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_patterns\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_patterns\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"redaction_patterns\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"role_audit_log\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"role_audit_log\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"role_audit_log\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"sensitive_data_vault\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"sensitive_data_vault\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"sensitive_data_vault\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"tasks\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"tasks\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"tasks\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"user_cidafm_commands\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"user_cidafm_commands\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"user_cidafm_commands\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"anon\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"postgres\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"anon\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"authenticated\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"postgres\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"anon\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"authenticated\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON FUNCTIONS TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"postgres\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"anon\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"authenticated\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES TO \\"service_role\\"","RESET ALL"}	consolidated_schema_complete
20250109000001	{"-- ============================================================================\n-- Remove problematic LLM models that cause quota/access issues for demo users\n-- ============================================================================\n-- \n-- This migration removes:\n-- 1. o1-preview (OpenAI) - Not available in most accounts, causes 404 errors\n-- 2. gemini-2.0-pro (Google) - Causes quota exceeded errors for demo users\n--\n-- These models were causing test failures and could impact demo user experience\n-- by hitting API quota limits or access restrictions.\n-- ============================================================================\n\n-- Remove o1-preview (OpenAI) - Not available in most accounts\nDELETE FROM public.llm_models \nWHERE provider_name = 'openai' \nAND model_name = 'o1-preview'","-- Remove gemini-2.0-pro (Google) - Quota issues for demo users  \nDELETE FROM public.llm_models \nWHERE provider_name = 'google' \nAND model_name = 'gemini-2.0-pro'","-- Add comment for tracking\nCOMMENT ON TABLE public.llm_models IS 'LLM models - removed o1-preview and gemini-2.0-pro for demo stability (2025-01-09)'"}	remove_problematic_models
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 2, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: hooks_id_seq; Type: SEQUENCE SET; Schema: supabase_functions; Owner: supabase_functions_admin
--

SELECT pg_catalog.setval('supabase_functions.hooks_id_seq', 1, false);


--
-- Name: extensions extensions_pkey; Type: CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.extensions
    ADD CONSTRAINT extensions_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: agent_conversations agent_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_conversations
    ADD CONSTRAINT agent_conversations_pkey PRIMARY KEY (id);


--
-- Name: cidafm_commands cidafm_commands_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidafm_commands
    ADD CONSTRAINT cidafm_commands_name_key UNIQUE (name);


--
-- Name: cidafm_commands cidafm_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidafm_commands
    ADD CONSTRAINT cidafm_commands_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: deliverable_versions deliverable_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT deliverable_versions_pkey PRIMARY KEY (id);


--
-- Name: deliverables deliverables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: human_inputs human_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.human_inputs
    ADD CONSTRAINT human_inputs_pkey PRIMARY KEY (id);


--
-- Name: kpi_data kpi_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_data
    ADD CONSTRAINT kpi_data_pkey PRIMARY KEY (id);


--
-- Name: kpi_goals kpi_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_goals
    ADD CONSTRAINT kpi_goals_pkey PRIMARY KEY (id);


--
-- Name: kpi_metrics kpi_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_metrics
    ADD CONSTRAINT kpi_metrics_pkey PRIMARY KEY (id);


--
-- Name: langgraph_states langgraph_states_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.langgraph_states
    ADD CONSTRAINT langgraph_states_pkey PRIMARY KEY (id);


--
-- Name: llm_models llm_models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_pkey PRIMARY KEY (provider_name, model_name);


--
-- Name: llm_providers llm_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_pkey PRIMARY KEY (name);


--
-- Name: llm_usage llm_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_pkey PRIMARY KEY (id);


--
-- Name: project_steps project_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_steps
    ADD CONSTRAINT project_steps_pkey PRIMARY KEY (id);


--
-- Name: project_steps project_steps_project_id_step_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_steps
    ADD CONSTRAINT project_steps_project_id_step_id_key UNIQUE (project_id, step_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: pseudonym_dictionaries pseudonym_dictionaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonym_dictionaries
    ADD CONSTRAINT pseudonym_dictionaries_pkey PRIMARY KEY (id);


--
-- Name: pseudonym_mappings pseudonym_mappings_original_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonym_mappings
    ADD CONSTRAINT pseudonym_mappings_original_hash_key UNIQUE (original_hash);


--
-- Name: pseudonym_mappings pseudonym_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pseudonym_mappings
    ADD CONSTRAINT pseudonym_mappings_pkey PRIMARY KEY (id);


--
-- Name: redaction_audit_log redaction_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redaction_audit_log
    ADD CONSTRAINT redaction_audit_log_pkey PRIMARY KEY (id);


--
-- Name: redaction_patterns redaction_patterns_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redaction_patterns
    ADD CONSTRAINT redaction_patterns_name_key UNIQUE (name);


--
-- Name: redaction_patterns redaction_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redaction_patterns
    ADD CONSTRAINT redaction_patterns_pkey PRIMARY KEY (id);


--
-- Name: role_audit_log role_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_audit_log
    ADD CONSTRAINT role_audit_log_pkey PRIMARY KEY (id);


--
-- Name: sensitive_data_vault sensitive_data_vault_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensitive_data_vault
    ADD CONSTRAINT sensitive_data_vault_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: deliverable_versions unique_current_version_per_deliverable; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT unique_current_version_per_deliverable EXCLUDE USING btree (deliverable_id WITH =) WHERE ((is_current_version = true));


--
-- Name: deliverables unique_deliverable_per_conversation; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT unique_deliverable_per_conversation UNIQUE (conversation_id);


--
-- Name: deliverable_versions unique_version_number_per_deliverable; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT unique_version_number_per_deliverable UNIQUE (deliverable_id, version_number);


--
-- Name: user_cidafm_commands user_cidafm_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_pkey PRIMARY KEY (id);


--
-- Name: user_cidafm_commands user_cidafm_commands_user_id_command_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_user_id_command_id_key UNIQUE (user_id, command_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_11_04 messages_2025_11_04_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_11_04
    ADD CONSTRAINT messages_2025_11_04_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_11_05 messages_2025_11_05_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_11_05
    ADD CONSTRAINT messages_2025_11_05_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_11_06 messages_2025_11_06_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_11_06
    ADD CONSTRAINT messages_2025_11_06_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_11_07 messages_2025_11_07_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_11_07
    ADD CONSTRAINT messages_2025_11_07_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2025_11_08 messages_2025_11_08_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2025_11_08
    ADD CONSTRAINT messages_2025_11_08_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: iceberg_namespaces iceberg_namespaces_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_pkey PRIMARY KEY (id);


--
-- Name: iceberg_tables iceberg_tables_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: hooks hooks_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks
    ADD CONSTRAINT hooks_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (version);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: extensions_tenant_external_id_index; Type: INDEX; Schema: _realtime; Owner: supabase_admin
--

CREATE INDEX extensions_tenant_external_id_index ON _realtime.extensions USING btree (tenant_external_id);


--
-- Name: extensions_tenant_external_id_type_index; Type: INDEX; Schema: _realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX extensions_tenant_external_id_type_index ON _realtime.extensions USING btree (tenant_external_id, type);


--
-- Name: tenants_external_id_index; Type: INDEX; Schema: _realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX tenants_external_id_index ON _realtime.tenants USING btree (external_id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: idx_company_companies_industry; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_companies_industry ON public.companies USING btree (industry);


--
-- Name: idx_company_companies_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_companies_name ON public.companies USING btree (name);


--
-- Name: idx_company_departments_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_departments_company ON public.departments USING btree (company_id);


--
-- Name: idx_company_departments_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_departments_name ON public.departments USING btree (name);


--
-- Name: idx_company_kpi_data_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_kpi_data_date ON public.kpi_data USING btree (date_recorded);


--
-- Name: idx_company_kpi_data_department; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_kpi_data_department ON public.kpi_data USING btree (department_id);


--
-- Name: idx_company_kpi_data_dept_metric_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_kpi_data_dept_metric_date ON public.kpi_data USING btree (department_id, metric_id, date_recorded);


--
-- Name: idx_company_kpi_data_metric; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_kpi_data_metric ON public.kpi_data USING btree (metric_id);


--
-- Name: idx_company_kpi_goals_department; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_kpi_goals_department ON public.kpi_goals USING btree (department_id);


--
-- Name: idx_company_kpi_goals_metric; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_kpi_goals_metric ON public.kpi_goals USING btree (metric_id);


--
-- Name: idx_company_kpi_goals_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_kpi_goals_period ON public.kpi_goals USING btree (period_start, period_end);


--
-- Name: idx_company_kpi_metrics_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_kpi_metrics_name ON public.kpi_metrics USING btree (name);


--
-- Name: idx_company_kpi_metrics_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_kpi_metrics_type ON public.kpi_metrics USING btree (metric_type);


--
-- Name: idx_deliverable_versions_created_by_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverable_versions_created_by_type ON public.deliverable_versions USING btree (created_by_type);


--
-- Name: idx_deliverable_versions_current; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverable_versions_current ON public.deliverable_versions USING btree (deliverable_id, is_current_version);


--
-- Name: idx_deliverable_versions_deliverable_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverable_versions_deliverable_id ON public.deliverable_versions USING btree (deliverable_id);


--
-- Name: idx_deliverable_versions_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverable_versions_number ON public.deliverable_versions USING btree (deliverable_id, version_number);


--
-- Name: idx_deliverable_versions_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverable_versions_task_id ON public.deliverable_versions USING btree (task_id);


--
-- Name: idx_deliverable_versions_version_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverable_versions_version_number ON public.deliverable_versions USING btree (deliverable_id, version_number);


--
-- Name: idx_deliverables_agent_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverables_agent_name ON public.deliverables USING btree (agent_name) WHERE (agent_name IS NOT NULL);


--
-- Name: idx_deliverables_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverables_conversation_id ON public.deliverables USING btree (conversation_id);


--
-- Name: idx_deliverables_project_step_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverables_project_step_id ON public.deliverables USING btree (project_step_id);


--
-- Name: idx_deliverables_standalone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverables_standalone ON public.deliverables USING btree (user_id) WHERE (conversation_id IS NULL);


--
-- Name: idx_deliverables_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverables_task_id ON public.deliverables USING btree (task_id);


--
-- Name: idx_deliverables_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverables_type ON public.deliverables USING btree (deliverable_type);


--
-- Name: idx_deliverables_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deliverables_user_id ON public.deliverables USING btree (user_id);


--
-- Name: idx_llm_models_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_models_active ON public.llm_models USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_llm_models_local; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_models_local ON public.llm_models USING btree (is_local) WHERE (is_local = true);


--
-- Name: idx_llm_models_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_models_provider ON public.llm_models USING btree (provider_name);


--
-- Name: idx_llm_usage_provider_model; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_usage_provider_model ON public.llm_usage USING btree (provider, model);


--
-- Name: idx_llm_usage_session; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_usage_session ON public.llm_usage USING btree (session_id);


--
-- Name: idx_llm_usage_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_usage_timestamp ON public.llm_usage USING btree (request_timestamp);


--
-- Name: idx_llm_usage_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_usage_user_id ON public.llm_usage USING btree (user_id);


--
-- Name: idx_orchestrator_agent_conversations_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_agent_conversations_active ON public.agent_conversations USING btree (last_active_at);


--
-- Name: idx_orchestrator_agent_conversations_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_agent_conversations_agent ON public.agent_conversations USING btree (agent_name);


--
-- Name: idx_orchestrator_agent_conversations_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_agent_conversations_user ON public.agent_conversations USING btree (user_id);


--
-- Name: idx_orchestrator_cidafm_commands_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_cidafm_commands_name ON public.cidafm_commands USING btree (name);


--
-- Name: idx_orchestrator_cidafm_commands_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_cidafm_commands_type ON public.cidafm_commands USING btree (type);


--
-- Name: idx_orchestrator_deliverables_conversation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_deliverables_conversation ON public.deliverables USING btree (conversation_id);


--
-- Name: idx_orchestrator_deliverables_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_deliverables_type ON public.deliverables USING btree (deliverable_type);


--
-- Name: idx_orchestrator_deliverables_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_deliverables_user ON public.deliverables USING btree (user_id);


--
-- Name: idx_orchestrator_human_inputs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_human_inputs_created ON public.human_inputs USING btree (created_at DESC);


--
-- Name: idx_orchestrator_human_inputs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_human_inputs_status ON public.human_inputs USING btree (status);


--
-- Name: idx_orchestrator_human_inputs_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_human_inputs_task ON public.human_inputs USING btree (task_id);


--
-- Name: idx_orchestrator_human_inputs_timeout; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_human_inputs_timeout ON public.human_inputs USING btree (timeout_at) WHERE (status = 'pending'::text);


--
-- Name: idx_orchestrator_human_inputs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_human_inputs_user ON public.human_inputs USING btree (user_id);


--
-- Name: idx_orchestrator_langgraph_states_project; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_langgraph_states_project ON public.langgraph_states USING btree (project_id);


--
-- Name: idx_orchestrator_langgraph_states_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_langgraph_states_version ON public.langgraph_states USING btree (state_version);


--
-- Name: idx_orchestrator_project_steps_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_project_steps_index ON public.project_steps USING btree (project_id, step_index);


--
-- Name: idx_orchestrator_project_steps_project; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_project_steps_project ON public.project_steps USING btree (project_id);


--
-- Name: idx_orchestrator_project_steps_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_project_steps_status ON public.project_steps USING btree (status);


--
-- Name: idx_orchestrator_projects_conversation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_projects_conversation ON public.projects USING btree (conversation_id);


--
-- Name: idx_orchestrator_projects_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_projects_parent ON public.projects USING btree (parent_project_id);


--
-- Name: idx_orchestrator_projects_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_projects_status ON public.projects USING btree (status);


--
-- Name: idx_orchestrator_projects_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_projects_user ON public.projects USING btree (user_id);


--
-- Name: idx_orchestrator_tasks_conversation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_tasks_conversation ON public.tasks USING btree (agent_conversation_id);


--
-- Name: idx_orchestrator_tasks_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_tasks_created ON public.tasks USING btree (created_at DESC);


--
-- Name: idx_orchestrator_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_tasks_status ON public.tasks USING btree (status);


--
-- Name: idx_orchestrator_tasks_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_tasks_user ON public.tasks USING btree (user_id);


--
-- Name: idx_orchestrator_user_cidafm_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_user_cidafm_active ON public.user_cidafm_commands USING btree (is_active);


--
-- Name: idx_orchestrator_user_cidafm_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_user_cidafm_user ON public.user_cidafm_commands USING btree (user_id);


--
-- Name: idx_orchestrator_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_users_email ON public.users USING btree (email);


--
-- Name: idx_orchestrator_users_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orchestrator_users_status ON public.users USING btree (status);


--
-- Name: idx_project_steps_project_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_steps_project_id ON public.project_steps USING btree (project_id);


--
-- Name: idx_project_steps_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_steps_status ON public.project_steps USING btree (status);


--
-- Name: idx_project_steps_step_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_steps_step_index ON public.project_steps USING btree (project_id, step_index);


--
-- Name: idx_pseudonym_dict_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dict_category ON public.pseudonym_dictionaries USING btree (category, is_active);


--
-- Name: idx_pseudonym_dict_locale; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dict_locale ON public.pseudonym_dictionaries USING btree (locale);


--
-- Name: idx_pseudonym_dict_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_dict_type ON public.pseudonym_dictionaries USING btree (data_type, is_active);


--
-- Name: idx_pseudonym_mappings_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_mappings_context ON public.pseudonym_mappings USING btree (context);


--
-- Name: idx_pseudonym_mappings_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_mappings_expires ON public.pseudonym_mappings USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_pseudonym_mappings_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_mappings_hash ON public.pseudonym_mappings USING btree (original_hash);


--
-- Name: idx_pseudonym_mappings_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pseudonym_mappings_type ON public.pseudonym_mappings USING btree (data_type);


--
-- Name: idx_redaction_audit_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redaction_audit_created ON public.redaction_audit_log USING btree (created_at);


--
-- Name: idx_redaction_audit_operation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redaction_audit_operation ON public.redaction_audit_log USING btree (operation_type);


--
-- Name: idx_redaction_audit_run; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redaction_audit_run ON public.redaction_audit_log USING btree (run_id);


--
-- Name: idx_redaction_audit_session; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redaction_audit_session ON public.redaction_audit_log USING btree (session_id);


--
-- Name: idx_redaction_audit_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redaction_audit_user ON public.redaction_audit_log USING btree (user_id);


--
-- Name: idx_redaction_patterns_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redaction_patterns_active ON public.redaction_patterns USING btree (is_active, priority);


--
-- Name: idx_redaction_patterns_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redaction_patterns_category ON public.redaction_patterns USING btree (category);


--
-- Name: idx_sensitive_vault_mapping; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sensitive_vault_mapping ON public.sensitive_data_vault USING btree (pseudonym_mapping_id);


--
-- Name: idx_sensitive_vault_retention; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sensitive_vault_retention ON public.sensitive_data_vault USING btree (retention_until);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2025_11_04_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_11_04_inserted_at_topic_idx ON realtime.messages_2025_11_04 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2025_11_05_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_11_05_inserted_at_topic_idx ON realtime.messages_2025_11_05 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2025_11_06_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_11_06_inserted_at_topic_idx ON realtime.messages_2025_11_06 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2025_11_07_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_11_07_inserted_at_topic_idx ON realtime.messages_2025_11_07 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2025_11_08_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX messages_2025_11_08_inserted_at_topic_idx ON realtime.messages_2025_11_08 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: idx_iceberg_namespaces_bucket_id; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_iceberg_namespaces_bucket_id ON storage.iceberg_namespaces USING btree (bucket_id, name);


--
-- Name: idx_iceberg_tables_namespace_id; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_iceberg_tables_namespace_id ON storage.iceberg_tables USING btree (namespace_id, name);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- Name: supabase_functions_hooks_h_table_id_h_name_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_h_table_id_h_name_idx ON supabase_functions.hooks USING btree (hook_table_id, hook_name);


--
-- Name: supabase_functions_hooks_request_id_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_request_id_idx ON supabase_functions.hooks USING btree (request_id);


--
-- Name: messages_2025_11_04_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_11_04_inserted_at_topic_idx;


--
-- Name: messages_2025_11_04_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_11_04_pkey;


--
-- Name: messages_2025_11_05_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_11_05_inserted_at_topic_idx;


--
-- Name: messages_2025_11_05_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_11_05_pkey;


--
-- Name: messages_2025_11_06_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_11_06_inserted_at_topic_idx;


--
-- Name: messages_2025_11_06_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_11_06_pkey;


--
-- Name: messages_2025_11_07_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_11_07_inserted_at_topic_idx;


--
-- Name: messages_2025_11_07_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_11_07_pkey;


--
-- Name: messages_2025_11_08_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_11_08_inserted_at_topic_idx;


--
-- Name: messages_2025_11_08_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_11_08_pkey;


--
-- Name: companies update_company_companies_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_company_companies_updated_at BEFORE UPDATE ON public.companies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: departments update_company_departments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_company_departments_updated_at BEFORE UPDATE ON public.departments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: kpi_data update_company_kpi_data_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_company_kpi_data_updated_at BEFORE UPDATE ON public.kpi_data FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: kpi_goals update_company_kpi_goals_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_company_kpi_goals_updated_at BEFORE UPDATE ON public.kpi_goals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: kpi_metrics update_company_kpi_metrics_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_company_kpi_metrics_updated_at BEFORE UPDATE ON public.kpi_metrics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: deliverable_versions update_deliverable_versions_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_deliverable_versions_updated_at BEFORE UPDATE ON public.deliverable_versions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agent_conversations update_orchestrator_agent_conversations_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_orchestrator_agent_conversations_updated_at BEFORE UPDATE ON public.agent_conversations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: cidafm_commands update_orchestrator_cidafm_commands_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_orchestrator_cidafm_commands_updated_at BEFORE UPDATE ON public.cidafm_commands FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: deliverables update_orchestrator_deliverables_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_orchestrator_deliverables_updated_at BEFORE UPDATE ON public.deliverables FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: human_inputs update_orchestrator_human_inputs_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_orchestrator_human_inputs_updated_at BEFORE UPDATE ON public.human_inputs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: langgraph_states update_orchestrator_langgraph_states_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_orchestrator_langgraph_states_updated_at BEFORE UPDATE ON public.langgraph_states FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: project_steps update_orchestrator_project_steps_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_orchestrator_project_steps_updated_at BEFORE UPDATE ON public.project_steps FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: projects update_orchestrator_projects_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_orchestrator_projects_updated_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tasks update_orchestrator_tasks_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_orchestrator_tasks_updated_at BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_orchestrator_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_orchestrator_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: project_steps update_project_steps_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_project_steps_updated_at BEFORE UPDATE ON public.project_steps FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: redaction_patterns update_redaction_patterns_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_redaction_patterns_updated_at BEFORE UPDATE ON public.redaction_patterns FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: extensions extensions_tenant_external_id_fkey; Type: FK CONSTRAINT; Schema: _realtime; Owner: supabase_admin
--

ALTER TABLE ONLY _realtime.extensions
    ADD CONSTRAINT extensions_tenant_external_id_fkey FOREIGN KEY (tenant_external_id) REFERENCES _realtime.tenants(external_id) ON DELETE CASCADE;


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: agent_conversations agent_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_conversations
    ADD CONSTRAINT agent_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: deliverable_versions deliverable_versions_deliverable_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT deliverable_versions_deliverable_id_fkey FOREIGN KEY (deliverable_id) REFERENCES public.deliverables(id) ON DELETE CASCADE;


--
-- Name: deliverable_versions deliverable_versions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT deliverable_versions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: deliverables deliverables_project_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_project_step_id_fkey FOREIGN KEY (project_step_id) REFERENCES public.project_steps(id) ON DELETE SET NULL;


--
-- Name: deliverables deliverables_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: deliverables deliverables_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: departments departments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: deliverable_versions fk_deliverable_versions_deliverable_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverable_versions
    ADD CONSTRAINT fk_deliverable_versions_deliverable_id FOREIGN KEY (deliverable_id) REFERENCES public.deliverables(id) ON DELETE CASCADE;


--
-- Name: deliverables fk_deliverables_conversation_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT fk_deliverables_conversation_id FOREIGN KEY (conversation_id) REFERENCES public.agent_conversations(id) ON DELETE SET NULL;


--
-- Name: CONSTRAINT fk_deliverables_conversation_id ON deliverables; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_deliverables_conversation_id ON public.deliverables IS 'SET NULL allows deliverables to survive conversation deletion for flexible workflows';


--
-- Name: human_inputs human_inputs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.human_inputs
    ADD CONSTRAINT human_inputs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: human_inputs human_inputs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.human_inputs
    ADD CONSTRAINT human_inputs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kpi_data kpi_data_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_data
    ADD CONSTRAINT kpi_data_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- Name: kpi_data kpi_data_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_data
    ADD CONSTRAINT kpi_data_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kpi_metrics(id) ON DELETE CASCADE;


--
-- Name: kpi_goals kpi_goals_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_goals
    ADD CONSTRAINT kpi_goals_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- Name: kpi_goals kpi_goals_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_goals
    ADD CONSTRAINT kpi_goals_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kpi_metrics(id) ON DELETE CASCADE;


--
-- Name: langgraph_states langgraph_states_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.langgraph_states
    ADD CONSTRAINT langgraph_states_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: llm_models llm_models_provider_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_provider_name_fkey FOREIGN KEY (provider_name) REFERENCES public.llm_providers(name) ON DELETE CASCADE;


--
-- Name: project_steps project_steps_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_steps
    ADD CONSTRAINT project_steps_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.agent_conversations(id);


--
-- Name: projects projects_parent_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_parent_project_id_fkey FOREIGN KEY (parent_project_id) REFERENCES public.projects(id);


--
-- Name: projects projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: redaction_audit_log redaction_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redaction_audit_log
    ADD CONSTRAINT redaction_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: redaction_patterns redaction_patterns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redaction_patterns
    ADD CONSTRAINT redaction_patterns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sensitive_data_vault sensitive_data_vault_pseudonym_mapping_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensitive_data_vault
    ADD CONSTRAINT sensitive_data_vault_pseudonym_mapping_id_fkey FOREIGN KEY (pseudonym_mapping_id) REFERENCES public.pseudonym_mappings(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_agent_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_agent_conversation_id_fkey FOREIGN KEY (agent_conversation_id) REFERENCES public.agent_conversations(id);


--
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_cidafm_commands user_cidafm_commands_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_command_id_fkey FOREIGN KEY (command_id) REFERENCES public.cidafm_commands(id) ON DELETE CASCADE;


--
-- Name: user_cidafm_commands user_cidafm_commands_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cidafm_commands
    ADD CONSTRAINT user_cidafm_commands_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: iceberg_namespaces iceberg_namespaces_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- Name: iceberg_tables iceberg_tables_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- Name: iceberg_tables iceberg_tables_namespace_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES storage.iceberg_namespaces(id) ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: deliverable_versions Users can view own deliverable versions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view own deliverable versions" ON public.deliverable_versions USING ((auth.uid() = ( SELECT d.user_id
   FROM public.deliverables d
  WHERE (d.id = deliverable_versions.deliverable_id))));


--
-- Name: project_steps Users can view own project steps; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view own project steps" ON public.project_steps USING ((auth.uid() = ( SELECT projects.user_id
   FROM public.projects
  WHERE (projects.id = project_steps.project_id))));


--
-- Name: redaction_audit_log audit_log_read_own_or_admin; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY audit_log_read_own_or_admin ON public.redaction_audit_log FOR SELECT USING (((user_id = auth.uid()) OR (EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = auth.uid()) AND ((users.roles @> '["admin"]'::jsonb) OR ((users.roles)::text ~~ '%admin%'::text)))))));


--
-- Name: deliverable_versions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.deliverable_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: project_steps; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.project_steps ENABLE ROW LEVEL SECURITY;

--
-- Name: redaction_audit_log; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.redaction_audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: sensitive_data_vault; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.sensitive_data_vault ENABLE ROW LEVEL SECURITY;

--
-- Name: sensitive_data_vault vault_access_admin_only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY vault_access_admin_only ON public.sensitive_data_vault USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = auth.uid()) AND ((users.roles @> '["admin"]'::jsonb) OR ((users.roles)::text ~~ '%admin%'::text))))));


--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: iceberg_namespaces; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.iceberg_namespaces ENABLE ROW LEVEL SECURITY;

--
-- Name: iceberg_tables; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.iceberg_tables ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA net; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA net TO supabase_functions_admin;
GRANT USAGE ON SCHEMA net TO postgres;
GRANT USAGE ON SCHEMA net TO anon;
GRANT USAGE ON SCHEMA net TO authenticated;
GRANT USAGE ON SCHEMA net TO service_role;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: SCHEMA supabase_functions; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA supabase_functions TO postgres;
GRANT USAGE ON SCHEMA supabase_functions TO anon;
GRANT USAGE ON SCHEMA supabase_functions TO authenticated;
GRANT USAGE ON SCHEMA supabase_functions TO service_role;
GRANT ALL ON SCHEMA supabase_functions TO supabase_functions_admin;


--
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer); Type: ACL; Schema: net; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO postgres;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO anon;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO authenticated;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO service_role;


--
-- Name: FUNCTION http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer); Type: ACL; Schema: net; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO postgres;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO anon;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO authenticated;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO service_role;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO postgres;


--
-- Name: FUNCTION calculate_sanitization_score(p_pii_detected boolean, p_sanitization_level character varying, p_redactions_applied integer, p_pseudonyms_used integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.calculate_sanitization_score(p_pii_detected boolean, p_sanitization_level character varying, p_redactions_applied integer, p_pseudonyms_used integer) TO anon;
GRANT ALL ON FUNCTION public.calculate_sanitization_score(p_pii_detected boolean, p_sanitization_level character varying, p_redactions_applied integer, p_pseudonyms_used integer) TO authenticated;
GRANT ALL ON FUNCTION public.calculate_sanitization_score(p_pii_detected boolean, p_sanitization_level character varying, p_redactions_applied integer, p_pseudonyms_used integer) TO service_role;


--
-- Name: FUNCTION create_deliverable_version(deliverable_uuid uuid, version_content text, version_format character varying, creation_type character varying, version_task_id uuid, version_metadata jsonb); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.create_deliverable_version(deliverable_uuid uuid, version_content text, version_format character varying, creation_type character varying, version_task_id uuid, version_metadata jsonb) TO anon;
GRANT ALL ON FUNCTION public.create_deliverable_version(deliverable_uuid uuid, version_content text, version_format character varying, creation_type character varying, version_task_id uuid, version_metadata jsonb) TO authenticated;
GRANT ALL ON FUNCTION public.create_deliverable_version(deliverable_uuid uuid, version_content text, version_format character varying, creation_type character varying, version_task_id uuid, version_metadata jsonb) TO service_role;


--
-- Name: FUNCTION exec_sql(query text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.exec_sql(query text) TO anon;
GRANT ALL ON FUNCTION public.exec_sql(query text) TO authenticated;
GRANT ALL ON FUNCTION public.exec_sql(query text) TO service_role;


--
-- Name: FUNCTION get_compliance_status(p_llm_usage_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_compliance_status(p_llm_usage_id uuid) TO anon;
GRANT ALL ON FUNCTION public.get_compliance_status(p_llm_usage_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_compliance_status(p_llm_usage_id uuid) TO service_role;


--
-- Name: FUNCTION get_current_deliverable_version(deliverable_uuid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_current_deliverable_version(deliverable_uuid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_current_deliverable_version(deliverable_uuid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_current_deliverable_version(deliverable_uuid uuid) TO service_role;


--
-- Name: FUNCTION increment_usage_counter(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.increment_usage_counter() TO anon;
GRANT ALL ON FUNCTION public.increment_usage_counter() TO authenticated;
GRANT ALL ON FUNCTION public.increment_usage_counter() TO service_role;


--
-- Name: FUNCTION update_llm_usage_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_llm_usage_updated_at() TO anon;
GRANT ALL ON FUNCTION public.update_llm_usage_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.update_llm_usage_updated_at() TO service_role;


--
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO anon;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO authenticated;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO service_role;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;


--
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: FUNCTION http_request(); Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

REVOKE ALL ON FUNCTION supabase_functions.http_request() FROM PUBLIC;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO postgres;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO anon;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO authenticated;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO service_role;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE oauth_authorizations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_authorizations TO postgres;
GRANT ALL ON TABLE auth.oauth_authorizations TO dashboard_user;


--
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- Name: TABLE oauth_consents; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_consents TO postgres;
GRANT ALL ON TABLE auth.oauth_consents TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;


--
-- Name: TABLE agent_conversations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.agent_conversations TO anon;
GRANT ALL ON TABLE public.agent_conversations TO authenticated;
GRANT ALL ON TABLE public.agent_conversations TO service_role;


--
-- Name: TABLE cidafm_commands; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.cidafm_commands TO anon;
GRANT ALL ON TABLE public.cidafm_commands TO authenticated;
GRANT ALL ON TABLE public.cidafm_commands TO service_role;


--
-- Name: TABLE companies; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.companies TO anon;
GRANT ALL ON TABLE public.companies TO authenticated;
GRANT ALL ON TABLE public.companies TO service_role;


--
-- Name: TABLE deliverable_versions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.deliverable_versions TO anon;
GRANT ALL ON TABLE public.deliverable_versions TO authenticated;
GRANT ALL ON TABLE public.deliverable_versions TO service_role;


--
-- Name: TABLE deliverables; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.deliverables TO anon;
GRANT ALL ON TABLE public.deliverables TO authenticated;
GRANT ALL ON TABLE public.deliverables TO service_role;


--
-- Name: TABLE departments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.departments TO anon;
GRANT ALL ON TABLE public.departments TO authenticated;
GRANT ALL ON TABLE public.departments TO service_role;


--
-- Name: TABLE human_inputs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.human_inputs TO anon;
GRANT ALL ON TABLE public.human_inputs TO authenticated;
GRANT ALL ON TABLE public.human_inputs TO service_role;


--
-- Name: TABLE kpi_data; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kpi_data TO anon;
GRANT ALL ON TABLE public.kpi_data TO authenticated;
GRANT ALL ON TABLE public.kpi_data TO service_role;


--
-- Name: TABLE kpi_goals; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kpi_goals TO anon;
GRANT ALL ON TABLE public.kpi_goals TO authenticated;
GRANT ALL ON TABLE public.kpi_goals TO service_role;


--
-- Name: TABLE kpi_metrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kpi_metrics TO anon;
GRANT ALL ON TABLE public.kpi_metrics TO authenticated;
GRANT ALL ON TABLE public.kpi_metrics TO service_role;


--
-- Name: TABLE langgraph_states; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.langgraph_states TO anon;
GRANT ALL ON TABLE public.langgraph_states TO authenticated;
GRANT ALL ON TABLE public.langgraph_states TO service_role;


--
-- Name: TABLE llm_models; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_models TO anon;
GRANT ALL ON TABLE public.llm_models TO authenticated;
GRANT ALL ON TABLE public.llm_models TO service_role;


--
-- Name: TABLE llm_models_backup; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_models_backup TO anon;
GRANT ALL ON TABLE public.llm_models_backup TO authenticated;
GRANT ALL ON TABLE public.llm_models_backup TO service_role;


--
-- Name: TABLE llm_providers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_providers TO anon;
GRANT ALL ON TABLE public.llm_providers TO authenticated;
GRANT ALL ON TABLE public.llm_providers TO service_role;


--
-- Name: TABLE llm_providers_backup; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_providers_backup TO anon;
GRANT ALL ON TABLE public.llm_providers_backup TO authenticated;
GRANT ALL ON TABLE public.llm_providers_backup TO service_role;


--
-- Name: TABLE llm_usage; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_usage TO anon;
GRANT ALL ON TABLE public.llm_usage TO authenticated;
GRANT ALL ON TABLE public.llm_usage TO service_role;


--
-- Name: TABLE llm_usage_backup; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.llm_usage_backup TO anon;
GRANT ALL ON TABLE public.llm_usage_backup TO authenticated;
GRANT ALL ON TABLE public.llm_usage_backup TO service_role;


--
-- Name: TABLE project_steps; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.project_steps TO anon;
GRANT ALL ON TABLE public.project_steps TO authenticated;
GRANT ALL ON TABLE public.project_steps TO service_role;


--
-- Name: TABLE projects; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.projects TO anon;
GRANT ALL ON TABLE public.projects TO authenticated;
GRANT ALL ON TABLE public.projects TO service_role;


--
-- Name: TABLE pseudonym_dictionaries; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pseudonym_dictionaries TO anon;
GRANT ALL ON TABLE public.pseudonym_dictionaries TO authenticated;
GRANT ALL ON TABLE public.pseudonym_dictionaries TO service_role;


--
-- Name: TABLE pseudonym_mappings; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pseudonym_mappings TO anon;
GRANT ALL ON TABLE public.pseudonym_mappings TO authenticated;
GRANT ALL ON TABLE public.pseudonym_mappings TO service_role;


--
-- Name: TABLE redaction_audit_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.redaction_audit_log TO anon;
GRANT ALL ON TABLE public.redaction_audit_log TO authenticated;
GRANT ALL ON TABLE public.redaction_audit_log TO service_role;


--
-- Name: TABLE redaction_patterns; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.redaction_patterns TO anon;
GRANT ALL ON TABLE public.redaction_patterns TO authenticated;
GRANT ALL ON TABLE public.redaction_patterns TO service_role;


--
-- Name: TABLE role_audit_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.role_audit_log TO anon;
GRANT ALL ON TABLE public.role_audit_log TO authenticated;
GRANT ALL ON TABLE public.role_audit_log TO service_role;


--
-- Name: TABLE sensitive_data_vault; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sensitive_data_vault TO anon;
GRANT ALL ON TABLE public.sensitive_data_vault TO authenticated;
GRANT ALL ON TABLE public.sensitive_data_vault TO service_role;


--
-- Name: TABLE tasks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tasks TO anon;
GRANT ALL ON TABLE public.tasks TO authenticated;
GRANT ALL ON TABLE public.tasks TO service_role;


--
-- Name: TABLE user_cidafm_commands; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_cidafm_commands TO anon;
GRANT ALL ON TABLE public.user_cidafm_commands TO authenticated;
GRANT ALL ON TABLE public.user_cidafm_commands TO service_role;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.users TO anon;
GRANT ALL ON TABLE public.users TO authenticated;
GRANT ALL ON TABLE public.users TO service_role;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: TABLE messages_2025_11_04; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_11_04 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_11_04 TO dashboard_user;


--
-- Name: TABLE messages_2025_11_05; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_11_05 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_11_05 TO dashboard_user;


--
-- Name: TABLE messages_2025_11_06; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_11_06 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_11_06 TO dashboard_user;


--
-- Name: TABLE messages_2025_11_07; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_11_07 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_11_07 TO dashboard_user;


--
-- Name: TABLE messages_2025_11_08; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2025_11_08 TO postgres;
GRANT ALL ON TABLE realtime.messages_2025_11_08 TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO postgres;
GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT ALL ON TABLE realtime.schema_migrations TO supabase_realtime_admin;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT ALL ON TABLE realtime.subscription TO supabase_realtime_admin;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO postgres WITH GRANT OPTION;


--
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- Name: TABLE iceberg_namespaces; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.iceberg_namespaces TO service_role;
GRANT SELECT ON TABLE storage.iceberg_namespaces TO authenticated;
GRANT SELECT ON TABLE storage.iceberg_namespaces TO anon;


--
-- Name: TABLE iceberg_tables; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.iceberg_tables TO service_role;
GRANT SELECT ON TABLE storage.iceberg_tables TO authenticated;
GRANT SELECT ON TABLE storage.iceberg_tables TO anon;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO postgres WITH GRANT OPTION;


--
-- Name: TABLE prefixes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.prefixes TO service_role;
GRANT ALL ON TABLE storage.prefixes TO authenticated;
GRANT ALL ON TABLE storage.prefixes TO anon;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: TABLE hooks; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.hooks TO postgres;
GRANT ALL ON TABLE supabase_functions.hooks TO anon;
GRANT ALL ON TABLE supabase_functions.hooks TO authenticated;
GRANT ALL ON TABLE supabase_functions.hooks TO service_role;


--
-- Name: SEQUENCE hooks_id_seq; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO postgres;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO anon;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO authenticated;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO service_role;


--
-- Name: TABLE migrations; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.migrations TO postgres;
GRANT ALL ON TABLE supabase_functions.migrations TO anon;
GRANT ALL ON TABLE supabase_functions.migrations TO authenticated;
GRANT ALL ON TABLE supabase_functions.migrations TO service_role;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

